import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { Border } from "../GlobalStyles";

const HomeLight = () => {
  return (
    <View style={styles.homeLight}>
      <Image
        style={[styles.homeLightChild, styles.homeLayout]}
        contentFit="cover"
        source={require("../assets/rectangle-11.png")}
      />
      <Image
        style={[styles.homeLightItem, styles.homeLayout]}
        contentFit="cover"
        source={require("../assets/vector-3.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  homeLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    bottom: "12.44%",
    position: "absolute",
  },
  homeLightChild: {
    height: "66.83%",
    width: "58.29%",
    top: "20.73%",
    right: "20.98%",
    left: "20.73%",
  },
  homeLightItem: {
    height: "25.12%",
    width: "20.73%",
    top: "62.44%",
    right: "39.76%",
    left: "39.51%",
    borderRadius: Border.br_12xs,
  },
  homeLight: {
    width: 41,
    height: 41,
    display: "none",
  },
});

export default HomeLight;
