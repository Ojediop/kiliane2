import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";

const HomeLightIcon = ({ style }) => {
  return (
    <Image
      style={[styles.homeLightIcon, style]}
      contentFit="cover"
      source={require("../assets/home-light.png")}
    />
  );
};

const styles = StyleSheet.create({
  homeLightIcon: {
    width: 41,
    height: 41,
  },
});

export default HomeLightIcon;
