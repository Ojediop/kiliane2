import * as React from "react";
import {
  StyleProp,
  ViewStyle,
  StyleSheet,
  View,
  Pressable,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Border, Padding, Color } from "../GlobalStyles";

const FrameComponent = ({ style }) => {
  const navigation = useNavigation();

  return (
    <View style={[styles.frameParent, style, styles.frameFlexBox]}>
      <View style={[styles.frameGroup, styles.frameFlexBox]}>
        <View style={styles.lightWrapperFlexBox}>
          <View style={styles.homeLight}>
            <View style={styles.frameContainer}>
              <View style={styles.vectorWrapper}>
                <Image
                  style={styles.frameChild}
                  contentFit="cover"
                  source={require("../assets/rectangle-12.png")}
                />
              </View>
              <Image
                style={styles.groupChild}
                contentFit="cover"
                source={require("../assets/frame-397.png")}
              />
            </View>
          </View>
        </View>
        <Pressable
          style={styles.lightWrapperFlexBox}
          onPress={() => navigation.navigate("ReviewEmptyState")}
        >
          <View style={styles.chatLight}>
            <View style={styles.chatLightChild} />
            <Image
              style={[styles.chatLightItem, styles.chatLayout]}
              contentFit="cover"
              source={require("../assets/vector-71.png")}
            />
            <Image
              style={[styles.chatLightInner, styles.chatLayout]}
              contentFit="cover"
              source={require("../assets/vector-81.png")}
            />
          </View>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    position: "absolute",
  },
  chatLayout: {
    height: 0,
    overflow: "hidden",
    maxWidth: "100%",
    borderRadius: Border.br_11xs,
    right: "37.6%",
    position: "absolute",
  },
  lightWrapperFlexBox: {
    flex: 1,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
  frameChild: {
    width: 22,
    height: 25,
  },
  vectorWrapper: {
    top: 0,
    left: 0,
    padding: Padding.p_3xs,
    flexDirection: "row",
    position: "absolute",
  },
  groupChild: {
    top: 16,
    left: 7,
    width: 28,
    height: 29,
    position: "absolute",
  },
  frameContainer: {
    width: 42,
    height: 45,
  },
  homeLight: {
    width: 41,
    height: 41,
    flexDirection: "row",
  },
  chatLightChild: {
    borderTopLeftRadius: Border.br_4xs,
    borderTopRightRadius: Border.br_4xs,
    borderBottomRightRadius: Border.br_11xs,
    borderBottomLeftRadius: Border.br_4xs,
    borderColor: Color.colorGray_100,
    borderWidth: 1,
    width: 26,
    height: 26,
    zIndex: 0,
    borderStyle: "solid",
  },
  chatLightItem: {
    width: "25.07%",
    top: "45.78%",
    left: "37.33%",
    zIndex: 1,
  },
  chatLightInner: {
    width: "12.53%",
    top: "62.4%",
    left: "49.86%",
    zIndex: 2,
  },
  chatLight: {
    padding: Padding.p_7xs,
    flexDirection: "row",
  },
  frameGroup: {
    right: 25,
    bottom: 22,
    left: 22,
    zIndex: 0,
  },
  frameParent: {
    borderRadius: Border.br_3xl,
    backgroundColor: Color.grey,
    borderColor: Color.colorGoldenrod_100,
    borderWidth: 2,
    width: 349,
    height: 88,
    display: "none",
    borderStyle: "solid",
  },
});

export default FrameComponent;
