import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";

const UserLight = () => {
  return (
    <View style={styles.userLight}>
      <Image
        style={[styles.userLightChild, styles.userLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-451.png")}
      />
      <Image
        style={[styles.userLightItem, styles.userLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-461.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  userLayout: {
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  userLightChild: {
    height: "50%",
    width: "66.59%",
    top: "66.59%",
    right: "16.83%",
    bottom: "-16.59%",
    left: "16.59%",
  },
  userLightItem: {
    height: "33.41%",
    width: "33.41%",
    top: "16.59%",
    right: "33.17%",
    bottom: "50%",
    left: "33.41%",
  },
  userLight: {
    width: 41,
    height: 41,
    display: "none",
  },
});

export default UserLight;
