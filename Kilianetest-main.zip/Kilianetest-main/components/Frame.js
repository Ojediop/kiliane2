import * as React from "react";
import {
  StyleProp,
  ViewStyle,
  StyleSheet,
  View,
  Pressable,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Padding } from "../GlobalStyles";

const Frame = ({ style }) => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={[styles.userLightParent, style]}
      onPress={() => navigation.navigate("Profile")}
    >
      <View style={styles.userLight}>
        <Image
          style={styles.userLightChild}
          contentFit="cover"
          source={require("../assets/ellipse-46.png")}
        />
        <Image
          style={styles.userLightItem}
          contentFit="cover"
          source={require("../assets/ellipse-45.png")}
        />
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  userLightChild: {
    width: 12,
    height: 12,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  userLightItem: {
    width: 25,
    height: 19,
    marginTop: 6,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  userLight: {
    paddingHorizontal: Padding.p_7xs,
    paddingVertical: 0,
    alignItems: "center",
  },
  userLightParent: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    transform: [
      {
        rotate: "180deg",
      },
    ],
    alignItems: "center",
  },
});

export default Frame;
