import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { Border } from "../GlobalStyles";

const ChatAltLight = () => {
  return (
    <View style={styles.chatAltLight}>
      <Image
        style={styles.chatAltLightChild}
        contentFit="cover"
        source={require("../assets/rectangle-1.png")}
      />
      <Image
        style={[styles.chatAltLightItem, styles.chatLayout]}
        contentFit="cover"
        source={require("../assets/vector-7.png")}
      />
      <Image
        style={[styles.chatAltLightInner, styles.chatLayout]}
        contentFit="cover"
        source={require("../assets/vector-8.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  chatLayout: {
    height: 0,
    borderRadius: Border.br_11xs,
    left: "37.56%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  chatAltLightChild: {
    height: "66.59%",
    width: "66.59%",
    top: "16.59%",
    right: "16.83%",
    bottom: "16.83%",
    left: "16.59%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  chatAltLightItem: {
    width: "25.12%",
    top: "41.71%",
    right: "37.32%",
  },
  chatAltLightInner: {
    width: "12.44%",
    top: "58.29%",
    right: "50%",
  },
  chatAltLight: {
    width: 41,
    height: 41,
    display: "none",
  },
});

export default ChatAltLight;
