import * as React from "react";
import { ScrollView, Pressable, StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Padding, FontFamily, Color, FontSize } from "../GlobalStyles";

const AllReviews = () => {
  const navigation = useNavigation();

  return (
    <ScrollView
      style={styles.allReviews}
      showsVerticalScrollIndicator={true}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.allReviewsScrollViewContent}
    >
      <View style={[styles.frameParent, styles.frameWrapperFlexBox]}>
        <View style={[styles.frameGroup, styles.frameWrapperFlexBox]}>
          <View style={[styles.backButtonWrapper, styles.frameWrapperFlexBox]}>
            <Pressable
              style={styles.backButton}
              onPress={() => navigation.navigate("AddReview")}
            >
              <Image
                style={styles.icon}
                contentFit="cover"
                source={require("../assets/back-button1.png")}
              />
            </Pressable>
          </View>
          <View style={[styles.tousLesAvisWrapper, styles.wrapperSpaceBlock]}>
            <Text style={[styles.tousLesAvis, styles.fatouTypo]}>
              Tous les avis
            </Text>
          </View>
        </View>
        <View style={[styles.frameWrapper, styles.frameWrapperFlexBox]}>
          <ScrollView
            style={styles.frameContainer}
            horizontal={true}
            showsVerticalScrollIndicator={true}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.frameScrollViewContent}
          >
            <View style={[styles.frameView, styles.frameParentFlexBox]}>
              <View style={[styles.frameParent1, styles.frameParentFlexBox]}>
                <View style={styles.frameParent2}>
                  <View style={styles.frameParent3}>
                    <View style={styles.wrapperSpaceBlock}>
                      <Image
                        style={styles.frameChild}
                        contentFit="cover"
                        source={require("../assets/ellipse-12.png")}
                      />
                    </View>
                    <View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.fatou, styles.fatouTypo]}>
                          fatou
                        </Text>
                      </View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.text, styles.textText]}>
                          12/12/2023
                        </Text>
                      </View>
                      <View style={styles.frameParent3}>
                        <Image
                          style={styles.starIconLayout}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                      </View>
                    </View>
                  </View>
                  <Image
                    style={styles.frameItem}
                    contentFit="cover"
                    source={require("../assets/frame-227.png")}
                  />
                </View>
                <View
                  style={[
                    styles.responsibleForDiagnosingExWrapper,
                    styles.frameParentFlexBox,
                  ]}
                >
                  <Text
                    style={[styles.responsibleForDiagnosing, styles.textText]}
                  >{`responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.
responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.`}</Text>
                </View>
              </View>
              <View style={[styles.frameParent5, styles.frameParentFlexBox]}>
                <View style={styles.frameParent2}>
                  <View style={styles.frameParent3}>
                    <View style={styles.wrapperSpaceBlock}>
                      <Image
                        style={styles.frameChild}
                        contentFit="cover"
                        source={require("../assets/ellipse-12.png")}
                      />
                    </View>
                    <View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.fatou, styles.fatouTypo]}>
                          fatou
                        </Text>
                      </View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.text, styles.textText]}>
                          12/12/2023
                        </Text>
                      </View>
                      <View style={styles.frameParent3}>
                        <Image
                          style={styles.starIconLayout}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                      </View>
                    </View>
                  </View>
                  <Image
                    style={styles.frameItem}
                    contentFit="cover"
                    source={require("../assets/frame-227.png")}
                  />
                </View>
                <View
                  style={[
                    styles.responsibleForDiagnosingExWrapper,
                    styles.frameParentFlexBox,
                  ]}
                >
                  <Text
                    style={[styles.responsibleForDiagnosing, styles.textText]}
                  >{`responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.
responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.`}</Text>
                </View>
              </View>
              <View style={[styles.frameParent5, styles.frameParentFlexBox]}>
                <View style={styles.frameParent2}>
                  <View style={styles.frameParent3}>
                    <View style={styles.wrapperSpaceBlock}>
                      <Image
                        style={styles.frameChild}
                        contentFit="cover"
                        source={require("../assets/ellipse-12.png")}
                      />
                    </View>
                    <View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.fatou, styles.fatouTypo]}>
                          fatou
                        </Text>
                      </View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.text, styles.textText]}>
                          12/12/2023
                        </Text>
                      </View>
                      <View style={styles.frameParent3}>
                        <Image
                          style={styles.starIconLayout}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                      </View>
                    </View>
                  </View>
                  <Image
                    style={styles.frameItem}
                    contentFit="cover"
                    source={require("../assets/frame-227.png")}
                  />
                </View>
                <View
                  style={[
                    styles.responsibleForDiagnosingExWrapper,
                    styles.frameParentFlexBox,
                  ]}
                >
                  <Text
                    style={[styles.responsibleForDiagnosing, styles.textText]}
                  >{`responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.
responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.`}</Text>
                </View>
              </View>
              <View style={[styles.frameParent5, styles.frameParentFlexBox]}>
                <View style={styles.frameParent2}>
                  <View style={styles.frameParent3}>
                    <View style={styles.wrapperSpaceBlock}>
                      <Image
                        style={styles.frameChild}
                        contentFit="cover"
                        source={require("../assets/ellipse-12.png")}
                      />
                    </View>
                    <View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.fatou, styles.fatouTypo]}>
                          fatou
                        </Text>
                      </View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.text, styles.textText]}>
                          12/12/2023
                        </Text>
                      </View>
                      <View style={styles.frameParent3}>
                        <Image
                          style={styles.starIconLayout}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                      </View>
                    </View>
                  </View>
                  <Image
                    style={styles.frameItem}
                    contentFit="cover"
                    source={require("../assets/frame-227.png")}
                  />
                </View>
                <View
                  style={[
                    styles.responsibleForDiagnosingExWrapper,
                    styles.frameParentFlexBox,
                  ]}
                >
                  <Text
                    style={[styles.responsibleForDiagnosing, styles.textText]}
                  >{`responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.
responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.`}</Text>
                </View>
              </View>
              <View style={[styles.frameParent5, styles.frameParentFlexBox]}>
                <View style={styles.frameParent2}>
                  <View style={styles.frameParent3}>
                    <View style={styles.wrapperSpaceBlock}>
                      <Image
                        style={styles.frameChild}
                        contentFit="cover"
                        source={require("../assets/ellipse-12.png")}
                      />
                    </View>
                    <View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.fatou, styles.fatouTypo]}>
                          fatou
                        </Text>
                      </View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.text, styles.textText]}>
                          12/12/2023
                        </Text>
                      </View>
                      <View style={styles.frameParent3}>
                        <Image
                          style={styles.starIconLayout}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                      </View>
                    </View>
                  </View>
                  <Image
                    style={styles.frameItem}
                    contentFit="cover"
                    source={require("../assets/frame-227.png")}
                  />
                </View>
                <View
                  style={[
                    styles.responsibleForDiagnosingExWrapper,
                    styles.frameParentFlexBox,
                  ]}
                >
                  <Text
                    style={[styles.responsibleForDiagnosing, styles.textText]}
                  >{`responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.
responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.`}</Text>
                </View>
              </View>
              <View style={[styles.frameParent5, styles.frameParentFlexBox]}>
                <View style={styles.frameParent2}>
                  <View style={styles.frameParent3}>
                    <View style={styles.wrapperSpaceBlock}>
                      <Image
                        style={styles.frameChild}
                        contentFit="cover"
                        source={require("../assets/ellipse-12.png")}
                      />
                    </View>
                    <View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.fatou, styles.fatouTypo]}>
                          fatou
                        </Text>
                      </View>
                      <View
                        style={[styles.fatouWrapper, styles.frameParentFlexBox]}
                      >
                        <Text style={[styles.text, styles.textText]}>
                          12/12/2023
                        </Text>
                      </View>
                      <View style={styles.frameParent3}>
                        <Image
                          style={styles.starIconLayout}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                        <Image
                          style={[styles.starIcon1, styles.starIconLayout]}
                          contentFit="cover"
                          source={require("../assets/star6.png")}
                        />
                      </View>
                    </View>
                  </View>
                  <Image
                    style={styles.frameItem}
                    contentFit="cover"
                    source={require("../assets/frame-227.png")}
                  />
                </View>
                <View
                  style={[
                    styles.responsibleForDiagnosingExWrapper,
                    styles.frameParentFlexBox,
                  ]}
                >
                  <Text
                    style={[styles.responsibleForDiagnosing, styles.textText]}
                  >{`responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.
responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.`}</Text>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  frameScrollViewContent: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  allReviewsScrollViewContent: {
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  frameWrapperFlexBox: {
    justifyContent: "space-between",
    alignSelf: "stretch",
  },
  wrapperSpaceBlock: {
    padding: Padding.p_3xs,
    flexDirection: "row",
  },
  fatouTypo: {
    textAlign: "left",
    textTransform: "capitalize",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  frameParentFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  textText: {
    color: Color.labelsPrimary,
    textAlign: "left",
    textTransform: "capitalize",
  },
  starIconLayout: {
    height: 13,
    width: 13,
  },
  buttonFlexBox: {
    width: 349,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
  },
  lightLayout: {
    height: 41,
    width: 41,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  backButton: {
    width: 25,
    height: 25,
  },
  backButtonWrapper: {
    width: 73,
    paddingHorizontal: Padding.p_mid,
    paddingVertical: Padding.p_3xs,
    alignItems: "center",
    flexDirection: "row",
  },
  tousLesAvis: {
    fontSize: FontSize.size_base,
    color: Color.color,
  },
  tousLesAvisWrapper: {
    alignItems: "center",
    alignSelf: "stretch",
    flex: 1,
    backgroundColor: Color.labelColorDarkPrimary,
  },
  frameGroup: {
    height: 145,
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: Color.labelColorDarkPrimary,
  },
  frameChild: {
    width: 40,
    height: 40,
  },
  fatou: {
    color: Color.colorDarkslategray_200,
    fontSize: FontSize.size_xs,
  },
  fatouWrapper: {
    padding: Padding.p_3xs,
    flexDirection: "row",
  },
  text: {
    fontSize: FontSize.size_5xs,
    opacity: 0.6,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    color: Color.labelsPrimary,
  },
  starIcon1: {
    marginLeft: 5,
  },
  frameParent3: {
    flexDirection: "row",
  },
  frameItem: {
    width: 4,
    height: 19,
    marginLeft: 191,
  },
  frameParent2: {
    alignItems: "center",
    flexDirection: "row",
  },
  responsibleForDiagnosing: {
    letterSpacing: 0.2,
    fontWeight: "300",
    fontFamily: FontFamily.poppinsLight,
    width: 283,
    opacity: 0.8,
    fontSize: FontSize.size_xs,
  },
  responsibleForDiagnosingExWrapper: {
    marginTop: 3,
    padding: Padding.p_3xs,
    flexDirection: "row",
  },
  frameParent1: {
    alignSelf: "stretch",
  },
  frameParent5: {
    marginTop: 23,
    alignSelf: "stretch",
  },
  frameView: {
    flex: 1,
  },
  frameContainer: {
    alignSelf: "stretch",
    width: "100%",
    flex: 1,
  },
  frameWrapper: {
    flex: 1,
    backgroundColor: Color.labelColorDarkPrimary,
  },
  frameParent: {
    flex: 1,
  },
  allReviews: {
    overflow: "hidden",
    maxWidth: "100%",
    width: "100%",
    flex: 1,
    backgroundColor: Color.labelColorDarkPrimary,
  },
});

export default AllReviews;
