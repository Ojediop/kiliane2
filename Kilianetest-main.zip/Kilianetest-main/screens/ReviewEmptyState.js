import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const ReviewEmptyState = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.reviewEmptyState}>
      <View style={styles.statusBarIphoneXOrNewe}>
        <Image
          style={styles.notchIcon}
          contentFit="cover"
          source={require("../assets/notch1.png")}
        />
        <View style={[styles.rightSide, styles.iconLayout]}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery1.png")}
          />
          <Image
            style={[styles.wifiIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/wifi3.png")}
          />
          <Image
            style={[styles.mobileSignalIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/mobile-signal1.png")}
          />
        </View>
        <View style={styles.leftSide}>
          <View style={[styles.time, styles.timePosition]}>
            <Text style={[styles.text, styles.textTypo]}>9:41</Text>
          </View>
        </View>
      </View>
      <View style={[styles.menuProfile, styles.rowSpaceBlock]}>
        <Pressable
          style={styles.iconsLayout}
          onPress={() =>
            navigation.navigate("BottomTabsRoot", { screen: "HomePage1" })
          }
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/frame-319.png")}
          />
        </Pressable>
        <View style={styles.hotelRadissonWrapper}>
          <Text style={[styles.hotelRadisson, styles.donnerUnAvisTypo]}>
            Hotel Radisson
          </Text>
        </View>
      </View>
      <View style={[styles.row, styles.rowSpaceBlock]}>
        <Image
          style={styles.customerSurveypanaIcon}
          contentFit="cover"
          source={require("../assets/customersurveypana.png")}
        />
        <View style={styles.frameParent}>
          <View style={styles.pasEncoreDavisWrapper}>
            <Text style={styles.pasEncoreDavis}>Pas encore d’avis</Text>
          </View>
          <View style={styles.ilNyAPasEncoreDavisSiWrapper}>
            <Text style={[styles.ilNyA, styles.textTypo]}>
              Il n’y a pas encore d’avis. si vous souhaitez donner un avis
              cliquez sur le bouton en dessous.
            </Text>
          </View>
        </View>
      </View>
      <Pressable
        style={[styles.bottomNavigation, styles.rowSpaceBlock]}
        onPress={() => navigation.navigate("AddReview")}
      >
        <Pressable
          style={styles.primaryButtondefault}
          onPress={() => navigation.navigate("AddReview")}
        >
          <Image
            style={[styles.icons, styles.iconsLayout]}
            contentFit="cover"
            source={require("../assets/icons.png")}
          />
          <Text style={[styles.donnerUnAvis, styles.donnerUnAvisTypo]}>
            Donner un avis
          </Text>
          <Image
            style={[styles.icons1, styles.iconsLayout]}
            contentFit="cover"
            source={require("../assets/icons.png")}
          />
        </Pressable>
        <View style={styles.homeIndicator} />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    height: 11,
    position: "absolute",
  },
  timePosition: {
    left: 0,
    width: 54,
    position: "absolute",
  },
  textTypo: {
    textAlign: "center",
    fontSize: FontSize.defaultBoldSubheadline_size,
  },
  rowSpaceBlock: {
    marginTop: 219,
    alignItems: "center",
  },
  donnerUnAvisTypo: {
    textAlign: "left",
    fontFamily: FontFamily.subtitleBold14,
    fontWeight: "700",
  },
  iconsLayout: {
    height: 24,
    width: 24,
  },
  buttonFlexBox: {
    justifyContent: "space-between",
    width: 349,
    flexDirection: "row",
    alignItems: "center",
  },
  lightLayout: {
    height: 41,
    width: 41,
  },
  notchIcon: {
    marginLeft: -109.5,
    top: -2,
    left: "50%",
    width: 219,
    height: 30,
    position: "absolute",
    display: "none",
  },
  batteryIcon: {
    right: 0,
    width: 24,
    top: 0,
    height: 11,
    position: "absolute",
  },
  wifiIcon: {
    right: 29,
    width: 15,
    top: 0,
  },
  mobileSignalIcon: {
    right: 50,
    width: 17,
    top: 0,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
  },
  text: {
    top: 1,
    letterSpacing: 0,
    lineHeight: 20,
    fontWeight: "500",
    fontFamily: FontFamily.mulishMedium,
    height: 20,
    color: Color.labelColorDarkPrimary,
    left: 0,
    width: 54,
    position: "absolute",
  },
  time: {
    borderRadius: Border.br_5xl,
    backgroundColor: Color.colorMediumseagreen,
    height: 21,
    top: 0,
  },
  leftSide: {
    top: 12,
    left: 16,
    height: 21,
    width: 54,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    width: 375,
    height: 44,
    display: "none",
    overflow: "hidden",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  hotelRadisson: {
    fontSize: FontSize.size_base,
    color: Color.colorDarkslategray_200,
    letterSpacing: -0.2,
    textAlign: "left",
    flex: 1,
  },
  hotelRadissonWrapper: {
    marginLeft: 12,
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  menuProfile: {
    flexDirection: "row",
    width: 343,
    marginTop: 219,
  },
  customerSurveypanaIcon: {
    width: 196,
    height: 141,
    display: "none",
  },
  pasEncoreDavis: {
    fontSize: FontSize.size_5xl,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.subtitleBold14,
    fontWeight: "700",
    letterSpacing: -0.2,
    textAlign: "center",
    flex: 1,
  },
  pasEncoreDavisWrapper: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
  },
  ilNyA: {
    letterSpacing: -0.1,
    fontFamily: FontFamily.mulishRegular,
    width: 277,
    color: Color.colorDarkslategray_200,
  },
  ilNyAPasEncoreDavisSiWrapper: {
    marginTop: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  frameParent: {
    marginTop: 16,
    alignSelf: "stretch",
    alignItems: "center",
  },
  row: {
    alignSelf: "stretch",
    flex: 1,
  },
  icons: {
    display: "none",
    overflow: "hidden",
  },
  donnerUnAvis: {
    fontSize: FontSize.subtitleBold14_size,
    marginLeft: 8,
    color: Color.labelColorDarkPrimary,
  },
  icons1: {
    marginLeft: 8,
    display: "none",
    overflow: "hidden",
  },
  primaryButtondefault: {
    borderRadius: Border.br_5xs,
    backgroundColor: Color.color,
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: Padding.p_base,
    alignSelf: "stretch",
    flexDirection: "row",
    justifyContent: "center",
    overflow: "hidden",
  },
  homeIndicator: {
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorDarkslategray_200,
    width: 134,
    height: 5,
    marginTop: 16,
    display: "none",
  },
  bottomNavigation: {
    height: 9,
    paddingBottom: 74,
    width: 343,
    marginTop: 219,
    justifyContent: "center",
  },
  reviewEmptyState: {
    backgroundColor: Color.labelColorDarkPrimary,
    paddingHorizontal: Padding.p_base,
    paddingTop: Padding.p_49xl,
    paddingBottom: 133,
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
    width: "100%",
    flex: 1,
  },
});

export default ReviewEmptyState;
