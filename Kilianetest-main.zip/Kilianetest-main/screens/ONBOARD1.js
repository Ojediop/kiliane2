import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border, Padding } from "../GlobalStyles";

const ONBOARD1 = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.onboard2, styles.onboard2FlexBox]}>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
      <View style={[styles.onboard2Inner, styles.onboard2FlexBox]}>
        <View>
          <View style={styles.frameWrapper}>
            <View style={styles.welcomeMessageContainerWrapper}>
              <View>
                <View style={[styles.titleWrapper, styles.wrapperFlexBox]}>
                  <Text style={styles.title}>Kiliane</Text>
                </View>
                <View
                  style={[
                    styles.loremIpsumDolorSitAmetCoWrapper,
                    styles.wrapperFlexBox,
                  ]}
                >
                  <Text
                    style={[styles.loremIpsumDolor, styles.button1Typo]}
                  >{`Notre application offre une expérience fluide et transparente, permettant aux clients de partager leurs
impressions en quelques instants. Ils peuvent attribuer une note, laisser un commentaire détaillé et
même partager leurs opinions sur les réseaux sociaux, tout cela en quelques clics.`}</Text>
                </View>
              </View>
            </View>
          </View>
          <View style={styles.frameContainer}>
            <View style={styles.frameView}>
              <View>
                <Pressable
                  style={[styles.onboard, styles.onboardFlexBox]}
                  onPress={() => navigation.navigate("ONBOARD2")}
                >
                  <View style={styles.buttonWrapperFlexBox}>
                    <Image
                      style={styles.carouselIndicatorChild}
                      contentFit="cover"
                      source={require("../assets/ellipse-1.png")}
                    />
                    <View
                      style={[
                        styles.carouselIndicatorItem,
                        styles.carouselSpaceBlock,
                      ]}
                    />
                    <Image
                      style={[
                        styles.carouselIndicatorInner,
                        styles.carouselSpaceBlock,
                      ]}
                      contentFit="cover"
                      source={require("../assets/ellipse-1.png")}
                    />
                  </View>
                  <Pressable
                    style={styles.welcomeMessageContainerWrapper}
                    onPress={() => navigation.navigate("ONBOARD2")}
                  >
                    <View
                      style={[
                        styles.buttonWrapper,
                        styles.buttonWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.button1, styles.button1Typo]}>
                        Suivant
                      </Text>
                    </View>
                  </Pressable>
                </Pressable>
              </View>
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.stattusBar, styles.onboardFlexBox]}>
        <View style={[styles.timeWrapper, styles.timeWrapperFlexBox]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
        </View>
        <View
          style={[styles.cellularConnectionParent, styles.timeWrapperFlexBox]}
        >
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection1.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi2.png")}
          />
          <View style={styles.battery}>
            <View style={[styles.border, styles.borderPosition]} />
            <Image
              style={[styles.capIcon, styles.borderPosition]}
              contentFit="cover"
              source={require("../assets/cap1.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  onboard2FlexBox: {
    justifyContent: "center",
    alignItems: "flex-end",
    flexDirection: "row",
  },
  stattusBarLayout: {
    display: "none",
    width: 375,
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  wrapperFlexBox: {
    paddingHorizontal: 0,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  button1Typo: {
    fontSize: FontSize.size_xl,
    textAlign: "left",
  },
  onboardFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
  carouselSpaceBlock: {
    marginLeft: 4,
    height: 8,
  },
  buttonWrapperFlexBox: {
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  timeWrapperFlexBox: {
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  timeTypo: {
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  borderPosition: {
    left: "50%",
    position: "absolute",
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
  },
  title: {
    fontSize: FontSize.size_5xl,
    lineHeight: 36,
    color: Color.color,
    textAlign: "left",
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  titleWrapper: {
    paddingVertical: Padding.p_3xs,
  },
  loremIpsumDolor: {
    lineHeight: 30,
    fontWeight: "500",
    fontFamily: FontFamily.montserratMedium,
    color: Color.textDark,
    flex: 1,
  },
  loremIpsumDolorSitAmetCoWrapper: {
    paddingVertical: Padding.p_xs,
    width: 327,
  },
  welcomeMessageContainerWrapper: {
    flexDirection: "row",
  },
  frameWrapper: {
    padding: Padding.p_3xs,
    flexDirection: "row",
  },
  carouselIndicatorChild: {
    height: 8,
    width: 8,
  },
  carouselIndicatorItem: {
    borderRadius: Border.br_31xl,
    width: 27,
    backgroundColor: Color.color,
  },
  carouselIndicatorInner: {
    width: 8,
    marginLeft: 4,
  },
  button1: {
    color: Color.color1,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  buttonWrapper: {
    borderRadius: Border.br_9xs,
    width: 120,
    height: 48,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_7xs,
    backgroundColor: Color.color,
  },
  onboard: {
    width: 327,
  },
  frameView: {
    padding: Padding.p_3xs,
  },
  frameContainer: {
    marginTop: 38,
  },
  onboard2Inner: {
    marginLeft: 10,
    padding: Padding.p_3xs,
  },
  time: {
    fontSize: FontSize.size_mid,
    lineHeight: 22,
    color: Color.labelsPrimary,
    textAlign: "center",
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    paddingVertical: Padding.p_3xs,
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderStyle: "solid",
    borderColor: Color.labelsPrimary,
    borderWidth: 1,
    width: 25,
    opacity: 0.35,
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    height: 13,
    marginLeft: 7,
    width: 27,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
  },
  stattusBar: {
    marginLeft: 10,
    display: "none",
    width: 375,
  },
  onboard2: {
    backgroundColor: Color.color1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    paddingHorizontal: 4,
    paddingVertical: 60,
    flex: 1,
  },
});

export default ONBOARD1;
