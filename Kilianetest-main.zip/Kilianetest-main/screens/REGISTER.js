import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Padding, FontFamily, FontSize, Border } from "../GlobalStyles";

const REGISTER = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.register, styles.wrapperFlexBox]}>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
      <View style={[styles.stattusBar, styles.stattusBarFlexBox]}>
        <View style={[styles.timeWrapper, styles.wrapperSpaceBlock]}>
          <Text style={[styles.time, styles.timeFlexBox]}>9:41</Text>
        </View>
        <View style={styles.cellularConnectionParent}>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <View style={styles.battery}>
            <View style={styles.border} />
            <Image
              style={styles.capIcon}
              contentFit="cover"
              source={require("../assets/cap.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={[styles.frameParent, styles.stattusBarFlexBox]}>
        <View
          style={[styles.crerUnNouveauCompteWrapper, styles.wrapperFlexBox]}
        >
          <Text style={[styles.crerUnNouveau, styles.timeFlexBox]}>
            Créer un nouveau compte
          </Text>
        </View>
        <View style={styles.frameGroupFlexBox}>
          <View>
            <View>
              <Text style={[styles.title, styles.titleTypo]}>Nom Complet</Text>
              <View style={[styles.inputTextWrapper, styles.buttonLayout]}>
                <Text style={[styles.inputText, styles.textTypo]}>
                  Fernando alonso
                </Text>
              </View>
            </View>
            <View style={styles.titleGroup}>
              <Text style={[styles.title, styles.titleTypo]}>Adresse mail</Text>
              <View style={[styles.inputTextWrapper, styles.buttonLayout]}>
                <Text style={[styles.inputText, styles.textTypo]}>
                  xyz123@gmail.com
                </Text>
              </View>
            </View>
            <View style={styles.titleGroup}>
              <Text style={[styles.title, styles.titleTypo]}>
                Numéro Téléphone
              </Text>
              <View style={[styles.inputTextWrapper, styles.buttonLayout]}>
                <Text style={[styles.inputText, styles.textTypo]}>+62</Text>
              </View>
            </View>
            <View style={styles.titleGroup}>
              <Text style={[styles.title, styles.titleTypo]}>Mot de passe</Text>
              <View style={[styles.inputTextWrapper, styles.buttonLayout]}>
                <Text style={[styles.inputText, styles.textTypo]}>
                  ********
                </Text>
              </View>
            </View>
          </View>
          <View style={[styles.instanceWrapper, styles.frameGroupFlexBox]}>
            <View>
              <Text style={[styles.title, styles.titleTypo]}>
                Confirmer mot de passe
              </Text>
              <View style={[styles.inputTextWrapper, styles.buttonLayout]}>
                <Text style={[styles.inputText, styles.textTypo]}>
                  ********
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.tcWrapper}>
          <View style={styles.wrapperFlexBox}>
            <View style={[styles.tcChild, styles.tcChildBorder]} />
            <Text style={[styles.iAgreeOf, styles.titleTypo]}>
              i agree of the term of use
            </Text>
          </View>
        </View>
        <View style={styles.tcWrapper}>
          <Pressable
            style={styles.buttonLayout}
            onPress={() => navigation.navigate("REGISTERSUCCESS")}
          >
            <View
              style={[styles.buttonContainer, styles.buttonContainerLayout]}
            >
              <Text style={styles.button1}>Enregistrer</Text>
            </View>
          </Pressable>
        </View>
        <View
          style={[styles.crerUnNouveauCompteWrapper, styles.wrapperFlexBox]}
        >
          <Pressable onPress={() => navigation.navigate("LOGIN")}>
            <Text style={styles.textTypo}>
              <Text
                style={styles.vousAvezDja}
              >{`Vous avez déja un compte ? `}</Text>
              <Text style={styles.seConnecter}>Se connecter</Text>
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperFlexBox: {
    alignItems: "center",
    flexDirection: "row",
  },
  stattusBarLayout: {
    display: "none",
    width: 375,
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  stattusBarFlexBox: {
    marginLeft: 10,
    justifyContent: "space-between",
    alignItems: "center",
  },
  wrapperSpaceBlock: {
    paddingVertical: Padding.p_3xs,
    height: 44,
  },
  timeFlexBox: {
    textAlign: "center",
    lineHeight: 22,
  },
  titleTypo: {
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  buttonLayout: {
    width: 327,
    flexDirection: "row",
  },
  textTypo: {
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textAlign: "center",
    lineHeight: 22,
  },
  frameGroupFlexBox: {
    alignSelf: "stretch",
    alignItems: "center",
  },
  tcChildBorder: {
    borderColor: Color.grey,
    borderStyle: "solid",
  },
  buttonContainerLayout: {
    borderRadius: Border.br_9xs,
    alignItems: "center",
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
  },
  time: {
    fontSize: FontSize.size_mid,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    textAlign: "center",
    lineHeight: 22,
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderColor: Color.labelsPrimary,
    width: 25,
    opacity: 0.35,
    borderWidth: 1,
    borderStyle: "solid",
    left: "50%",
    position: "absolute",
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
    left: "50%",
    position: "absolute",
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    width: 27,
    height: 13,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  stattusBar: {
    display: "none",
    width: 375,
    flexDirection: "row",
  },
  crerUnNouveau: {
    fontSize: FontSize.size_xl,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    textAlign: "center",
    lineHeight: 22,
  },
  crerUnNouveauCompteWrapper: {
    padding: Padding.p_3xs,
    justifyContent: "center",
  },
  title: {
    fontSize: FontSize.size_base,
    color: Color.textDark,
    textAlign: "center",
    lineHeight: 22,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  inputText: {
    color: Color.grey,
  },
  inputTextWrapper: {
    borderWidth: 2,
    paddingHorizontal: Padding.p_xs,
    marginTop: 8,
    borderColor: Color.grey,
    borderStyle: "solid",
    borderRadius: Border.br_9xs,
    alignItems: "center",
    paddingVertical: Padding.p_3xs,
    height: 44,
  },
  titleGroup: {
    marginTop: 12,
  },
  instanceWrapper: {
    marginTop: 2,
    padding: Padding.p_3xs,
    justifyContent: "center",
  },
  tcChild: {
    borderRadius: Border.br_11xs,
    width: 14,
    height: 14,
    borderWidth: 1,
  },
  iAgreeOf: {
    fontSize: FontSize.size_xs,
    color: Color.colorDimgray,
    marginLeft: 12,
    textAlign: "left",
  },
  tcWrapper: {
    padding: Padding.p_3xs,
  },
  button1: {
    fontWeight: "700",
    fontFamily: FontFamily.montserratBold,
    color: Color.frame1,
    textAlign: "left",
    fontSize: FontSize.size_xl,
  },
  buttonContainer: {
    backgroundColor: Color.color2,
    height: 48,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_7xs,
    justifyContent: "center",
    flexDirection: "row",
    flex: 1,
  },
  vousAvezDja: {
    color: Color.labelsPrimary,
  },
  seConnecter: {
    textDecoration: "underline",
    color: Color.color2,
  },
  frameParent: {
    height: 651,
    flex: 1,
  },
  register: {
    backgroundColor: Color.color1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    paddingHorizontal: Padding.p_sm,
    paddingVertical: 58,
    justifyContent: "center",
    flex: 1,
  },
});

export default REGISTER;
