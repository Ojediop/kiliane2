import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const HomePageInvite = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homePageInvite}>
      <Text style={[styles.lesMieuxNots, styles.consultingTypo]}>
        les mieux notés
      </Text>
      <Text style={styles.voirTout}>Voir tout</Text>
      <View style={[styles.hospitals, styles.hospitalsPosition]}>
        <Text style={[styles.quelquesAvis, styles.consultingTypo]}>
          Quelques Avis
        </Text>
        <Text style={[styles.voirTout1, styles.voirTypo]}>Voir tout</Text>
        <LinearGradient
          style={[styles.hospitalsChild, styles.hospitalsPosition]}
          locations={[0, 1]}
          colors={["#fff", "rgba(255, 255, 255, 0)"]}
        />
        <View style={[styles.hospitals1, styles.hospitals1FlexBox]}>
          <View style={styles.rectangleLayout}>
            <View style={styles.groupChild} />
            <Text style={[styles.laGondole, styles.consultingTypo]}>
              la gondole
            </Text>
            <Image
              style={styles.maskGroupIcon}
              contentFit="cover"
              source={require("../assets/mask-group.png")}
            />
            <Image
              style={[styles.toolIcon, styles.toolIconLayout]}
              contentFit="cover"
              source={require("../assets/tool.png")}
            />
            <Text style={[styles.westHamNorth, styles.westText]}>
              west ham, north England
            </Text>
            <Text style={[styles.kmAwayFrom, styles.awayTypo]}>
              5km away from your location
            </Text>
            <Image
              style={[styles.groupItem, styles.groupPosition]}
              contentFit="cover"
              source={require("../assets/group-57.png")}
            />
          </View>
          <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
            <View style={styles.groupChild} />
            <Text style={[styles.laGondole, styles.consultingTypo]}>
              Orange Senegal
            </Text>
            <Image
              style={styles.maskGroupIcon}
              contentFit="cover"
              source={require("../assets/mask-group1.png")}
            />
            <Image
              style={[styles.toolIcon, styles.toolIconLayout]}
              contentFit="cover"
              source={require("../assets/tool.png")}
            />
            <Text style={[styles.westHamNorth, styles.westText]}>
              west harm, north England
            </Text>
            <Text style={[styles.kmAwayFrom, styles.awayTypo]}>
              5km away from your location
            </Text>
            <Image
              style={[styles.groupItem, styles.groupPosition]}
              contentFit="cover"
              source={require("../assets/group-57.png")}
            />
          </View>
          <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
            <View style={styles.groupChild} />
            <Text style={[styles.laGondole, styles.consultingTypo]}>
              Apollo international hospital
            </Text>
            <Image
              style={styles.maskGroupIcon}
              contentFit="cover"
              source={require("../assets/mask-group2.png")}
            />
            <Image
              style={[styles.toolIcon2, styles.toolIconLayout]}
              contentFit="cover"
              source={require("../assets/tool.png")}
            />
            <Text style={[styles.westHarmNorth1, styles.westText]}>
              west harm, north England
            </Text>
            <Text style={styles.awayTypo}>5km away from your location</Text>
            <Image
              style={styles.groupPosition}
              contentFit="cover"
              source={require("../assets/group-57.png")}
            />
          </View>
          <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
            <View style={styles.groupChild} />
            <Text style={[styles.laGondole, styles.consultingTypo]}>
              Apollo international hospital
            </Text>
            <Image
              style={styles.maskGroupIcon}
              contentFit="cover"
              source={require("../assets/mask-group3.png")}
            />
            <Image
              style={[styles.toolIcon2, styles.toolIconLayout]}
              contentFit="cover"
              source={require("../assets/tool.png")}
            />
            <Text style={[styles.westHarmNorth1, styles.westText]}>
              west harm, north England
            </Text>
            <Text style={styles.awayTypo}>5km away from your location</Text>
            <Image
              style={styles.groupPosition}
              contentFit="cover"
              source={require("../assets/group-57.png")}
            />
          </View>
        </View>
      </View>
      <View style={[styles.homePageInviteInner, styles.maskGroupLayout2]}>
        <View style={[styles.maskGroupParent, styles.hospitals1FlexBox]}>
          <Image
            style={styles.maskGroupLayout2}
            contentFit="cover"
            source={require("../assets/mask-group4.png")}
          />
          <Image
            style={[styles.maskGroupIcon5, styles.maskGroupLayout2]}
            contentFit="cover"
            source={require("../assets/mask-group5.png")}
          />
          <Image
            style={[styles.maskGroupIcon5, styles.maskGroupLayout2]}
            contentFit="cover"
            source={require("../assets/mask-group6.png")}
          />
          <Image
            style={[styles.maskGroupIcon5, styles.maskGroupLayout2]}
            contentFit="cover"
            source={require("../assets/mask-group7.png")}
          />
          <Image
            style={[styles.maskGroupIcon5, styles.maskGroupLayout2]}
            contentFit="cover"
            source={require("../assets/mask-group8.png")}
          />
        </View>
      </View>
      <Pressable
        style={styles.categories}
        onPress={() => navigation.navigate("Review")}
      >
        <Text style={[styles.services, styles.consultingTypo]}>Services</Text>
        <View style={[styles.maskGroupGroup, styles.maskGroupLayout1]}>
          <Image
            style={styles.maskGroupIcon9}
            contentFit="cover"
            source={require("../assets/mask-group9.png")}
          />
          <Text style={[styles.hotel, styles.hotelTypo]}>Hotel</Text>
        </View>
        <View style={[styles.maskGroupContainer, styles.maskGroupLayout1]}>
          <Image
            style={styles.maskGroupIcon9}
            contentFit="cover"
            source={require("../assets/mask-group10.png")}
          />
          <Text style={[styles.dentiste, styles.hotelTypo]}>dentiste</Text>
        </View>
        <View style={[styles.maskGroupParent1, styles.maskGroupPosition2]}>
          <Image
            style={styles.maskGroupIcon9}
            contentFit="cover"
            source={require("../assets/mask-group11.png")}
          />
          <Text style={[styles.gynecologe, styles.hotelTypo]}>gynecologe</Text>
        </View>
        <View style={[styles.maskGroupParent2, styles.maskGroupPosition1]}>
          <Image
            style={styles.maskGroupIcon9}
            contentFit="cover"
            source={require("../assets/mask-group12.png")}
          />
          <Text style={[styles.fastFood, styles.hotelTypo]}>Fast Food</Text>
        </View>
        <View style={[styles.maskGroupParent3, styles.maskGroupPosition]}>
          <Image
            style={styles.maskGroupIcon9}
            contentFit="cover"
            source={require("../assets/mask-group13.png")}
          />
          <Text style={[styles.pretPorter, styles.hotelTypo]}>
            Pret à porter
          </Text>
        </View>
        <View style={[styles.maskGroupParent4, styles.maskGroupPosition2]}>
          <Image
            style={styles.maskGroupIcon9}
            contentFit="cover"
            source={require("../assets/mask-group14.png")}
          />
          <Text style={[styles.hotel, styles.hotelTypo]}>Banque</Text>
        </View>
        <View style={[styles.maskGroupParent5, styles.maskGroupPosition1]}>
          <Image
            style={styles.maskGroupIcon9}
            contentFit="cover"
            source={require("../assets/mask-group15.png")}
          />
          <Text style={[styles.gynecologe, styles.hotelTypo]}>Restaurant</Text>
        </View>
        <View style={[styles.maskGroupParent6, styles.maskGroupPosition]}>
          <Image
            style={styles.maskGroupIcon9}
            contentFit="cover"
            source={require("../assets/mask-group16.png")}
          />
          <Text style={[styles.hotel, styles.hotelTypo]}>Clinique</Text>
        </View>
        <Text style={[styles.voirTout2, styles.voirTypo]}>Voir tout</Text>
      </Pressable>
      <View style={styles.rectangleParent1}>
        <View style={[styles.groupChild4, styles.groupChildLayout]} />
        <Image
          style={[styles.maskGroupIcon17, styles.maskGroupLayout]}
          contentFit="cover"
          source={require("../assets/mask-group17.png")}
        />
        <Text style={[styles.accueilseaplazateyliomcom, styles.textTypo1]}>
          accueil.seaplaza@teyliom.com
        </Text>
        <Text style={[styles.yearExperience, styles.yearTypo]}>
          42 year experience
        </Text>
        <Text style={[styles.consultingFee, styles.consultingPosition]}>
          consulting fee
        </Text>
        <Text style={[styles.seaPlaza, styles.textTypo1]}>Sea plaza</Text>
        <Text style={[styles.text, styles.textTypo1]}>(+221) 33 859 89 62</Text>
        <View
          style={[
            styles.routeCornicheOuestDakarParent,
            styles.consultingPosition,
          ]}
        >
          <Text
            style={[styles.routeCornicheOuest, styles.routeCornicheOuestTypo]}
          >
            Route Corniche Ouest, Dakar
          </Text>
          <Image
            style={[styles.toolIcon4, styles.toolIconLayout]}
            contentFit="cover"
            source={require("../assets/tool.png")}
          />
        </View>
        <View style={[styles.parent, styles.parentLayout1]}>
          <Text style={styles.text1}>500</Text>
          <Image
            style={[styles.rupeeIcon, styles.toolIconLayout]}
            contentFit="cover"
            source={require("../assets/rupee.png")}
          />
        </View>
        <View style={[styles.group, styles.groupLayout]}>
          <Text style={[styles.text2, styles.westText]}>4.5</Text>
          <Text style={[styles.rating, styles.consultingTypo]}>rating</Text>
          <Image
            style={[styles.starIcon, styles.starIconLayout]}
            contentFit="cover"
            source={require("../assets/star.png")}
          />
        </View>
        <View style={styles.frameView} />
      </View>
      <View style={[styles.rectangleParent2, styles.groupChildLayout]}>
        <View style={[styles.groupChild5, styles.groupChildLayout]} />
        <Image
          style={[styles.maskGroupIcon18, styles.htelTerrouBiPosition]}
          contentFit="cover"
          source={require("../assets/mask-group18.png")}
        />
        <Text style={[styles.cardiologist, styles.textTypo1]}>
          Cardiologist
        </Text>
        <Text style={[styles.yearExperience1, styles.yearTypo]}>
          42 year experience
        </Text>
        <Text style={[styles.consultingFee1, styles.consultingPosition]}>
          consulting fee
        </Text>
        <Text style={[styles.htelTerrouBi, styles.htelTerrouBiPosition]}>
          Hôtel Terrou-Bi
        </Text>
        <Text style={[styles.text3, styles.textTypo]}>33 839 90 39</Text>
        <View
          style={[
            styles.boulevardMartinLutherKingDParent,
            styles.parentPosition1,
          ]}
        >
          <Text
            style={[
              styles.boulevardMartinLuther,
              styles.routeCornicheOuestTypo,
            ]}
          >
             Boulevard Martin Luther King Dakar
          </Text>
          <Image
            style={[styles.toolIcon4, styles.toolIconLayout]}
            contentFit="cover"
            source={require("../assets/tool.png")}
          />
        </View>
        <View style={[styles.container, styles.parentLayout1]}>
          <Text style={styles.text1}>500</Text>
          <Image
            style={[styles.rupeeIcon, styles.toolIconLayout]}
            contentFit="cover"
            source={require("../assets/rupee.png")}
          />
        </View>
        <View style={[styles.parent1, styles.groupLayout]}>
          <Text style={[styles.text2, styles.westText]}>4.5</Text>
          <Text style={[styles.rating, styles.consultingTypo]}>rating</Text>
          <Image
            style={[styles.starIcon, styles.starIconLayout]}
            contentFit="cover"
            source={require("../assets/star.png")}
          />
        </View>
      </View>
      <View style={[styles.rectangleParent3, styles.groupChildLayout]}>
        <View style={[styles.groupChild6, styles.groupChildLayout]} />
        <Image
          style={[styles.maskGroupIcon18, styles.htelTerrouBiPosition]}
          contentFit="cover"
          source={require("../assets/mask-group19.png")}
        />
        <Text style={[styles.cardiologist, styles.textTypo1]}>
          Cardiologist
        </Text>
        <Text style={[styles.yearExperience1, styles.yearTypo]}>
          42 year experience
        </Text>
        <Text style={[styles.consultingFee1, styles.consultingPosition]}>
          consulting fee
        </Text>
        <Text style={[styles.htelTerrouBi, styles.htelTerrouBiPosition]}>
          Auchan
        </Text>
        <Text style={styles.textTypo}>+ 221 33 876 21 21</Text>
        <View
          style={[
            styles.routeDuMridienPrsidentNgParent,
            styles.calendarIconLayout,
          ]}
        >
          <Text
            style={[styles.routeCornicheOuest, styles.routeCornicheOuestTypo]}
          >
            Route du Méridien Président Ngor, Dakar, Sénégal
          </Text>
          <Image
            style={[styles.toolIcon4, styles.toolIconLayout]}
            contentFit="cover"
            source={require("../assets/tool.png")}
          />
        </View>
        <View style={[styles.container, styles.parentLayout1]}>
          <Text style={styles.text1}>500</Text>
          <Image
            style={[styles.rupeeIcon, styles.toolIconLayout]}
            contentFit="cover"
            source={require("../assets/rupee.png")}
          />
        </View>
        <View style={[styles.parent1, styles.groupLayout]}>
          <Text style={[styles.text2, styles.westText]}>4.5</Text>
          <Text style={[styles.rating, styles.consultingTypo]}>rating</Text>
          <Image
            style={[styles.starIcon, styles.starIconLayout]}
            contentFit="cover"
            source={require("../assets/star.png")}
          />
        </View>
      </View>
      <View style={[styles.rectangleParent4, styles.groupChildLayout]}>
        <View style={[styles.groupChild7, styles.groupChildLayout]} />
        <Image
          style={[styles.maskGroupIcon18, styles.htelTerrouBiPosition]}
          contentFit="cover"
          source={require("../assets/mask-group20.png")}
        />
        <Text style={[styles.cardiologist, styles.textTypo1]}>
          Cardiologist
        </Text>
        <Text style={[styles.yearExperience1, styles.yearTypo]}>
          42 year experience
        </Text>
        <Text style={[styles.consultingFee1, styles.consultingPosition]}>
          consulting fee
        </Text>
        <Text style={[styles.htelTerrouBi, styles.htelTerrouBiPosition]}>
          La brioche dorée
        </Text>
        <Text style={[styles.text3, styles.textTypo]}>33 835 80 80</Text>
        <View style={[styles.unit21Parent, styles.parentPosition1]}>
          <Text
            style={[styles.routeCornicheOuest, styles.routeCornicheOuestTypo]}
          >
            Unité 21
          </Text>
          <Image
            style={[styles.toolIcon4, styles.toolIconLayout]}
            contentFit="cover"
            source={require("../assets/tool.png")}
          />
        </View>
        <View style={[styles.container, styles.parentLayout1]}>
          <Text style={styles.text1}>500</Text>
          <Image
            style={[styles.rupeeIcon, styles.toolIconLayout]}
            contentFit="cover"
            source={require("../assets/rupee.png")}
          />
        </View>
        <View style={[styles.parent1, styles.groupLayout]}>
          <Text style={[styles.text2, styles.westText]}>4.5</Text>
          <Text style={[styles.rating, styles.consultingTypo]}>rating</Text>
          <Image
            style={[styles.starIcon, styles.starIconLayout]}
            contentFit="cover"
            source={require("../assets/star.png")}
          />
        </View>
      </View>
      <View style={styles.statusBarParent}>
        <Image
          style={styles.statusBarIcon}
          contentFit="cover"
          source={require("../assets/status-bar.png")}
        />
        <View style={styles.groupParent}>
          <Image
            style={styles.groupChild8}
            contentFit="cover"
            source={require("../assets/group-34.png")}
          />
          <Text style={[styles.bonjourMoussa, styles.westHamClr]}>
            Bonjour moussa
          </Text>
          <Image
            style={[styles.notificationIcon, styles.iconLayout1]}
            contentFit="cover"
            source={require("../assets/notification.png")}
          />
          <Image
            style={styles.ellipseIcon}
            contentFit="cover"
            source={require("../assets/ellipse-9.png")}
          />
          <Image
            style={styles.groupChild9}
            contentFit="cover"
            source={require("../assets/ellipse-10.png")}
          />
          <View style={[styles.westHamParent, styles.iconLayout1]}>
            <Text style={[styles.westHam, styles.westHamPosition]}>
              west ham
            </Text>
            <Text style={styles.yourLocation}>your location</Text>
            <Image
              style={styles.locationIcon}
              contentFit="cover"
              source={require("../assets/location.png")}
            />
            <Image
              style={[
                styles.downFilledTriangularArrow,
                styles.rectangleIconLayout,
              ]}
              contentFit="cover"
              source={require("../assets/down-filled-triangular-arrow.png")}
            />
          </View>
          <View style={[styles.component8, styles.component8Position]}>
            <Text style={styles.goodMorningTypo}>good morning</Text>
            <Text style={[styles.stayHealthy, styles.goodMorningTypo]}>
              stay healthy
            </Text>
          </View>
          <View style={[styles.homePage, styles.homePageLayout]}>
            <View style={[styles.rectangleParent5, styles.homePageLayout]}>
              <View style={[styles.groupChild10, styles.homePageLayout]} />
              <Image
                style={[
                  styles.magnifyingGlassIcon,
                  styles.doctorParentPosition,
                ]}
                contentFit="cover"
                source={require("../assets/magnifying-glass.png")}
              />
            </View>
            <View style={[styles.component46, styles.starIconLayout]}>
              <View style={[styles.frameParent, styles.mimsWrapperLayout]}>
                <View style={[styles.mimsWrapper, styles.mimsWrapperLayout]}>
                  <Text style={[styles.mims, styles.mimsWrapperLayout]}>
                    ”MIMS”
                  </Text>
                </View>
                <View style={[styles.mariaWrapper, styles.mimsWrapperLayout]}>
                  <Text style={[styles.mims, styles.mimsWrapperLayout]}>
                    ”Maria”
                  </Text>
                </View>
                <View
                  style={[styles.christopherWrapper, styles.mimsWrapperLayout]}
                >
                  <Text style={[styles.mims, styles.mimsWrapperLayout]}>
                    ”Christopher”
                  </Text>
                </View>
                <View style={[styles.tomWrapper, styles.mimsWrapperLayout]}>
                  <Text style={[styles.mims, styles.mimsWrapperLayout]}>
                    ”tom”
                  </Text>
                </View>
              </View>
              <View style={styles.egWrapper}>
                <Text style={[styles.eg, styles.egTypo]}>eg:</Text>
              </View>
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.rectangleParent6, styles.groupChild11Layout]}>
        <View style={[styles.groupChild11, styles.groupChild11Layout]} />
        <View style={[styles.homeSignParent, styles.parentPosition]}>
          <Image
            style={styles.homeSignIcon}
            contentFit="cover"
            source={require("../assets/home-sign.png")}
          />
          <Text style={[styles.home, styles.homeTypo]}>home</Text>
        </View>
        <View style={[styles.calendarParent, styles.parentLayout]}>
          <Image
            style={[styles.calendarIcon, styles.calendarIconLayout]}
            contentFit="cover"
            source={require("../assets/calendar.png")}
          />
          <Text style={[styles.myAppointments, styles.allHospitalsTypo]}>
            my appointments
          </Text>
          <Image
            style={[styles.rectangleIcon, styles.rectangleIconLayout]}
            contentFit="cover"
            source={require("../assets/rectangle-109.png")}
          />
          <View style={[styles.groupChild12, styles.groupChildBg]} />
        </View>
        <View style={[styles.doctorParent, styles.doctorParentPosition]}>
          <Image
            style={[styles.doctorIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/doctor.png")}
          />
          <Image
            style={styles.iconPencil}
            contentFit="cover"
            source={require("../assets/-icon-pencil.png")}
          />
          <Text style={[styles.avis, styles.homeTypo]}>Avis</Text>
        </View>
        <View style={[styles.hospitalParent, styles.allHospitalsLayout]}>
          <Image
            style={[styles.hospitalIcon, styles.iconLayout1]}
            contentFit="cover"
            source={require("../assets/hospital.png")}
          />
          <Text style={[styles.allHospitals, styles.allHospitalsLayout]}>
            all hospitals
          </Text>
          <View style={[styles.groupChild13, styles.groupChildBg]} />
        </View>
        <Pressable
          style={[styles.userParent, styles.parentPosition]}
          onPress={() =>
            navigation.navigate("BottomTabsRoot", { screen: "Profile" })
          }
        >
          <Image
            style={[styles.userIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/user.png")}
          />
          <Text style={[styles.profile, styles.homeTypo]}>profile</Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  consultingTypo: {
    textAlign: "left",
    textTransform: "capitalize",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  hospitalsPosition: {
    width: 360,
    left: 0,
    position: "absolute",
  },
  voirTypo: {
    top: 2,
    color: Color.color,
    fontFamily: FontFamily.poppinsMedium,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontWeight: "500",
    textTransform: "capitalize",
    position: "absolute",
  },
  hospitals1FlexBox: {
    flexDirection: "row",
    position: "absolute",
  },
  toolIconLayout: {
    width: 10,
    height: 10,
    position: "absolute",
  },
  westText: {
    color: Color.colorDarkslategray_200,
    textAlign: "left",
    textTransform: "capitalize",
    position: "absolute",
  },
  awayTypo: {
    top: 164,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.montserratRegular,
    fontSize: FontSize.size_3xs,
    left: 27,
    textAlign: "left",
    textTransform: "capitalize",
    position: "absolute",
  },
  groupPosition: {
    height: 8,
    width: 9,
    left: 13,
    top: 164,
    opacity: 0.7,
    position: "absolute",
  },
  rectangleLayout: {
    height: 180,
    width: 220,
  },
  maskGroupLayout2: {
    height: 151,
    width: 330,
  },
  maskGroupLayout1: {
    height: 89,
    width: 70,
    left: 0,
    position: "absolute",
  },
  hotelTypo: {
    top: 82,
    color: Color.colorDarkslategray_200,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.poppinsMedium,
    textAlign: "left",
    fontWeight: "500",
    textTransform: "capitalize",
    position: "absolute",
  },
  maskGroupPosition2: {
    left: 87,
    height: 89,
    width: 70,
    position: "absolute",
  },
  maskGroupPosition1: {
    left: 174,
    height: 89,
    width: 70,
    position: "absolute",
  },
  maskGroupPosition: {
    left: 260,
    height: 89,
    width: 70,
    position: "absolute",
  },
  groupChildLayout: {
    height: 147,
    position: "absolute",
  },
  maskGroupLayout: {
    height: 117,
    width: 100,
    left: 12,
  },
  textTypo1: {
    color: Color.colorTeal,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    left: 122,
    textAlign: "left",
    textTransform: "capitalize",
  },
  yearTypo: {
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    left: 122,
    color: Color.colorDarkslategray_200,
    fontSize: FontSize.size_3xs,
    opacity: 0.7,
    display: "none",
    textAlign: "left",
    textTransform: "capitalize",
    position: "absolute",
  },
  consultingPosition: {
    left: 122,
    position: "absolute",
  },
  routeCornicheOuestTypo: {
    lineHeight: 13,
    top: 1,
    color: Color.colorDarkslategray_200,
    fontSize: FontSize.size_3xs,
    left: 15,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textTransform: "capitalize",
    position: "absolute",
  },
  parentLayout1: {
    width: 34,
    left: 282,
    display: "none",
    height: 10,
    position: "absolute",
  },
  groupLayout: {
    height: 36,
    left: 295,
    width: 24,
    position: "absolute",
  },
  starIconLayout: {
    height: 15,
    position: "absolute",
  },
  htelTerrouBiPosition: {
    top: 15,
    position: "absolute",
  },
  textTypo: {
    top: 38,
    color: Color.colorTeal,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    left: 122,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    textTransform: "capitalize",
    position: "absolute",
  },
  parentPosition1: {
    top: 100,
    left: 122,
    opacity: 0.7,
  },
  calendarIconLayout: {
    height: 21,
    position: "absolute",
  },
  westHamClr: {
    color: Color.colorDarkslategray_100,
    position: "absolute",
  },
  iconLayout1: {
    height: 20,
    position: "absolute",
  },
  westHamPosition: {
    opacity: 0.8,
    top: 13,
  },
  rectangleIconLayout: {
    height: 7,
    position: "absolute",
  },
  component8Position: {
    left: 50,
    display: "none",
  },
  goodMorningTypo: {
    fontSize: FontSize.size_smi_7,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorDarkslategray_100,
    opacity: 0.7,
    textAlign: "left",
    textTransform: "capitalize",
  },
  homePageLayout: {
    height: 41,
    width: 330,
    left: 0,
    position: "absolute",
  },
  doctorParentPosition: {
    top: 12,
    position: "absolute",
  },
  mimsWrapperLayout: {
    width: 135,
    position: "absolute",
  },
  egTypo: {
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    textTransform: "capitalize",
  },
  groupChild11Layout: {
    height: 91,
    width: 375,
    left: 0,
    position: "absolute",
  },
  parentPosition: {
    height: 60,
    top: 17,
    position: "absolute",
  },
  homeTypo: {
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    textTransform: "capitalize",
    position: "absolute",
  },
  parentLayout: {
    height: 32,
    display: "none",
    top: 10,
  },
  allHospitalsTypo: {
    top: 26,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    left: 0,
    textAlign: "left",
    color: Color.labelsPrimary,
    textTransform: "capitalize",
  },
  groupChildBg: {
    backgroundColor: Color.labelsPrimary,
    position: "absolute",
  },
  iconLayout: {
    height: 38,
    width: 39,
    position: "absolute",
  },
  allHospitalsLayout: {
    width: 51,
    position: "absolute",
  },
  lesMieuxNots: {
    top: 655,
    color: Color.labelsPrimary,
    fontSize: FontSize.defaultBoldSubheadline_size,
    textTransform: "capitalize",
    position: "absolute",
    left: 23,
  },
  voirTout: {
    top: 657,
    left: 306,
    color: Color.color,
    fontFamily: FontFamily.poppinsMedium,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontWeight: "500",
    textTransform: "capitalize",
    position: "absolute",
  },
  quelquesAvis: {
    left: 15,
    top: 0,
    color: Color.labelsPrimary,
    fontSize: FontSize.defaultBoldSubheadline_size,
    textTransform: "capitalize",
    position: "absolute",
  },
  voirTout1: {
    left: 298,
  },
  hospitalsChild: {
    height: 118,
    backgroundColor: "transparent",
    top: 40,
  },
  groupChild: {
    backgroundColor: Color.colorWhitesmoke_100,
    borderRadius: Border.br_3xs,
    height: 180,
    width: 220,
    top: 0,
    left: 0,
    position: "absolute",
  },
  laGondole: {
    top: 130,
    left: 12,
    fontSize: FontSize.size_xs,
    color: Color.labelsPrimary,
    position: "absolute",
  },
  maskGroupIcon: {
    height: 110,
    width: 200,
    left: 10,
    top: 10,
    position: "absolute",
  },
  toolIcon: {
    opacity: 0.7,
    display: "none",
    height: 10,
    top: 146,
    width: 10,
    left: 12,
  },
  westHamNorth: {
    fontFamily: FontFamily.montserratRegular,
    left: 27,
    top: 147,
    color: Color.colorDarkslategray_200,
    fontSize: FontSize.size_3xs,
    display: "none",
  },
  kmAwayFrom: {
    display: "none",
  },
  groupItem: {
    display: "none",
  },
  rectangleGroup: {
    marginLeft: 15,
  },
  toolIcon2: {
    opacity: 0.7,
    height: 10,
    top: 146,
    width: 10,
    left: 12,
  },
  westHarmNorth1: {
    fontFamily: FontFamily.montserratRegular,
    left: 27,
    top: 147,
    color: Color.colorDarkslategray_200,
    fontSize: FontSize.size_3xs,
  },
  hospitals1: {
    width: 330,
    top: 50,
    left: 15,
  },
  hospitals: {
    top: 1373,
    height: 230,
  },
  maskGroupIcon5: {
    marginLeft: 20,
  },
  maskGroupParent: {
    top: 0,
    left: 0,
  },
  homePageInviteInner: {
    top: 201,
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowRadius: 10,
    elevation: 10,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    borderRadius: Border.br_3xs,
    backgroundColor: Color.labelColorDarkPrimary,
    left: 22,
    position: "absolute",
    overflow: "hidden",
  },
  services: {
    top: 0,
    left: 0,
    color: Color.labelsPrimary,
    fontSize: FontSize.defaultBoldSubheadline_size,
    textTransform: "capitalize",
    position: "absolute",
  },
  maskGroupIcon9: {
    height: 70,
    width: 70,
    top: 0,
    left: 0,
    position: "absolute",
  },
  hotel: {
    left: 15,
  },
  maskGroupGroup: {
    top: 40,
  },
  dentiste: {
    left: 13,
  },
  maskGroupContainer: {
    top: 154,
  },
  gynecologe: {
    left: 6,
  },
  maskGroupParent1: {
    top: 154,
  },
  fastFood: {
    left: 12,
  },
  maskGroupParent2: {
    top: 154,
  },
  pretPorter: {
    left: 1,
  },
  maskGroupParent3: {
    top: 154,
  },
  maskGroupParent4: {
    top: 40,
  },
  maskGroupParent5: {
    top: 40,
  },
  maskGroupParent6: {
    top: 40,
  },
  voirTout2: {
    left: 283,
  },
  categories: {
    top: 382,
    height: 243,
    width: 337,
    left: 23,
    position: "absolute",
  },
  groupChild4: {
    top: 27,
    borderRadius: Border.br_mini,
    elevation: 8,
    shadowRadius: 8,
    shadowColor: "rgba(0, 0, 0, 0.08)",
    height: 147,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    width: 330,
    left: 0,
    backgroundColor: Color.labelColorDarkPrimary,
  },
  maskGroupIcon17: {
    top: 42,
    position: "absolute",
  },
  accueilseaplazateyliomcom: {
    top: 86,
    fontSize: FontSize.size_2xs,
    color: Color.colorTeal,
    position: "absolute",
  },
  yearExperience: {
    top: 107,
  },
  consultingFee: {
    top: 151,
    color: Color.colorSteelblue,
    display: "none",
    fontSize: FontSize.size_xs,
    textAlign: "left",
    textTransform: "capitalize",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  seaPlaza: {
    fontSize: FontSize.subtitleBold14_size,
    top: 42,
    position: "absolute",
  },
  text: {
    top: 65,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  routeCornicheOuest: {
    width: 181,
  },
  toolIcon4: {
    opacity: 0.7,
    height: 10,
    top: 0,
    left: 0,
  },
  routeCornicheOuestDakarParent: {
    top: 127,
    width: 196,
    opacity: 0.7,
    height: 10,
  },
  text1: {
    left: 11,
    top: 1,
    color: Color.colorSteelblue,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textTransform: "capitalize",
    position: "absolute",
  },
  rupeeIcon: {
    height: 10,
    top: 0,
    left: 0,
  },
  parent: {
    top: 150,
  },
  text2: {
    top: 19,
    fontSize: FontSize.size_2xs_3,
    left: 4,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  rating: {
    top: 31,
    fontSize: FontSize.size_6xs_9,
    color: Color.colorSteelblue,
    opacity: 0.7,
    left: 0,
    position: "absolute",
  },
  starIcon: {
    width: 15,
    left: 4,
    top: 0,
  },
  group: {
    top: 37,
  },
  frameView: {
    left: 114,
    height: 100,
    width: 100,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  rectangleParent1: {
    top: 668,
    height: 174,
    width: 330,
    left: 15,
    position: "absolute",
  },
  groupChild5: {
    borderRadius: Border.br_mini,
    elevation: 8,
    shadowRadius: 8,
    shadowColor: "rgba(0, 0, 0, 0.08)",
    height: 147,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    width: 330,
    left: 0,
    backgroundColor: Color.labelColorDarkPrimary,
    top: 0,
  },
  maskGroupIcon18: {
    height: 117,
    width: 100,
    left: 12,
  },
  cardiologist: {
    top: 59,
    fontSize: FontSize.size_2xs,
    color: Color.colorTeal,
    position: "absolute",
    display: "none",
  },
  yearExperience1: {
    top: 80,
  },
  consultingFee1: {
    top: 124,
    color: Color.colorSteelblue,
    display: "none",
    fontSize: FontSize.size_xs,
    textAlign: "left",
    textTransform: "capitalize",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  htelTerrouBi: {
    fontSize: FontSize.subtitleBold14_size,
    color: Color.colorTeal,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    left: 122,
    textAlign: "left",
    textTransform: "capitalize",
  },
  text3: {
    textDecoration: "underline",
  },
  boulevardMartinLuther: {
    width: 200,
  },
  boulevardMartinLutherKingDParent: {
    width: 215,
    height: 10,
    position: "absolute",
  },
  container: {
    top: 123,
  },
  parent1: {
    top: 10,
  },
  rectangleParent2: {
    top: 862,
    width: 337,
    left: 15,
  },
  groupChild6: {
    borderRadius: Border.br_mini,
    elevation: 8,
    shadowRadius: 8,
    shadowColor: "rgba(0, 0, 0, 0.08)",
    height: 147,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    width: 330,
    left: 0,
    backgroundColor: Color.labelColorDarkPrimary,
    top: 0,
  },
  routeDuMridienPrsidentNgParent: {
    top: 100,
    left: 122,
    opacity: 0.7,
    width: 196,
  },
  rectangleParent3: {
    top: 1029,
    width: 330,
    left: 15,
  },
  groupChild7: {
    borderRadius: Border.br_mini,
    elevation: 8,
    shadowRadius: 8,
    shadowColor: "rgba(0, 0, 0, 0.08)",
    height: 147,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    width: 330,
    left: 0,
    backgroundColor: Color.labelColorDarkPrimary,
    top: 0,
  },
  unit21Parent: {
    width: 196,
    height: 10,
    position: "absolute",
  },
  rectangleParent4: {
    top: 1196,
    width: 330,
    left: 15,
  },
  statusBarIcon: {
    width: 344,
    height: 16,
    top: 10,
    left: 15,
    position: "absolute",
  },
  groupChild8: {
    top: -7,
    height: 45,
    width: 45,
    left: -1,
    display: "none",
    position: "absolute",
  },
  bonjourMoussa: {
    left: 50,
    display: "none",
    fontSize: FontSize.subtitleBold14_size,
    top: 0,
    textAlign: "left",
    textTransform: "capitalize",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  notificationIcon: {
    left: 310,
    width: 20,
    top: -1,
    height: 20,
    display: "none",
  },
  ellipseIcon: {
    left: 321,
    height: 9,
    width: 9,
    display: "none",
    top: 0,
    position: "absolute",
  },
  groupChild9: {
    left: 305,
    width: 11,
    height: 10,
    top: 0,
    position: "absolute",
  },
  westHam: {
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    textTransform: "capitalize",
    color: Color.colorDarkslategray_100,
    position: "absolute",
    left: 11,
    fontSize: FontSize.size_3xs,
    opacity: 0.8,
    top: 13,
  },
  yourLocation: {
    opacity: 0.5,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorDarkslategray_100,
    left: 11,
    top: 1,
    textAlign: "left",
    textTransform: "capitalize",
    position: "absolute",
  },
  locationIcon: {
    left: 70,
    width: 19,
    height: 19,
    top: 0,
    position: "absolute",
  },
  downFilledTriangularArrow: {
    borderRadius: Border.br_115xl,
    width: 7,
    opacity: 0.8,
    top: 13,
    left: 0,
  },
  westHamParent: {
    left: 200,
    width: 89,
    top: -1,
    height: 20,
    display: "none",
  },
  stayHealthy: {
    marginTop: 6.3,
  },
  component8: {
    top: 18,
    height: 13,
    position: "absolute",
    overflow: "hidden",
  },
  groupChild10: {
    shadowColor: "rgba(0, 0, 0, 0.04)",
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    borderRadius: Border.br_3xs,
    backgroundColor: Color.labelColorDarkPrimary,
    top: 0,
  },
  magnifyingGlassIcon: {
    width: 17,
    height: 17,
    opacity: 0.5,
    left: 13,
  },
  rectangleParent5: {
    top: 0,
  },
  mims: {
    height: 11,
    opacity: 0.5,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    textTransform: "capitalize",
    fontSize: FontSize.subtitleBold14_size,
    top: 0,
    left: 0,
    color: Color.labelsPrimary,
  },
  mimsWrapper: {
    height: 11,
    top: 0,
    left: 0,
  },
  mariaWrapper: {
    top: 21,
    height: 11,
    left: 0,
  },
  christopherWrapper: {
    height: 11,
    top: 42,
    left: 0,
  },
  tomWrapper: {
    top: 63,
    height: 11,
    left: 0,
  },
  frameParent: {
    left: 25,
    height: 74,
    top: 0,
  },
  eg: {
    opacity: 0.5,
    fontSize: FontSize.subtitleBold14_size,
    top: 0,
    left: 0,
    color: Color.labelsPrimary,
    position: "absolute",
  },
  egWrapper: {
    width: 20,
    height: 10,
    top: 0,
    left: 0,
    position: "absolute",
  },
  component46: {
    top: 16,
    left: 45,
    width: 160,
    overflow: "hidden",
  },
  homePage: {
    top: 64,
  },
  groupParent: {
    top: 66,
    height: 105,
    width: 330,
    left: 23,
    position: "absolute",
  },
  statusBarParent: {
    height: 191,
    width: 375,
    left: -1,
    backgroundColor: Color.colorWhitesmoke_100,
    top: 0,
    position: "absolute",
  },
  groupChild11: {
    backgroundColor: Color.frame1,
    borderStyle: "solid",
    borderColor: Color.colorSteelblue,
    borderWidth: 0.5,
    top: 0,
  },
  homeSignIcon: {
    height: 43,
    width: 48,
    top: 0,
    left: 0,
    position: "absolute",
  },
  home: {
    width: 45,
    left: 4,
    color: Color.colorSteelblue,
    height: 10,
    top: 50,
  },
  homeSignParent: {
    left: 36,
    width: 48,
  },
  calendarIcon: {
    left: 26,
    width: 24,
    height: 21,
    top: 0,
  },
  myAppointments: {
    width: 73,
    position: "absolute",
  },
  rectangleIcon: {
    top: 9,
    left: 39,
    width: 8,
  },
  groupChild12: {
    top: 3,
    left: 31,
    height: 3,
    width: 15,
  },
  calendarParent: {
    left: 80,
    width: 73,
    position: "absolute",
  },
  doctorIcon: {
    top: 5,
    display: "none",
    left: 10,
  },
  iconPencil: {
    height: "73.85%",
    width: "49.64%",
    top: "0%",
    right: "50.36%",
    bottom: "26.15%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  avis: {
    top: 54,
    left: 16,
    width: 81,
    height: 11,
    color: Color.labelsPrimary,
  },
  doctorParent: {
    left: 159,
    width: 97,
    height: 65,
  },
  hospitalIcon: {
    width: 23,
    left: 15,
    top: 0,
  },
  allHospitals: {
    top: 26,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    left: 0,
    textAlign: "left",
    color: Color.labelsPrimary,
    textTransform: "capitalize",
  },
  groupChild13: {
    top: 7,
    width: 8,
    height: 9,
    left: 22,
  },
  hospitalParent: {
    left: 239,
    height: 32,
    display: "none",
    top: 10,
  },
  userIcon: {
    top: 0,
    left: 0,
  },
  profile: {
    top: 49,
    left: 2,
    width: 47,
    height: 11,
    color: Color.labelsPrimary,
  },
  userParent: {
    left: 284,
    width: 49,
  },
  rectangleParent6: {
    top: 728,
  },
  homePageInvite: {
    flex: 1,
    width: "100%",
    height: 1725,
    overflow: "hidden",
    backgroundColor: Color.labelColorDarkPrimary,
  },
});

export default HomePageInvite;
