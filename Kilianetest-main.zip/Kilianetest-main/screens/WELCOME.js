import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Padding, Border, FontSize, FontFamily } from "../GlobalStyles";

const WELCOME = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.welcome}>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
      <View style={[styles.stattusBar, styles.stattusBarSpaceBlock]}>
        <View style={[styles.timeWrapper, styles.timeWrapperFlexBox]}>
          <Text style={styles.time}>9:41</Text>
        </View>
        <View
          style={[styles.cellularConnectionParent, styles.timeWrapperFlexBox]}
        >
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection1.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi2.png")}
          />
          <View style={styles.battery}>
            <View style={[styles.border, styles.borderPosition]} />
            <Image
              style={[styles.capIcon, styles.borderPosition]}
              contentFit="cover"
              source={require("../assets/cap1.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={[styles.frameParent, styles.stattusBarSpaceBlock]}>
        <View style={styles.frameGroup}>
          <View style={styles.bienvenueWrapper}>
            <Text style={styles.bienvenue}>BIENVENUE!</Text>
          </View>
          <View style={styles.bienvenueWrapper}>
            <Text style={styles.choisirUneOption}>
              Choisir une option pour continuer
            </Text>
          </View>
        </View>
        <View style={styles.frameContainer}>
          <Pressable
            style={styles.buttonWrapper}
            onPress={() => navigation.navigate("HomePageInvite1")}
          >
            <Pressable
              style={styles.button}
              onPress={() => navigation.navigate("HomePageInvite1")}
            >
              <View style={[styles.buttonContainer, styles.buttonFlexBox]}>
                <Text style={styles.button1}>Invité</Text>
              </View>
            </Pressable>
          </Pressable>
          <View style={styles.buttonWrapper}>
            <Pressable
              style={styles.button}
              onPress={() => navigation.navigate("LOGIN")}
            >
              <View style={[styles.buttonContainer, styles.buttonFlexBox]}>
                <Text style={styles.button1}>Se connecter</Text>
              </View>
            </Pressable>
          </View>
          <View style={styles.buttonWrapper}>
            <Pressable
              style={styles.button}
              onPress={() => navigation.navigate("REGISTER")}
            >
              <View style={[styles.buttonWrapper2, styles.buttonFlexBox]}>
                <Text style={styles.button1}>S’enregistrer</Text>
              </View>
            </Pressable>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  stattusBarLayout: {
    display: "none",
    width: 375,
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  stattusBarSpaceBlock: {
    marginLeft: 10,
    alignItems: "center",
  },
  timeWrapperFlexBox: {
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  borderPosition: {
    left: "50%",
    position: "absolute",
  },
  buttonFlexBox: {
    paddingVertical: Padding.p_7xs,
    paddingHorizontal: Padding.p_3xs,
    height: 48,
    borderRadius: Border.br_9xs,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    flex: 1,
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
  },
  time: {
    fontSize: FontSize.size_mid,
    lineHeight: 22,
    fontWeight: "600",
    fontFamily: FontFamily.montserratSemiBold,
    textAlign: "center",
    color: Color.labelsPrimary,
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    paddingVertical: Padding.p_3xs,
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderStyle: "solid",
    borderColor: Color.labelsPrimary,
    borderWidth: 1,
    width: 25,
    opacity: 0.35,
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    width: 27,
    height: 13,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
  },
  stattusBar: {
    justifyContent: "space-between",
    display: "none",
    width: 375,
    flexDirection: "row",
  },
  bienvenue: {
    fontSize: 64,
    fontFamily: FontFamily.bebasNeueRegular,
    color: Color.textDark,
    textAlign: "left",
  },
  bienvenueWrapper: {
    alignItems: "center",
    flexDirection: "row",
  },
  choisirUneOption: {
    fontSize: FontSize.size_base,
    fontWeight: "500",
    fontFamily: FontFamily.montserratMedium,
    textAlign: "left",
    color: Color.labelsPrimary,
  },
  frameGroup: {
    alignItems: "center",
  },
  button1: {
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.montserratBold,
    color: Color.frame1,
    textAlign: "left",
  },
  buttonContainer: {
    backgroundColor: Color.color,
  },
  button: {
    width: 327,
    flexDirection: "row",
  },
  buttonWrapper: {
    padding: Padding.p_3xs,
  },
  buttonWrapper2: {
    backgroundColor: Color.color2,
  },
  frameContainer: {
    marginTop: 211,
  },
  frameParent: {
    justifyContent: "flex-end",
  },
  welcome: {
    backgroundColor: Color.color1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    alignItems: "flex-end",
    paddingHorizontal: Padding.p_sm,
    paddingVertical: 55,
    justifyContent: "center",
    flex: 1,
    flexDirection: "row",
  },
});

export default WELCOME;
