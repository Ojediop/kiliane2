import * as React from "react";
import { Text, StyleSheet, View, Pressable, TextInput } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Padding, FontSize, Border } from "../GlobalStyles";

const ForgetPassword = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.forgetPassword}>
      <View style={[styles.stattusBar, styles.stattusBarLayout]}>
        <View style={[styles.timeWrapper, styles.wrapperFlexBox]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
        </View>
        <View style={[styles.cellularConnectionParent, styles.wrapperFlexBox]}>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <View style={styles.battery}>
            <View style={[styles.border, styles.borderPosition]} />
            <Image
              style={[styles.capIcon, styles.borderPosition]}
              contentFit="cover"
              source={require("../assets/cap.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={styles.frameParent}>
        <Pressable
          style={styles.frameGroup}
          onPress={() => navigation.goBack()}
        >
          <Image
            style={styles.frameChild}
            contentFit="cover"
            source={require("../assets/frame-164.png")}
          />
          <View style={styles.motDePasseOubliWrapper}>
            <Text style={[styles.motDePasse, styles.timeTypo]}>
              Mot de passe oublié
            </Text>
          </View>
        </Pressable>
        <View
          style={[
            styles.entrerVotreAdresseEmailPouWrapper,
            styles.wrapperSpaceBlock,
          ]}
        >
          <Text style={[styles.entrerVotreAdresse, styles.frameItemTypo]}>
            Entrer votre adresse Email pour recupérer votre mot de passe
          </Text>
        </View>
        <View style={styles.wrapperSpaceBlock}>
          <TextInput
            style={[styles.frameItem, styles.frameItemTypo]}
            placeholder="Email"
            placeholderTextColor="#d9d9d9"
          />
        </View>
        <View style={styles.wrapperSpaceBlock}>
          <Pressable
            style={styles.button}
            onPress={() => navigation.navigate("OTPVerification")}
          >
            <View style={[styles.buttonContainer, styles.wrapperFlexBox]}>
              <Text style={styles.button1}>Envoyer OTP</Text>
            </View>
          </Pressable>
        </View>
      </View>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  stattusBarLayout: {
    display: "none",
    width: 375,
  },
  wrapperFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  timeTypo: {
    textAlign: "center",
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    lineHeight: 22,
  },
  borderPosition: {
    left: "50%",
    position: "absolute",
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  wrapperSpaceBlock: {
    marginTop: 28,
    padding: Padding.p_3xs,
  },
  frameItemTypo: {
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  time: {
    fontSize: FontSize.size_mid,
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    paddingVertical: Padding.p_3xs,
    height: 44,
    justifyContent: "center",
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderStyle: "solid",
    borderColor: Color.labelsPrimary,
    borderWidth: 1,
    width: 25,
    opacity: 0.35,
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    width: 27,
    height: 13,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
    height: 44,
    justifyContent: "center",
  },
  stattusBar: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  frameChild: {
    width: 24,
    height: 24,
  },
  motDePasse: {
    fontSize: FontSize.size_5xl,
  },
  motDePasseOubliWrapper: {
    marginLeft: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  frameGroup: {
    flexDirection: "row",
    alignItems: "center",
  },
  entrerVotreAdresse: {
    fontSize: FontSize.size_base,
    color: Color.textDark,
    width: 327,
    textAlign: "left",
    lineHeight: 22,
    fontWeight: "500",
  },
  entrerVotreAdresseEmailPouWrapper: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  frameItem: {
    fontSize: FontSize.subtitleBold14_size,
  },
  button1: {
    fontSize: FontSize.size_xl,
    color: Color.frame1,
    textAlign: "left",
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  buttonContainer: {
    borderRadius: Border.br_9xs,
    backgroundColor: Color.color2,
    height: 48,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_7xs,
    flex: 1,
  },
  button: {
    width: 327,
    flexDirection: "row",
  },
  frameParent: {
    marginTop: 10,
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
    marginTop: 10,
  },
  forgetPassword: {
    backgroundColor: Color.color1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    paddingHorizontal: Padding.p_sm,
    paddingVertical: Padding.p_56xl,
    alignItems: "center",
    flex: 1,
  },
});

export default ForgetPassword;
