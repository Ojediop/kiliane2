import * as React from "react";
import { StyleSheet, View, Text, Pressable, TextInput } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Padding, FontFamily, Border, FontSize } from "../GlobalStyles";

const SetNewPassword = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.setNewPassword, styles.wrapperFlexBox]}>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
      <View style={[styles.stattusBar, styles.stattusBarLayout]}>
        <View style={[styles.timeWrapper, styles.timeWrapperSpaceBlock]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
        </View>
        <View style={styles.cellularConnectionParent}>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection2.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi2.png")}
          />
          <View style={styles.battery}>
            <View style={[styles.border, styles.borderPosition]} />
            <Image
              style={[styles.capIcon, styles.borderPosition]}
              contentFit="cover"
              source={require("../assets/cap1.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={styles.frameParent}>
        <View style={styles.frameGroup}>
          <Pressable
            style={[styles.frameContainer, styles.stattusBarFlexBox]}
            onPress={() => navigation.goBack()}
          >
            <Pressable
              style={styles.wrapper}
              onPress={() =>
                navigation.navigate("BottomTabsRoot", { screen: "Profile" })
              }
            >
              <Image
                style={styles.icon}
                contentFit="cover"
                source={require("../assets/frame-178.png")}
              />
            </Pressable>
            <View
              style={[
                styles.modifierLeMotDePasseWrapper,
                styles.stattusBarFlexBox,
              ]}
            >
              <Text style={[styles.modifierLeMot, styles.timeTypo]}>
                Modifier le mot de passe
              </Text>
            </View>
          </Pressable>
          <View
            style={[
              styles.crerUnNouveauMotDePasseWrapper,
              styles.wrapperSpaceBlock,
            ]}
          >
            <Text style={[styles.crerUnNouveau, styles.titleTypo]}>
              Créer un nouveau mot de passe
            </Text>
          </View>
          <View style={styles.wrapperSpaceBlock}>
            <View>
              <Text style={[styles.title, styles.titleTypo]}>Mot de passe</Text>
              <TextInput
                style={[styles.instanceChild, styles.buttonLayout]}
                secureTextEntry={true}
              />
            </View>
          </View>
          <View style={styles.wrapperSpaceBlock}>
            <View>
              <Text style={[styles.title, styles.titleTypo]}>
                Confirmer mot de passe
              </Text>
              <TextInput
                style={[styles.instanceChild, styles.buttonLayout]}
                secureTextEntry={true}
              />
            </View>
          </View>
        </View>
        <View style={styles.buttonWrapper}>
          <Pressable
            style={styles.buttonLayout}
            onPress={() => navigation.navigate("Done")}
          >
            <View style={[styles.buttonContainer, styles.instanceChildLayout]}>
              <Text style={styles.button1}>Continuer</Text>
            </View>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
  },
  stattusBarLayout: {
    display: "none",
    width: 375,
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  timeWrapperSpaceBlock: {
    paddingVertical: Padding.p_3xs,
    height: 44,
  },
  timeTypo: {
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    lineHeight: 22,
    textAlign: "center",
  },
  borderPosition: {
    left: "50%",
    position: "absolute",
  },
  stattusBarFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  wrapperSpaceBlock: {
    marginTop: 28,
    padding: Padding.p_3xs,
  },
  titleTypo: {
    color: Color.textDark,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    lineHeight: 22,
  },
  buttonLayout: {
    width: 327,
    flexDirection: "row",
  },
  instanceChildLayout: {
    borderRadius: Border.br_9xs,
    alignItems: "center",
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
  },
  time: {
    fontSize: FontSize.size_mid,
    textAlign: "center",
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderColor: Color.labelsPrimary,
    borderWidth: 1,
    width: 25,
    opacity: 0.35,
    borderStyle: "solid",
    height: "100%",
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    width: 27,
    height: 13,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  stattusBar: {
    justifyContent: "space-between",
    marginLeft: 10,
    alignItems: "center",
    flexDirection: "row",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    width: 24,
    height: 24,
  },
  modifierLeMot: {
    fontSize: 23,
    textAlign: "center",
  },
  modifierLeMotDePasseWrapper: {
    marginLeft: 10,
    alignItems: "center",
  },
  frameContainer: {
    alignItems: "center",
  },
  crerUnNouveau: {
    fontSize: FontSize.size_lg,
    textAlign: "left",
  },
  crerUnNouveauMotDePasseWrapper: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  title: {
    fontSize: FontSize.size_base,
    textAlign: "center",
  },
  instanceChild: {
    borderColor: Color.grey,
    borderWidth: 2,
    paddingHorizontal: Padding.p_xs,
    marginTop: 8,
    borderRadius: Border.br_9xs,
    alignItems: "center",
    borderStyle: "solid",
    paddingVertical: Padding.p_3xs,
    height: 44,
  },
  frameGroup: {
    alignItems: "center",
  },
  button1: {
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.montserratBold,
    color: Color.frame1,
    textAlign: "left",
  },
  buttonContainer: {
    backgroundColor: Color.color,
    height: 48,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_7xs,
    justifyContent: "center",
    flexDirection: "row",
    flex: 1,
  },
  buttonWrapper: {
    marginTop: 261,
    padding: Padding.p_3xs,
  },
  frameParent: {
    marginLeft: 10,
  },
  setNewPassword: {
    backgroundColor: Color.color1,
    height: 812,
    overflow: "hidden",
    paddingHorizontal: Padding.p_sm,
    paddingVertical: Padding.p_51xl,
    alignItems: "center",
    width: "100%",
    flex: 1,
    justifyContent: "center",
  },
});

export default SetNewPassword;
