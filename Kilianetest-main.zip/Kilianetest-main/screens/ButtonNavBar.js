import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View } from "react-native";
import { Padding, Color, Border } from "../GlobalStyles";

const ButtonNavBar = () => {
  return (
    <View style={styles.buttonNavBar}>
      <View style={[styles.property1home, styles.property1homeShadowBox]}>
        <Image
          style={[styles.homeLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/home-light.png")}
        />
        <Image
          style={[styles.chatAltLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/chat-alt-light.png")}
        />
        <Image
          style={[styles.userLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/user-light.png")}
        />
        <Image
          style={[styles.property1homeChild, styles.childPosition]}
          contentFit="cover"
          source={require("../assets/line-1.png")}
        />
      </View>
      <View style={[styles.property1review, styles.property1homeShadowBox]}>
        <Image
          style={[styles.homeLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/home-light1.png")}
        />
        <Image
          style={[styles.chatAltLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/chat-alt-light1.png")}
        />
        <Image
          style={[styles.userLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/user-light.png")}
        />
        <Image
          style={[styles.property1reviewChild, styles.childPosition]}
          contentFit="cover"
          source={require("../assets/line-1.png")}
        />
      </View>
      <View style={[styles.property1profil, styles.property1homeShadowBox]}>
        <Image
          style={[styles.homeLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/home-light1.png")}
        />
        <Image
          style={[styles.chatAltLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/chat-alt-light.png")}
        />
        <Image
          style={[styles.userLightIcon, styles.lightIconLayout]}
          contentFit="cover"
          source={require("../assets/user-light1.png")}
        />
        <Image
          style={[styles.property1profilChild, styles.childPosition]}
          contentFit="cover"
          source={require("../assets/line-1.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  property1homeShadowBox: {
    paddingVertical: Padding.p_xl,
    paddingHorizontal: Padding.p_11xl,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
    width: 349,
    backgroundColor: Color.colorSaddlebrown,
    borderRadius: Border.br_17xl,
    shadowOpacity: 1,
    elevation: 12,
    shadowRadius: 12,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 20,
    position: "absolute",
  },
  lightIconLayout: {
    height: 41,
    width: 41,
  },
  childPosition: {
    zIndex: 3,
    height: 1,
    width: 34,
    top: 64,
    position: "absolute",
  },
  homeLightIcon: {
    zIndex: 0,
  },
  chatAltLightIcon: {
    zIndex: 1,
  },
  userLightIcon: {
    zIndex: 2,
  },
  property1homeChild: {
    left: 35,
  },
  property1home: {
    top: 20,
  },
  property1reviewChild: {
    left: 159,
  },
  property1review: {
    top: 121,
  },
  property1profilChild: {
    left: 282,
  },
  property1profil: {
    top: 222,
  },
  buttonNavBar: {
    borderRadius: Border.br_8xs,
    borderStyle: "dashed",
    borderColor: "#9747ff",
    borderWidth: 1,
    flex: 1,
    width: "100%",
    height: 323,
    overflow: "hidden",
  },
});

export default ButtonNavBar;
