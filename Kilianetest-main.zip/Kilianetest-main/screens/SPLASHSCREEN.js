import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Color, FontSize, FontFamily, Padding, Border } from "../GlobalStyles";

const SPLASHSCREEN = () => {
  return (
    <View style={styles.splashScreen}>
      <View style={[styles.stattusBar, styles.stattusBarFlexBox]}>
        <View style={[styles.timeWrapper, styles.timeWrapperFlexBox]}>
          <Text style={[styles.time, styles.timeFlexBox]}>9:41</Text>
        </View>
        <View
          style={[styles.cellularConnectionParent, styles.timeWrapperFlexBox]}
        >
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <View style={styles.battery}>
            <View style={[styles.border, styles.borderPosition]} />
            <Image
              style={[styles.capIcon, styles.borderPosition]}
              contentFit="cover"
              source={require("../assets/cap.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={styles.frameParent}>
        <View style={[styles.kilianeWrapper, styles.stattusBarFlexBox]}>
          <Text style={[styles.kiliane, styles.timeFlexBox]}>KILIANE</Text>
        </View>
        <View style={[styles.frameGroup, styles.groupLayout]}>
          <View style={[styles.groupParent, styles.groupLayout]}>
            <Image
              style={styles.frameChild}
              contentFit="cover"
              source={require("../assets/group-1.png")}
            />
            <Image
              style={styles.frameItem}
              contentFit="cover"
              source={require("../assets/group-2.png")}
            />
          </View>
          <View style={styles.frameInner} />
        </View>
        <View style={[styles.starParent, styles.stattusBarFlexBox]}>
          <Image
            style={styles.starIcon}
            contentFit="cover"
            source={require("../assets/star1.png")}
          />
          <Image
            style={[styles.starIcon1, styles.starIconSpaceBlock]}
            contentFit="cover"
            source={require("../assets/star2.png")}
          />
          <Image
            style={[styles.starIcon2, styles.starIconSpaceBlock]}
            contentFit="cover"
            source={require("../assets/star1.png")}
          />
          <Image
            style={[styles.starIcon1, styles.starIconSpaceBlock]}
            contentFit="cover"
            source={require("../assets/star2.png")}
          />
          <Image
            style={[styles.starIcon2, styles.starIconSpaceBlock]}
            contentFit="cover"
            source={require("../assets/star1.png")}
          />
        </View>
      </View>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  stattusBarFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  timeWrapperFlexBox: {
    height: 44,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  timeFlexBox: {
    textAlign: "center",
    lineHeight: 22,
  },
  borderPosition: {
    left: "50%",
    position: "absolute",
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  groupLayout: {
    height: 11,
    alignItems: "center",
  },
  starIconSpaceBlock: {
    marginLeft: 10,
    height: 20,
  },
  stattusBarLayout: {
    width: 375,
    display: "none",
  },
  time: {
    fontSize: FontSize.size_mid,
    fontWeight: "600",
    fontFamily: FontFamily.montserratSemiBold,
    color: Color.labelsPrimary,
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    paddingVertical: Padding.p_3xs,
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderStyle: "solid",
    borderColor: Color.labelsPrimary,
    borderWidth: 1,
    width: 25,
    opacity: 0.35,
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    width: 27,
    height: 13,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
  },
  stattusBar: {
    display: "none",
    justifyContent: "space-between",
    width: 375,
  },
  kiliane: {
    fontSize: FontSize.size_29xl,
    fontWeight: "900",
    fontFamily: FontFamily.ralewayBlack,
    color: Color.color,
  },
  kilianeWrapper: {
    height: 42,
    padding: Padding.p_3xs,
    alignSelf: "stretch",
    justifyContent: "center",
  },
  frameChild: {
    width: 93,
    height: 103,
  },
  frameItem: {
    height: 39,
    marginTop: 24,
    width: 204,
  },
  groupParent: {
    width: 204,
    display: "none",
  },
  frameInner: {
    borderRadius: Border.br_31xl,
    backgroundColor: Color.color,
    width: 180,
    height: 4,
  },
  frameGroup: {
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  starIcon: {
    height: 20,
    width: 20,
  },
  starIcon1: {
    width: 21,
  },
  starIcon2: {
    width: 20,
    marginLeft: 10,
  },
  starParent: {
    alignSelf: "stretch",
    justifyContent: "center",
  },
  frameParent: {
    height: 99,
    marginTop: 13,
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
    marginTop: 13,
    display: "none",
  },
  splashScreen: {
    borderRadius: 20,
    backgroundColor: Color.color1,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    paddingHorizontal: 76,
    paddingVertical: 277,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default SPLASHSCREEN;
