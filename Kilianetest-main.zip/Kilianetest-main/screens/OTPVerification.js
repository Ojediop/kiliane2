import * as React from "react";
import { Text, StyleSheet, View, Pressable, TextInput } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Border, Padding, FontSize } from "../GlobalStyles";

const OTPVerification = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.otpVerification}>
      <View style={[styles.stattusBar, styles.stattusBarLayout]}>
        <View style={[styles.timeWrapper, styles.timeWrapperFlexBox]}>
          <Text style={[styles.time, styles.timeFlexBox]}>9:41</Text>
        </View>
        <View
          style={[styles.cellularConnectionParent, styles.timeWrapperFlexBox]}
        >
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <View style={styles.battery}>
            <View style={styles.border} />
            <Image
              style={styles.capIcon}
              contentFit="cover"
              source={require("../assets/cap.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={styles.frameParent}>
        <View>
          <Pressable
            style={styles.frameContainer}
            onPress={() => navigation.goBack()}
          >
            <Image
              style={styles.frameChild}
              contentFit="cover"
              source={require("../assets/frame-164.png")}
            />
            <View style={styles.otpVerificationWrapper}>
              <Text style={[styles.otpVerification1, styles.timeFlexBox]}>
                OTP Verification
              </Text>
            </View>
          </Pressable>
          <View
            style={[
              styles.unCodeATEnvoyDansVotrWrapper,
              styles.rectangleParentSpaceBlock,
            ]}
          >
            <Text style={[styles.unCodeA, styles.codeTypo]}>
              Un code a été envoyé dans votre adresse mail. Entrer le code pour
              continuer
            </Text>
          </View>
          <Pressable
            style={[styles.rectangleParent, styles.rectangleParentSpaceBlock]}
            onPress={() => navigation.navigate("SetNewPassword")}
          >
            <TextInput style={styles.frameLayout} />
            <TextInput style={[styles.frameInner, styles.frameLayout]} />
            <TextInput style={[styles.frameInner, styles.frameLayout]} />
            <TextInput style={[styles.frameInner, styles.frameLayout]} />
            <TextInput style={[styles.frameInner, styles.frameLayout]} />
            <TextInput style={[styles.frameInner, styles.frameLayout]} />
          </Pressable>
        </View>
        <View style={styles.frameView}>
          <View style={[styles.wrapper, styles.wrapperSpaceBlock]}>
            <Text style={styles.text}>00:59</Text>
          </View>
          <View style={[styles.wrapper, styles.wrapperSpaceBlock]}>
            <Text style={[styles.renvoyerCode, styles.codeTypo]}>
              Renvoyer code
            </Text>
          </View>
        </View>
      </View>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  stattusBarLayout: {
    display: "none",
    width: 375,
  },
  timeWrapperFlexBox: {
    justifyContent: "center",
    height: 44,
    alignItems: "center",
    flexDirection: "row",
  },
  timeFlexBox: {
    textAlign: "center",
    color: Color.labelsPrimary,
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  rectangleParentSpaceBlock: {
    marginTop: 37,
    flexDirection: "row",
  },
  codeTypo: {
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    lineHeight: 22,
  },
  frameLayout: {
    height: 60,
    width: 50,
    borderColor: Color.grey,
    borderRadius: Border.br_9xs,
    borderWidth: 1,
    borderStyle: "solid",
  },
  wrapperSpaceBlock: {
    padding: Padding.p_3xs,
    alignItems: "center",
  },
  time: {
    fontSize: FontSize.size_mid,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    lineHeight: 22,
    color: Color.labelsPrimary,
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    paddingVertical: Padding.p_3xs,
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderColor: Color.labelsPrimary,
    width: 25,
    opacity: 0.35,
    borderWidth: 1,
    borderStyle: "solid",
    left: "50%",
    position: "absolute",
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
    left: "50%",
    position: "absolute",
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    width: 27,
    height: 13,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
  },
  stattusBar: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
  frameChild: {
    width: 24,
    height: 24,
  },
  otpVerification1: {
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    lineHeight: 22,
    color: Color.labelsPrimary,
  },
  otpVerificationWrapper: {
    marginLeft: 10,
    alignItems: "center",
    flexDirection: "row",
  },
  frameContainer: {
    alignItems: "center",
    flexDirection: "row",
  },
  unCodeA: {
    fontSize: FontSize.size_lg,
    color: Color.textDark,
    textAlign: "left",
    width: 327,
  },
  unCodeATEnvoyDansVotrWrapper: {
    padding: Padding.p_3xs,
    alignItems: "center",
  },
  frameInner: {
    marginLeft: 11,
  },
  rectangleParent: {
    width: 355,
  },
  text: {
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.robotoMonoMedium,
    fontWeight: "500",
    textAlign: "center",
    color: Color.labelsPrimary,
    lineHeight: 22,
  },
  wrapper: {
    flexDirection: "row",
  },
  renvoyerCode: {
    fontSize: FontSize.subtitleBold14_size,
    textDecoration: "underline",
    textAlign: "center",
    color: Color.labelsPrimary,
  },
  frameView: {
    marginTop: 14,
    alignItems: "center",
  },
  frameParent: {
    marginTop: 10,
    alignItems: "center",
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
    marginTop: 10,
  },
  otpVerification: {
    backgroundColor: Color.color1,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    paddingHorizontal: Padding.p_sm,
    paddingVertical: Padding.p_56xl,
  },
});

export default OTPVerification;
