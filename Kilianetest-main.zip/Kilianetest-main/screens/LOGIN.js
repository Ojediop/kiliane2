import * as React from "react";
import { StyleSheet, View, Text, TextInput, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, Padding, FontFamily, Border, FontSize } from "../GlobalStyles";

const LOGIN = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.login, styles.wrapperFlexBox]}>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
      <View style={[styles.stattusBar, styles.stattusBarSpaceBlock]}>
        <View style={[styles.timeWrapper, styles.timeWrapperSpaceBlock]}>
          <Text style={[styles.time, styles.timeFlexBox]}>9:41</Text>
        </View>
        <View style={styles.cellularConnectionParent}>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection1.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi2.png")}
          />
          <View style={styles.battery}>
            <View style={[styles.border, styles.borderPosition]} />
            <Image
              style={[styles.capIcon, styles.borderPosition]}
              contentFit="cover"
              source={require("../assets/cap1.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={[styles.frameParent, styles.stattusBarSpaceBlock]}>
        <View style={[styles.connectezVousWrapper, styles.wrapperFlexBox]}>
          <Text style={[styles.connectezVous, styles.timeFlexBox]}>
            Connectez Vous
          </Text>
        </View>
        <View style={styles.frameGroup}>
          <View style={styles.frameContainer}>
            <View style={styles.frameView}>
              <View>
                <View>
                  <View>
                    <Text style={[styles.title, styles.titleTypo]}>Email</Text>
                    <TextInput
                      style={[
                        styles.instanceChild,
                        styles.instanceChildSpaceBlock,
                      ]}
                      placeholder="entrez votre email"
                      placeholderTextColor="#d9d9d9"
                    />
                  </View>
                </View>
                <View style={styles.instanceContainer}>
                  <View>
                    <Text style={[styles.title, styles.titleTypo]}>
                      Mot de passe
                    </Text>
                    <TextInput
                      style={[
                        styles.instanceChild,
                        styles.instanceChildSpaceBlock,
                      ]}
                      placeholder="entrez mot de passe"
                      secureTextEntry={true}
                      placeholderTextColor="#d9d9d9"
                    />
                  </View>
                </View>
              </View>
              <View
                style={[
                  styles.motDePasseOubliWrapper,
                  styles.instanceChildSpaceBlock,
                ]}
              >
                <Pressable
                  onPress={() => navigation.navigate("ForgetPassword")}
                >
                  <Text
                    style={[styles.motDePasseOubli, styles.senregistrerClr]}
                  >
                    Mot de passe oublié ?
                  </Text>
                </Pressable>
              </View>
            </View>
            <View style={styles.buttonWrapper}>
              <Pressable
                style={styles.button}
                onPress={() =>
                  navigation.navigate("BottomTabsRoot", { screen: "HomePage1" })
                }
              >
                <View
                  style={[styles.buttonContainer, styles.instanceChildLayout]}
                >
                  <Text style={styles.button1}>Se connecter</Text>
                </View>
              </Pressable>
            </View>
          </View>
          <View
            style={[
              styles.ouContinuerAvecWrapper,
              styles.iconGoogleParentFlexBox,
            ]}
          >
            <Text style={[styles.ouContinuerAvec, styles.textTypo]}>
              ou continuer avec
            </Text>
          </View>
          <View
            style={[styles.iconGoogleParent, styles.iconGoogleParentFlexBox]}
          >
            <Image
              style={styles.iconGoogle}
              contentFit="cover"
              source={require("../assets/icon-google.png")}
            />
            <Image
              style={styles.iconFb}
              contentFit="cover"
              source={require("../assets/icon-fb.png")}
            />
            <Image
              style={styles.iconApple}
              contentFit="cover"
              source={require("../assets/icon-apple.png")}
            />
          </View>
          <View
            style={[
              styles.ouContinuerAvecWrapper,
              styles.iconGoogleParentFlexBox,
            ]}
          >
            <Pressable onPress={() => navigation.navigate("REGISTER")}>
              <Text style={[styles.text, styles.textTypo]}>
                <Text
                  style={styles.vousNavezPas}
                >{`Vous n’avez pas de compte ? `}</Text>
                <Text style={styles.senregistrerClr}>S’enregistrer</Text>
              </Text>
            </Pressable>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperFlexBox: {
    justifyContent: "center",
    flexDirection: "row",
  },
  stattusBarLayout: {
    display: "none",
    width: 375,
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  stattusBarSpaceBlock: {
    marginLeft: 10,
    alignItems: "center",
  },
  timeWrapperSpaceBlock: {
    paddingVertical: Padding.p_3xs,
    height: 44,
  },
  timeFlexBox: {
    textAlign: "center",
    lineHeight: 22,
  },
  borderPosition: {
    left: "50%",
    position: "absolute",
  },
  titleTypo: {
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textAlign: "center",
    lineHeight: 22,
  },
  instanceChildSpaceBlock: {
    marginTop: 8,
    flexDirection: "row",
  },
  senregistrerClr: {
    color: Color.color2,
    textDecoration: "underline",
  },
  instanceChildLayout: {
    borderRadius: Border.br_9xs,
    alignItems: "center",
  },
  iconGoogleParentFlexBox: {
    marginTop: 17,
    justifyContent: "center",
    flexDirection: "row",
  },
  textTypo: {
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
  },
  time: {
    fontSize: FontSize.size_mid,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    textAlign: "center",
    lineHeight: 22,
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderColor: Color.labelsPrimary,
    borderWidth: 1,
    width: 25,
    opacity: 0.35,
    borderStyle: "solid",
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    width: 27,
    height: 13,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  stattusBar: {
    justifyContent: "space-between",
    display: "none",
    width: 375,
    flexDirection: "row",
  },
  connectezVous: {
    fontSize: FontSize.size_5xl,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    textAlign: "center",
    lineHeight: 22,
  },
  connectezVousWrapper: {
    padding: Padding.p_3xs,
    alignItems: "center",
  },
  title: {
    fontSize: FontSize.size_base,
    color: Color.textDark,
  },
  instanceChild: {
    borderColor: Color.grey,
    borderWidth: 2,
    paddingHorizontal: Padding.p_xs,
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    width: 327,
    borderRadius: Border.br_9xs,
    alignItems: "center",
    borderStyle: "solid",
    paddingVertical: Padding.p_3xs,
    height: 44,
  },
  instanceContainer: {
    marginTop: 12,
  },
  motDePasseOubli: {
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textAlign: "center",
    lineHeight: 22,
  },
  motDePasseOubliWrapper: {
    alignItems: "flex-end",
  },
  frameView: {
    alignItems: "flex-end",
  },
  button1: {
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.montserratBold,
    color: Color.frame1,
    textAlign: "left",
  },
  buttonContainer: {
    backgroundColor: Color.color,
    height: 48,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_7xs,
    justifyContent: "center",
    flexDirection: "row",
    flex: 1,
  },
  button: {
    width: 327,
    flexDirection: "row",
  },
  buttonWrapper: {
    marginTop: 2,
    padding: Padding.p_3xs,
  },
  frameContainer: {
    alignItems: "center",
  },
  ouContinuerAvec: {
    textAlign: "center",
    lineHeight: 22,
    color: Color.labelsPrimary,
    fontSize: FontSize.subtitleBold14_size,
  },
  ouContinuerAvecWrapper: {
    padding: Padding.p_3xs,
    alignItems: "center",
  },
  iconGoogle: {
    height: 32,
    width: 32,
  },
  iconFb: {
    width: 33,
    marginLeft: 32,
    height: 32,
  },
  iconApple: {
    height: 38,
    marginLeft: 32,
    width: 32,
  },
  iconGoogleParent: {
    alignItems: "flex-end",
  },
  vousNavezPas: {
    color: Color.labelsPrimary,
  },
  text: {
    textAlign: "center",
    lineHeight: 22,
    fontSize: FontSize.subtitleBold14_size,
  },
  frameGroup: {
    marginTop: 82,
    alignItems: "center",
  },
  frameParent: {
    justifyContent: "flex-end",
  },
  login: {
    backgroundColor: Color.color1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    paddingHorizontal: Padding.p_sm,
    paddingVertical: 114,
    alignItems: "flex-end",
    flex: 1,
    justifyContent: "center",
  },
});

export default LOGIN;
