import * as React from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Pressable,
  TextInput,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Padding, Border } from "../GlobalStyles";

const HomePage1 = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.homePage, styles.homeWrapperFlexBox]}>
      <ScrollView
        style={styles.frameParent}
        showsVerticalScrollIndicator={true}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollViewContent}
      >
        <View style={[styles.vectorParent, styles.parentFrameSpaceBlock]}>
          <Image
            style={styles.frameChild}
            contentFit="cover"
            source={require("../assets/ellipse-102.png")}
          />
          <Text style={[styles.bonjourMoussa, styles.bonjourTypo]}>
            Bonjour moussa
          </Text>
          <Image
            style={[styles.notificationIcon, styles.notificationIconLayout]}
            contentFit="cover"
            source={require("../assets/notification2.png")}
          />
          <View style={styles.component8}>
            <Text style={[styles.goodMorning, styles.goodMorningTypo]}>
              good morning
            </Text>
            <Text style={[styles.stayHealthy, styles.goodMorningTypo]}>
              stay healthy
            </Text>
          </View>
          <View style={styles.frameGroup}>
            <Pressable
              style={styles.frameContainer}
              onPress={() =>
                navigation.navigate("BottomTabsRoot", { screen: "Profile" })
              }
            >
              <View style={styles.maskGroupWrapper}>
                <Image
                  style={styles.maskGroupIcon}
                  contentFit="cover"
                  source={require("../assets/mask-group36.png")}
                />
              </View>
              <View style={styles.bonjourMoussaWrapper}>
                <Text style={[styles.bonjourMoussa1, styles.bonjourTypo]}>
                  Bonjour moussa
                </Text>
              </View>
            </Pressable>
            <View style={styles.frameWrapper}>
              <View style={styles.frameView}>
                <View style={styles.notificationWrapper}>
                  <Image
                    style={styles.notificationIconLayout}
                    contentFit="cover"
                    source={require("../assets/notification3.png")}
                  />
                </View>
                <Image
                  style={styles.frameItem}
                  contentFit="cover"
                  source={require("../assets/frame-280.png")}
                />
              </View>
            </View>
          </View>
          <View style={[styles.homePageWrapper, styles.parentFrameSpaceBlock]}>
            <TextInput
              style={styles.homePage1}
              placeholder="”MIMS”"
              placeholderTextColor="#000"
            />
          </View>
          <Image
            style={[styles.frameInner, styles.groupIconLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-9.png")}
          />
        </View>
        <View style={[styles.instanceWrapper, styles.homeWrapperFlexBox]}>
          <View style={[styles.frameWrapper1, styles.maskGroupLayout]}>
            <View style={[styles.maskGroupParent, styles.frameInnerPosition]}>
              <Image
                style={styles.maskGroupLayout}
                contentFit="cover"
                source={require("../assets/mask-group37.png")}
              />
              <Image
                style={[styles.maskGroupIcon2, styles.maskGroupLayout]}
                contentFit="cover"
                source={require("../assets/mask-group38.png")}
              />
              <Image
                style={[styles.maskGroupIcon2, styles.maskGroupLayout]}
                contentFit="cover"
                source={require("../assets/mask-group39.png")}
              />
              <Image
                style={[styles.maskGroupIcon2, styles.maskGroupLayout]}
                contentFit="cover"
                source={require("../assets/mask-group40.png")}
              />
              <Image
                style={[styles.maskGroupIcon2, styles.maskGroupLayout]}
                contentFit="cover"
                source={require("../assets/mask-group41.png")}
              />
            </View>
          </View>
        </View>
        <View style={[styles.frameParent1, styles.parentFrameSpaceBlock]}>
          <View style={styles.servicesWrapper}>
            <Text style={[styles.services, styles.servicesClr]}>Services</Text>
          </View>
          <Pressable
            style={styles.voirToutWrapper}
            onPress={() => navigation.navigate("AllServices")}
          >
            <Text style={[styles.voirTout, styles.voirTypo]}>Voir tout</Text>
          </Pressable>
        </View>
        <View style={styles.frameWrapper2}>
          <View style={[styles.frameParent2, styles.frameParentFlexBox]}>
            <Pressable
              style={styles.maskGroupGroup}
              onPress={() => navigation.navigate("Service")}
            >
              <Image
                style={styles.maskGroupIcon6}
                contentFit="cover"
                source={require("../assets/mask-group42.png")}
              />
              <Text style={[styles.hotel, styles.hotelTypo]}>Hotel</Text>
            </Pressable>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon6}
                contentFit="cover"
                source={require("../assets/mask-group43.png")}
              />
              <Text style={[styles.hotel, styles.hotelTypo]}>Banque</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon6}
                contentFit="cover"
                source={require("../assets/mask-group44.png")}
              />
              <Text style={[styles.hotel, styles.hotelTypo]}>Restaurant</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon6}
                contentFit="cover"
                source={require("../assets/mask-group45.png")}
              />
              <Text style={[styles.hotel, styles.hotelTypo]}>Clinique</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon6}
                contentFit="cover"
                source={require("../assets/mask-group46.png")}
              />
              <Text style={[styles.hotel, styles.hotelTypo]}>dentiste</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon6}
                contentFit="cover"
                source={require("../assets/mask-group47.png")}
              />
              <Text style={[styles.hotel, styles.hotelTypo]}>gynecologe</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon6}
                contentFit="cover"
                source={require("../assets/mask-group48.png")}
              />
              <Text style={[styles.hotel, styles.hotelTypo]}>Fast Food</Text>
            </View>
            <View>
              <Image
                style={styles.maskGroupIcon6}
                contentFit="cover"
                source={require("../assets/mask-group49.png")}
              />
              <Text style={[styles.hotel, styles.hotelTypo]}>
                Pret à porter
              </Text>
            </View>
          </View>
        </View>
        <View style={[styles.frameParent3, styles.hospitalsFlexBox]}>
          <View style={styles.lesMieuxNotsWrapper}>
            <Text style={[styles.services, styles.servicesClr]}>
              les mieux notés
            </Text>
          </View>
          <Pressable
            style={styles.voirToutWrapper}
            onPress={() => navigation.navigate("Top1")}
          >
            <Text style={[styles.voirTout, styles.voirTypo]}>Voir tout</Text>
          </Pressable>
        </View>
        <Pressable
          style={[styles.framePressable, styles.parentFrameSpaceBlock]}
          onPress={() => navigation.navigate("AddReview")}
        >
          <Image
            style={styles.maskGroupIcon14}
            contentFit="cover"
            source={require("../assets/mask-group50.png")}
          />
          <View style={[styles.frameWrapper3, styles.frameFlexBox1]}>
            <View style={styles.frameParent4}>
              <View style={styles.frameParent5}>
                <View style={styles.frameParent5}>
                  <View style={styles.frameParent7}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star13.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool8.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.hotelTypo]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </Pressable>
        <View style={[styles.framePressable, styles.parentFrameSpaceBlock]}>
          <Image
            style={styles.maskGroupIcon14}
            contentFit="cover"
            source={require("../assets/mask-group51.png")}
          />
          <View style={[styles.frameWrapper3, styles.frameFlexBox1]}>
            <View style={styles.frameParent4}>
              <View style={styles.frameParent5}>
                <View style={styles.frameParent5}>
                  <View style={styles.frameParent7}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star14.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool9.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.hotelTypo]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.framePressable, styles.parentFrameSpaceBlock]}>
          <Image
            style={styles.maskGroupIcon14}
            contentFit="cover"
            source={require("../assets/mask-group52.png")}
          />
          <View style={[styles.frameWrapper3, styles.frameFlexBox1]}>
            <View style={styles.frameParent4}>
              <View style={styles.frameParent5}>
                <View style={styles.frameParent5}>
                  <View style={styles.frameParent7}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star15.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool10.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.hotelTypo]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.framePressable, styles.parentFrameSpaceBlock]}>
          <Image
            style={styles.maskGroupIcon14}
            contentFit="cover"
            source={require("../assets/mask-group53.png")}
          />
          <View style={[styles.frameWrapper3, styles.frameFlexBox1]}>
            <View style={styles.frameParent4}>
              <View style={styles.frameParent5}>
                <View style={styles.frameParent5}>
                  <View style={styles.frameParent7}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star16.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool11.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.hotelTypo]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.framePressable, styles.parentFrameSpaceBlock]}>
          <Image
            style={styles.maskGroupIcon14}
            contentFit="cover"
            source={require("../assets/mask-group54.png")}
          />
          <View style={[styles.frameWrapper3, styles.frameFlexBox1]}>
            <View style={styles.frameParent4}>
              <View style={styles.frameParent5}>
                <View style={styles.frameParent5}>
                  <View style={styles.frameParent7}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star17.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool12.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.hotelTypo]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.framePressable, styles.parentFrameSpaceBlock]}>
          <Image
            style={styles.maskGroupIcon14}
            contentFit="cover"
            source={require("../assets/mask-group55.png")}
          />
          <View style={[styles.frameWrapper3, styles.frameFlexBox1]}>
            <View style={styles.frameParent4}>
              <View style={styles.frameParent5}>
                <View style={styles.frameParent5}>
                  <View style={styles.frameParent7}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star18.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool13.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.hotelTypo]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <ScrollView
          style={styles.frameScrollview}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={true}
          contentContainerStyle={styles.frameScrollView1Content}
        >
          <View style={[styles.frameParent28, styles.frameParentFlexBox]}>
            <View style={styles.quelquesAvisWrapper}>
              <Text style={[styles.quelquesAvis, styles.voirTout2Typo]}>
                Quelques Avis
              </Text>
            </View>
            <Pressable
              style={[styles.frameWrapper9, styles.frameFlexBox]}
              onPress={() =>
                navigation.navigate("BottomTabsRoot", { screen: "AllReviews" })
              }
            >
              <View style={[styles.voirToutFrame, styles.frameFlexBox]}>
                <Text style={[styles.voirTout2, styles.voirTout2Typo]}>
                  Voir tout
                </Text>
              </View>
            </Pressable>
          </View>
          <View style={[styles.hospitals, styles.hospitalsFlexBox]}>
            <Pressable
              style={styles.maskGroupBg}
              onPress={() => navigation.navigate("Review")}
            >
              <Image
                style={styles.maskGroupIcon20}
                contentFit="cover"
                source={require("../assets/mask-group.png")}
              />
              <Text style={[styles.laGondole, styles.servicesClr]}>
                la gondole
              </Text>
              <Text style={[styles.westHamNorth, styles.hotelTypo]}>
                west ham, north England
              </Text>
              <Image
                style={[styles.toolIcon6, styles.toolIconLayout]}
                contentFit="cover"
                source={require("../assets/tool.png")}
              />
              <Text style={[styles.westHamNorth, styles.hotelTypo]}>
                5km away from your location
              </Text>
              <Image
                style={[styles.groupIcon, styles.groupIconLayout]}
                contentFit="cover"
                source={require("../assets/group-572.png")}
              />
            </Pressable>
            <View style={[styles.maskGroupParent13, styles.maskGroupBg]}>
              <Image
                style={styles.maskGroupIcon20}
                contentFit="cover"
                source={require("../assets/mask-group.png")}
              />
              <Text style={[styles.laGondole, styles.servicesClr]}>
                la gondole
              </Text>
              <Text style={[styles.westHamNorth, styles.hotelTypo]}>
                west ham, north England
              </Text>
              <Image
                style={[styles.toolIcon6, styles.toolIconLayout]}
                contentFit="cover"
                source={require("../assets/tool.png")}
              />
              <Text style={[styles.westHamNorth, styles.hotelTypo]}>
                5km away from your location
              </Text>
              <Image
                style={[styles.groupIcon, styles.groupIconLayout]}
                contentFit="cover"
                source={require("../assets/group-572.png")}
              />
            </View>
            <View style={[styles.maskGroupParent13, styles.maskGroupBg]}>
              <Image
                style={styles.maskGroupIcon20}
                contentFit="cover"
                source={require("../assets/mask-group.png")}
              />
              <Text style={[styles.laGondole, styles.servicesClr]}>
                la gondole
              </Text>
              <Text style={[styles.westHamNorth, styles.hotelTypo]}>
                west ham, north England
              </Text>
              <Image
                style={[styles.toolIcon6, styles.toolIconLayout]}
                contentFit="cover"
                source={require("../assets/tool.png")}
              />
              <Text style={[styles.westHamNorth, styles.hotelTypo]}>
                5km away from your location
              </Text>
              <Image
                style={[styles.groupIcon, styles.groupIconLayout]}
                contentFit="cover"
                source={require("../assets/group-572.png")}
              />
            </View>
          </View>
        </ScrollView>
      </ScrollView>
      <View style={[styles.homePageChild, styles.frameInnerPosition]} />
    </View>
  );
};

const styles = StyleSheet.create({
  frameScrollView1Content: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  frameScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-between",
  },
  homeWrapperFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  parentFrameSpaceBlock: {
    paddingVertical: 0,
    alignSelf: "stretch",
  },
  bonjourTypo: {
    textAlign: "left",
    textTransform: "capitalize",
    fontWeight: "500",
  },
  notificationIconLayout: {
    height: 20,
    width: 20,
  },
  goodMorningTypo: {
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_smi_7,
    opacity: 0.7,
    textAlign: "left",
    color: Color.colorDarkslategray_100,
    textTransform: "capitalize",
  },
  groupIconLayout: {
    width: 9,
    display: "none",
  },
  maskGroupLayout: {
    height: 151,
    width: 330,
  },
  frameInnerPosition: {
    top: 0,
    position: "absolute",
  },
  servicesClr: {
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratMedium,
  },
  voirTypo: {
    color: Color.color,
    fontFamily: FontFamily.poppinsMedium,
    fontSize: FontSize.size_xs,
  },
  frameParentFlexBox: {
    paddingHorizontal: Padding.p_xl,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  hotelTypo: {
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkslategray_200,
    textAlign: "left",
    textTransform: "capitalize",
  },
  hospitalsFlexBox: {
    width: 375,
    flexDirection: "row",
    paddingVertical: 0,
    alignItems: "center",
  },
  frameFlexBox1: {
    flexWrap: "wrap",
    flex: 1,
  },
  text1Typo: {
    color: Color.colorTeal,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    textAlign: "left",
    textTransform: "capitalize",
  },
  textTypo: {
    marginTop: 4,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textTransform: "capitalize",
  },
  wrapperFlexBox: {
    marginTop: 6,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  voirTout2Typo: {
    textAlign: "center",
    fontWeight: "500",
    textTransform: "capitalize",
  },
  frameFlexBox: {
    width: 71,
    flexDirection: "row",
    alignItems: "center",
  },
  toolIconLayout: {
    width: 10,
    opacity: 0.7,
    height: 10,
  },
  maskGroupBg: {
    backgroundColor: Color.colorWhitesmoke_100,
    borderRadius: Border.br_3xs,
    padding: Padding.p_3xs,
  },
  buttonFlexBox: {
    width: 349,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  lightLayout: {
    width: 41,
    height: 41,
  },
  frameChild: {
    width: 11,
    height: 10,
    zIndex: 0,
  },
  bonjourMoussa: {
    marginTop: 1,
    zIndex: 1,
    display: "none",
    color: Color.colorDarkslategray_100,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    textTransform: "capitalize",
    fontSize: FontSize.subtitleBold14_size,
  },
  notificationIcon: {
    zIndex: 2,
    marginTop: 1,
    display: "none",
  },
  goodMorning: {
    opacity: 0.7,
  },
  stayHealthy: {
    marginTop: 6.3,
    opacity: 0.7,
  },
  component8: {
    height: 13,
    zIndex: 3,
    marginTop: 1,
    display: "none",
    overflow: "hidden",
  },
  maskGroupIcon: {
    width: 31,
    height: 31,
  },
  maskGroupWrapper: {
    flexDirection: "row",
  },
  bonjourMoussa1: {
    color: Color.colorDarkslategray_100,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    textTransform: "capitalize",
    fontSize: FontSize.subtitleBold14_size,
  },
  bonjourMoussaWrapper: {
    padding: Padding.p_3xs,
    flexDirection: "row",
    alignItems: "center",
  },
  frameContainer: {
    width: 173,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  notificationWrapper: {
    padding: Padding.p_3xs,
    flexDirection: "row",
    zIndex: 0,
  },
  frameItem: {
    top: 1,
    left: 11,
    width: 29,
    height: 29,
    position: "absolute",
    zIndex: 1,
  },
  frameView: {
    flexDirection: "row",
  },
  frameWrapper: {
    width: 40,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  frameGroup: {
    width: 331,
    zIndex: 4,
    justifyContent: "space-between",
    flexDirection: "row",
    marginTop: 1,
    alignItems: "center",
  },
  homePage1: {
    height: 41,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.subtitleBold14_size,
    alignSelf: "stretch",
  },
  homePageWrapper: {
    zIndex: 5,
    paddingHorizontal: Padding.p_3xs,
    marginTop: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  frameInner: {
    left: 321,
    height: 9,
    zIndex: 6,
    top: 0,
    position: "absolute",
  },
  vectorParent: {
    height: 113,
    paddingHorizontal: Padding.p_lgi,
    alignItems: "center",
    backgroundColor: Color.labelColorDarkPrimary,
  },
  maskGroupIcon2: {
    marginLeft: 20,
  },
  maskGroupParent: {
    left: 0,
    flexDirection: "row",
  },
  frameWrapper1: {
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowRadius: 10,
    elevation: 10,
    borderRadius: Border.br_3xs,
    height: 151,
    width: 330,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    overflow: "hidden",
    backgroundColor: Color.labelColorDarkPrimary,
  },
  instanceWrapper: {
    padding: Padding.p_3xs,
    alignSelf: "stretch",
  },
  services: {
    fontSize: FontSize.defaultBoldSubheadline_size,
    color: Color.labelsPrimary,
    textAlign: "left",
    textTransform: "capitalize",
    fontWeight: "500",
  },
  servicesWrapper: {
    width: 83,
    padding: Padding.p_3xs,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  voirTout: {
    textAlign: "left",
    textTransform: "capitalize",
    fontWeight: "500",
  },
  voirToutWrapper: {
    width: 74,
    padding: Padding.p_3xs,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  frameParent1: {
    paddingHorizontal: Padding.p_11xl,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  maskGroupIcon6: {
    width: 70,
    height: 70,
  },
  hotel: {
    marginTop: 12,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.poppinsMedium,
    fontSize: FontSize.size_3xs,
    fontWeight: "500",
  },
  maskGroupGroup: {
    alignItems: "center",
  },
  frameParent2: {
    paddingVertical: Padding.p_5xs,
    flexWrap: "wrap",
    flex: 1,
  },
  frameWrapper2: {
    height: 245,
    justifyContent: "space-between",
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  lesMieuxNotsWrapper: {
    width: 145,
    padding: Padding.p_3xs,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  frameParent3: {
    paddingHorizontal: Padding.p_base,
    justifyContent: "space-between",
  },
  maskGroupIcon14: {
    width: 93,
    height: 99,
  },
  seaPlaza: {
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  seaPlazaWrapper: {
    padding: Padding.p_3xs,
    flexDirection: "row",
  },
  starIcon: {
    width: 15,
    height: 15,
  },
  text: {
    fontSize: FontSize.size_2xs_3,
    color: Color.colorDarkslategray_200,
  },
  rating: {
    fontSize: FontSize.size_6xs_9,
    color: Color.colorSteelblue,
    opacity: 0.7,
  },
  starParent: {
    width: 24,
    alignItems: "flex-end",
  },
  frameParent7: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  text1: {
    fontSize: FontSize.size_xs,
  },
  wrapper: {
    padding: Padding.p_3xs,
  },
  frameParent5: {
    alignSelf: "stretch",
  },
  accueilseaplazateyliomcom: {
    fontSize: FontSize.size_2xs,
  },
  routeCornicheOuest: {
    lineHeight: 13,
    width: 181,
    marginLeft: 10,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    fontSize: FontSize.size_3xs,
  },
  toolParent: {
    opacity: 0.7,
  },
  frameParent4: {
    flex: 1,
  },
  frameWrapper3: {
    height: 132,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  framePressable: {
    paddingHorizontal: Padding.p_3xs,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  quelquesAvis: {
    width: 125,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratMedium,
    fontSize: FontSize.defaultBoldSubheadline_size,
  },
  quelquesAvisWrapper: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  voirTout2: {
    width: 68,
    color: Color.color,
    fontFamily: FontFamily.poppinsMedium,
    fontSize: FontSize.size_xs,
  },
  voirToutFrame: {
    justifyContent: "flex-end",
  },
  frameWrapper9: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
    justifyContent: "space-between",
  },
  frameParent28: {
    paddingVertical: 0,
    alignSelf: "stretch",
  },
  maskGroupIcon20: {
    width: 200,
    height: 110,
  },
  laGondole: {
    marginTop: 10,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    textTransform: "capitalize",
    fontWeight: "500",
  },
  westHamNorth: {
    fontFamily: FontFamily.montserratRegular,
    marginTop: 10,
    color: Color.colorDarkslategray_200,
    display: "none",
  },
  toolIcon6: {
    marginTop: 10,
    display: "none",
  },
  groupIcon: {
    height: 8,
    marginTop: 10,
    opacity: 0.7,
  },
  maskGroupParent13: {
    marginLeft: 10,
  },
  hospitals: {
    paddingHorizontal: Padding.p_3xs,
  },
  frameScrollview: {
    alignSelf: "stretch",
    flex: 1,
  },
  frameParent: {
    zIndex: 0,
    alignSelf: "stretch",
    flex: 1,
  },
  homePageChild: {
    left: 1,
    width: 373,
    height: 55,
    zIndex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Color.labelColorDarkPrimary,
  },
  homePage: {
    overflow: "hidden",
    width: "100%",
    flex: 1,
    backgroundColor: Color.labelColorDarkPrimary,
  },
});

export default HomePage1;
