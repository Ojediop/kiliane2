import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { Padding, Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Profile = () => {
  return (
    <View style={[styles.profile, styles.frameParentFlexBox]}>
      <View style={[styles.frameParent, styles.frameParentPosition]}>
        <View style={[styles.rectangleParent, styles.vectorWrapperSpaceBlock]}>
          <View style={styles.frameChild} />
          <View style={styles.report}>
            <View style={[styles.reportChild, styles.reportLayout]} />
            <View style={[styles.reportItem, styles.reportItemPosition]} />
            <View style={[styles.reportInner, styles.reportLayout]} />
          </View>
          <Text style={styles.profile1}>profile</Text>
          <Image
            style={[styles.statusBarIcon, styles.barPosition]}
            contentFit="cover"
            source={require("../assets/status-bar1.png")}
          />
        </View>
        <View style={styles.frameWrapper}>
          <View style={styles.frameGroup}>
            <View style={styles.maskGroupWrapper}>
              <Image
                style={styles.maskGroupIcon}
                contentFit="cover"
                source={require("../assets/mask-group21.png")}
              />
            </View>
            <View style={styles.frameContainer}>
              <View style={styles.moussaWrapper}>
                <Text style={styles.moussa}>Moussa</Text>
              </View>
              <View style={styles.moussaWrapper}>
                <Text style={[styles.text, styles.textTypo]}>
                  +221 77 000 00 00
                </Text>
              </View>
              <View style={styles.moussaWrapper}>
                <Text style={[styles.text, styles.textTypo]}>Dakar</Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.frameView, styles.frameParentFlexBox]}>
          <View
            style={[styles.changerDePhotoWrapper, styles.changerWrapperBorder]}
          >
            <Text style={[styles.changerDePhoto, styles.textTypo]}>
              Changer de photo
            </Text>
          </View>
          <View style={[styles.changerNomWrapper, styles.changerWrapperBorder]}>
            <Text style={[styles.changerDePhoto, styles.textTypo]}>
              changer nom
            </Text>
          </View>
        </View>
        <View style={[styles.frameParent1, styles.frameParentFlexBox]}>
          <View style={[styles.mesAvisParent, styles.frameParentFlexBox]}>
            <Text style={[styles.mesAvis, styles.textTypo]}>mes avis</Text>
            <Image
              style={styles.nextIconLayout}
              contentFit="cover"
              source={require("../assets/next.png")}
            />
          </View>
          <View style={styles.notificationsParent}>
            <Text style={[styles.mesAvis, styles.textTypo]}>notifications</Text>
            <Image
              style={[styles.nextIcon1, styles.nextIconLayout]}
              contentFit="cover"
              source={require("../assets/next1.png")}
            />
          </View>
          <View style={styles.notificationsParent}>
            <Text style={[styles.mesAvis, styles.textTypo]}>
              changer contact
            </Text>
            <Image
              style={[styles.nextIcon2, styles.nextIconLayout]}
              contentFit="cover"
              source={require("../assets/next2.png")}
            />
          </View>
          <View style={styles.notificationsParent}>
            <Text style={[styles.mesAvis, styles.textTypo]}>
              changer location
            </Text>
            <Image
              style={[styles.nextIcon3, styles.nextIconLayout]}
              contentFit="cover"
              source={require("../assets/next3.png")}
            />
          </View>
          <View style={styles.notificationsParent}>
            <Text style={[styles.mesAvis, styles.textTypo]}>
              changer mot de pass
            </Text>
            <Image
              style={[styles.nextIcon4, styles.nextIconLayout]}
              contentFit="cover"
              source={require("../assets/next4.png")}
            />
          </View>
          <View style={styles.notificationsParent}>
            <Text style={[styles.mesAvis, styles.textTypo]}>reglages</Text>
            <Image
              style={[styles.nextIcon5, styles.nextIconLayout]}
              contentFit="cover"
              source={require("../assets/next5.png")}
            />
          </View>
          <View style={styles.notificationsParent}>
            <Text style={[styles.mesAvis, styles.textTypo]}>FAQs</Text>
            <Image
              style={[styles.nextIcon6, styles.nextIconLayout]}
              contentFit="cover"
              source={require("../assets/next6.png")}
            />
          </View>
          <View style={styles.notificationsParent}>
            <Text style={[styles.mesAvis, styles.textTypo]}>
              a propos de nous
            </Text>
            <Image
              style={[styles.nextIcon7, styles.nextIconLayout]}
              contentFit="cover"
              source={require("../assets/next7.png")}
            />
          </View>
        </View>
        <View style={styles.frameWrapper1}>
          <View style={styles.notificationsParent}>
            <View style={styles.moussaWrapper}>
              <Text style={[styles.seDconnecter, styles.textTypo]}>
                se déconnecter
              </Text>
            </View>
            <View style={styles.exitParent}>
              <Image
                style={styles.exitIcon}
                contentFit="cover"
                source={require("../assets/exit.png")}
              />
              <Image
                style={styles.frameItem}
                contentFit="cover"
                source={require("../assets/vector-4.png")}
              />
            </View>
          </View>
        </View>
      </View>
      <View style={[styles.rectangleGroup, styles.groupLayout]}>
        <View style={[styles.groupChild, styles.groupLayout]} />
        <View style={[styles.homeSignParent, styles.reportItemPosition]}>
          <Image
            style={[styles.homeSignIcon, styles.iconChildPosition]}
            contentFit="cover"
            source={require("../assets/home-sign1.png")}
          />
          <Text style={styles.home}>home</Text>
        </View>
        <View style={[styles.calendarParent, styles.parentLayout]}>
          <Image
            style={[styles.calendarIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/calendar1.png")}
          />
          <Text style={[styles.myAppointments, styles.allTypo]}>
            my appointments
          </Text>
        </View>
        <View style={[styles.doctorParent, styles.allDoctorsLayout]}>
          <Image
            style={[styles.doctorIcon, styles.iconPosition]}
            contentFit="cover"
            source={require("../assets/doctor1.png")}
          />
          <Text style={[styles.allDoctors, styles.allDoctorsLayout]}>
            all doctors
          </Text>
        </View>
        <View style={[styles.hospitalParent, styles.allHospitalsLayout]}>
          <Image
            style={[styles.hospitalIcon, styles.iconChildPosition]}
            contentFit="cover"
            source={require("../assets/hospital1.png")}
          />
          <Text style={[styles.allHospitals, styles.allHospitalsLayout]}>
            all hospitals
          </Text>
        </View>
        <View style={[styles.userParent, styles.profile2Layout]}>
          <Image
            style={[styles.userIcon, styles.iconChildPosition]}
            contentFit="cover"
            source={require("../assets/user1.png")}
          />
          <Text style={[styles.profile2, styles.profile2Layout]}>profile</Text>
        </View>
        <Image
          style={styles.groupItem}
          contentFit="cover"
          source={require("../assets/rectangle-106.png")}
        />
        <View style={[styles.groupInner, styles.groupInnerBg]} />
        <View style={[styles.rectangleView, styles.groupInnerBg]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameParentFlexBox: {
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
  frameParentPosition: {
    right: 25,
    zIndex: 0,
    position: "absolute",
    justifyContent: "space-between",
    alignItems: "center",
  },
  vectorWrapperSpaceBlock: {
    padding: Padding.p_3xs,
    flexDirection: "row",
  },
  reportLayout: {
    backgroundColor: Color.grey,
    height: 3,
    left: 0,
    width: 3,
  },
  reportItemPosition: {
    top: 7,
    position: "absolute",
  },
  barPosition: {
    zIndex: 3,
    position: "absolute",
  },
  textTypo: {
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textAlign: "left",
    textTransform: "capitalize",
  },
  changerWrapperBorder: {
    paddingVertical: Padding.p_xs,
    borderColor: Color.color2,
    backgroundColor: Color.color,
    borderRadius: Border.br_3xs,
    borderWidth: 2,
    borderStyle: "solid",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  nextIconLayout: {
    height: 15,
    width: 10,
  },
  groupLayout: {
    width: 375,
    height: 91,
  },
  iconChildPosition: {
    top: 0,
    position: "absolute",
  },
  parentLayout: {
    height: 32,
    top: 10,
    display: "none",
  },
  iconPosition: {
    height: 21,
    top: 0,
    position: "absolute",
  },
  allTypo: {
    fontSize: FontSize.size_5xs,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    textTransform: "capitalize",
    left: 0,
  },
  allDoctorsLayout: {
    width: 44,
    position: "absolute",
  },
  allHospitalsLayout: {
    width: 51,
    position: "absolute",
  },
  profile2Layout: {
    width: 47,
    position: "absolute",
  },
  groupInnerBg: {
    backgroundColor: Color.labelsPrimary,
    display: "none",
    position: "absolute",
  },
  buttonFlexBox: {
    width: 349,
    justifyContent: "space-between",
    alignItems: "center",
    flexDirection: "row",
  },
  homeLayout: {
    height: 41,
    width: 41,
  },
  chatLayout: {
    height: 0,
    borderRadius: Border.br_11xs,
    right: "37.6%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  frameChild: {
    backgroundColor: Color.colorSteelblue,
    width: 360,
    height: 90,
    display: "none",
    zIndex: 0,
  },
  reportChild: {
    height: 3,
    top: 0,
    position: "absolute",
  },
  reportItem: {
    height: 3,
    backgroundColor: Color.grey,
    left: 0,
    width: 3,
  },
  reportInner: {
    top: 14,
    height: 3,
    position: "absolute",
  },
  report: {
    left: 327,
    height: 17,
    zIndex: 1,
    width: 3,
    top: 2,
    display: "none",
    position: "absolute",
  },
  profile1: {
    fontWeight: "700",
    fontFamily: FontFamily.montserratBold,
    zIndex: 2,
    textAlign: "left",
    textTransform: "capitalize",
    fontSize: FontSize.size_base,
    color: Color.color,
    left: 0,
    top: 0,
    position: "absolute",
  },
  statusBarIcon: {
    top: -40,
    width: 344,
    height: 16,
    left: 0,
    display: "none",
  },
  rectangleParent: {
    width: 53,
    height: 20,
  },
  maskGroupIcon: {
    maxHeight: "100%",
    maxWidth: "100%",
    alignSelf: "stretch",
    overflow: "hidden",
    width: "100%",
    flex: 1,
  },
  maskGroupWrapper: {
    width: 85,
    height: 85,
    flexDirection: "row",
  },
  moussa: {
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textAlign: "left",
    textTransform: "capitalize",
    fontSize: FontSize.size_base,
  },
  moussaWrapper: {
    justifyContent: "center",
    padding: Padding.p_3xs,
    alignItems: "center",
    flexDirection: "row",
  },
  text: {
    opacity: 0.6,
    color: Color.colorDarkslategray_200,
  },
  frameContainer: {
    marginLeft: 5,
    alignSelf: "stretch",
    flex: 1,
  },
  frameGroup: {
    width: 324,
    height: 91,
    left: 0,
    top: 0,
    position: "absolute",
    flexDirection: "row",
  },
  frameWrapper: {
    alignSelf: "stretch",
    flex: 1,
  },
  changerDePhoto: {
    color: Color.labelColorDarkPrimary,
  },
  changerDePhotoWrapper: {
    paddingHorizontal: 11,
  },
  changerNomWrapper: {
    paddingHorizontal: 25,
  },
  frameView: {
    alignSelf: "stretch",
    flex: 1,
  },
  mesAvis: {
    color: Color.colorDarkslategray_200,
  },
  mesAvisParent: {
    width: 309,
  },
  nextIcon1: {
    marginLeft: 208,
  },
  notificationsParent: {
    alignItems: "center",
    flexDirection: "row",
  },
  nextIcon2: {
    marginLeft: 177,
  },
  nextIcon3: {
    marginLeft: 172,
  },
  nextIcon4: {
    marginLeft: 145,
  },
  nextIcon5: {
    marginLeft: 233,
  },
  nextIcon6: {
    marginLeft: 261,
  },
  nextIcon7: {
    marginLeft: 170,
  },
  frameParent1: {
    height: 345,
    flexWrap: "wrap",
    paddingHorizontal: 0,
    paddingVertical: Padding.p_5xs,
    alignSelf: "stretch",
  },
  seDconnecter: {
    color: Color.color,
    fontSize: FontSize.subtitleBold14_size,
  },
  exitIcon: {
    width: 20,
    height: 20,
    zIndex: 0,
  },
  frameItem: {
    left: 2,
    width: 13,
    height: 18,
    zIndex: 1,
    top: 2,
    position: "absolute",
  },
  exitParent: {
    marginLeft: 170,
    flexDirection: "row",
  },
  frameWrapper1: {
    height: 30,
    alignSelf: "stretch",
  },
  frameParent: {
    bottom: 156,
    height: 577,
    zIndex: 0,
    left: 26,
  },
  groupChild: {
    backgroundColor: Color.frame1,
    borderColor: Color.colorSteelblue,
    borderWidth: 0.5,
    borderStyle: "solid",
    left: 0,
    top: 0,
    position: "absolute",
  },
  homeSignIcon: {
    width: 48,
    height: 43,
    left: 0,
  },
  home: {
    top: 50,
    left: 6,
    width: 45,
    height: 10,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_smi,
    textAlign: "left",
    textTransform: "capitalize",
    position: "absolute",
  },
  homeSignParent: {
    left: 48,
    width: 50,
    height: 60,
  },
  calendarIcon: {
    width: 24,
    left: 26,
  },
  myAppointments: {
    top: 26,
    fontSize: FontSize.size_5xs,
    width: 73,
    position: "absolute",
  },
  calendarParent: {
    left: 80,
    width: 73,
    position: "absolute",
  },
  doctorIcon: {
    left: 12,
    width: 22,
  },
  allDoctors: {
    top: 27,
    fontSize: FontSize.size_5xs,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    textTransform: "capitalize",
    left: 0,
  },
  doctorParent: {
    left: 168,
    height: 33,
    top: 9,
    display: "none",
  },
  hospitalIcon: {
    left: 15,
    width: 23,
    height: 20,
  },
  allHospitals: {
    fontSize: FontSize.size_5xs,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    textTransform: "capitalize",
    left: 0,
    top: 26,
  },
  hospitalParent: {
    left: 239,
    height: 32,
    top: 10,
    display: "none",
  },
  userIcon: {
    width: 39,
    height: 38,
    left: 0,
  },
  profile2: {
    top: 49,
    height: 11,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_smi,
    width: 47,
    textAlign: "left",
    color: Color.color,
    textTransform: "capitalize",
    left: 0,
  },
  userParent: {
    left: 299,
    top: 9,
    height: 60,
  },
  groupItem: {
    top: 19,
    left: 119,
    width: 8,
    height: 7,
    display: "none",
    position: "absolute",
  },
  groupInner: {
    top: 13,
    left: 110,
    width: 14,
    height: 3,
  },
  rectangleView: {
    top: 18,
    left: 259,
    width: 9,
    height: 7,
  },
  rectangleGroup: {
    zIndex: 1,
    display: "none",
  },
  profile: {
    backgroundColor: Color.labelColorDarkPrimary,
    height: 812,
    overflow: "hidden",
    justifyContent: "space-between",
    width: "100%",
    flex: 1,
  },
});

export default Profile;
