import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize, Padding } from "../GlobalStyles";

const Review = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.review}>
      <View style={styles.statusBarIphoneXOrNewe}>
        <Image
          style={styles.notchIcon}
          contentFit="cover"
          source={require("../assets/notch2.png")}
        />
        <View style={[styles.rightSide, styles.iconLayout]}>
          <Image
            style={styles.batteryIcon}
            contentFit="cover"
            source={require("../assets/battery.png")}
          />
          <Image
            style={[styles.wifiIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/wifi1.png")}
          />
          <Image
            style={[styles.mobileSignalIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/mobile-signal.png")}
          />
        </View>
        <View style={styles.leftSide}>
          <View style={styles.time}>
            <Text style={styles.text}>9:41</Text>
          </View>
        </View>
      </View>
      <View style={[styles.divblock, styles.divblockSpaceBlock]}>
        <View style={styles.row}>
          <View style={styles.rating}>
            <View style={styles.row1}>
              <Text style={[styles.text1, styles.textFlexBox]}>5</Text>
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <View style={[styles.space, styles.spaceLayout]} />
            </View>
            <View style={styles.row2}>
              <Text style={[styles.text1, styles.textFlexBox]}>4</Text>
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <View style={[styles.space1, styles.spaceLayout]} />
            </View>
            <View style={styles.row2}>
              <Text style={[styles.text1, styles.textFlexBox]}>3</Text>
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <View style={[styles.space2, styles.spaceLayout]} />
            </View>
            <View style={styles.row2}>
              <Text style={[styles.text1, styles.textFlexBox]}>2</Text>
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <View style={[styles.space3, styles.spaceLayout]} />
            </View>
            <View style={styles.row2}>
              <Text style={[styles.text1, styles.textFlexBox]}>1</Text>
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <View style={[styles.space4, styles.spaceLayout]} />
            </View>
          </View>
          <View style={styles.rating1}>
            <Text style={[styles.text6, styles.text6Typo]}>4.0</Text>
            <View style={styles.row6}>
              <Image
                style={styles.rowChildLayout}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-1.png")}
              />
              <Image
                style={[styles.rowChild, styles.rowChildLayout]}
                contentFit="cover"
                source={require("../assets/star-5.png")}
              />
            </View>
            <Text style={[styles.avis, styles.avisTypo]}>15 Avis</Text>
          </View>
        </View>
        <View style={styles.row7}>
          <View style={[styles.divblock1, styles.divblock1FlexBox]}>
            <View style={styles.div}>
              <Image
                style={styles.logoIcon}
                contentFit="cover"
                source={require("../assets/logo.png")}
              />
              <View style={styles.text7}>
                <Text style={[styles.doudou, styles.doudouTypo]}>Doudou</Text>
                <View style={styles.row8}>
                  <Image
                    style={styles.rowChildLayout}
                    contentFit="cover"
                    source={require("../assets/star-11.png")}
                  />
                  <Image
                    style={[styles.rowChild, styles.rowChildLayout]}
                    contentFit="cover"
                    source={require("../assets/star-11.png")}
                  />
                  <Image
                    style={[styles.rowChild, styles.rowChildLayout]}
                    contentFit="cover"
                    source={require("../assets/star-11.png")}
                  />
                  <Image
                    style={[styles.rowChild, styles.rowChildLayout]}
                    contentFit="cover"
                    source={require("../assets/star-11.png")}
                  />
                  <Image
                    style={[styles.rowChild, styles.rowChildLayout]}
                    contentFit="cover"
                    source={require("../assets/star-11.png")}
                  />
                  <Text style={[styles.ilYA, styles.textFlexBox]}>
                    il y a 2 min
                  </Text>
                </View>
              </View>
            </View>
            <Image
              style={[styles.icons, styles.iconsLayout]}
              contentFit="cover"
              source={require("../assets/icons1.png")}
            />
          </View>
          <Text style={styles.lePersonnelDe}>
            Le personnel de l'hôtel était incroyablement accueillant et
            serviable. Ils étaient toujours prêts à répondre à nos demandes et à
            nous aider à organiser nos activités locales.
          </Text>
        </View>
        <View style={styles.space5} />
        <View style={styles.row7}>
          <View style={[styles.divblock1, styles.divblock1FlexBox]}>
            <View style={styles.div}>
              <Image
                style={styles.logoIcon}
                contentFit="cover"
                source={require("../assets/logo1.png")}
              />
              <View style={styles.text7}>
                <Text style={[styles.doudou, styles.doudouTypo]}>Natalie</Text>
                <View style={styles.row8}>
                  <Image
                    style={styles.rowChildLayout}
                    contentFit="cover"
                    source={require("../assets/star-12.png")}
                  />
                  <Image
                    style={[styles.rowChild, styles.rowChildLayout]}
                    contentFit="cover"
                    source={require("../assets/star-12.png")}
                  />
                  <Image
                    style={[styles.rowChild, styles.rowChildLayout]}
                    contentFit="cover"
                    source={require("../assets/star-12.png")}
                  />
                  <Image
                    style={[styles.rowChild, styles.rowChildLayout]}
                    contentFit="cover"
                    source={require("../assets/star-12.png")}
                  />
                  <Image
                    style={[styles.rowChild, styles.rowChildLayout]}
                    contentFit="cover"
                    source={require("../assets/star-51.png")}
                  />
                  <Text style={[styles.ilYA, styles.textFlexBox]}>
                    il y a 40 min
                  </Text>
                </View>
              </View>
            </View>
            <Image
              style={[styles.icons, styles.iconsLayout]}
              contentFit="cover"
              source={require("../assets/icons2.png")}
            />
          </View>
          <Text style={styles.lePersonnelDe}>
            Nous avons été impressionnés par le niveau de propreté de l'hôtel.
            Notre chambre était impeccablement entretenue.
          </Text>
        </View>
        <View style={styles.space5} />
      </View>
      <Pressable
        style={[styles.bottomNavigation, styles.divblockSpaceBlock]}
        onPress={() => navigation.navigate("AddReview")}
      >
        <Pressable
          style={styles.primaryButtondefault}
          onPress={() => navigation.navigate("AddReview")}
        >
          <Image
            style={[styles.icons2, styles.iconsLayout]}
            contentFit="cover"
            source={require("../assets/icons3.png")}
          />
          <Text style={[styles.donnerUnAvis, styles.text6Typo]}>
            Donner un avis
          </Text>
          <Image
            style={[styles.icons3, styles.iconsLayout]}
            contentFit="cover"
            source={require("../assets/icons3.png")}
          />
        </Pressable>
        <View style={styles.homeIndicator} />
      </Pressable>
      <View style={[styles.menuProfile, styles.menuProfilePosition]}>
        <Pressable
          style={styles.iconsLayout}
          onPress={() =>
            navigation.navigate("BottomTabsRoot", { screen: "HomePage1" })
          }
        >
          <Image
            style={styles.icon}
            contentFit="cover"
            source={require("../assets/frame-319.png")}
          />
        </Pressable>
        <View style={styles.hotelRadissonWrapper}>
          <Text style={[styles.hotelRadisson, styles.doudouTypo]}>
            Hotel Radisson
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    height: 11,
    position: "absolute",
  },
  divblockSpaceBlock: {
    marginTop: 18,
    alignItems: "center",
  },
  textFlexBox: {
    textAlign: "right",
    color: Color.colorDarkslategray_200,
  },
  rowChildLayout: {
    height: 16,
    width: 16,
    borderRadius: Border.br_12xs,
  },
  spaceLayout: {
    height: 6,
    borderRadius: Border.br_9xs,
    backgroundColor: Color.color,
    marginLeft: 4,
  },
  text6Typo: {
    fontFamily: FontFamily.subtitleBold14,
    fontWeight: "700",
  },
  avisTypo: {
    fontFamily: FontFamily.mulishSemiBold,
    fontWeight: "600",
    alignSelf: "stretch",
  },
  divblock1FlexBox: {
    alignItems: "flex-end",
    flexDirection: "row",
  },
  doudouTypo: {
    letterSpacing: -0.2,
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.colorDarkslategray_200,
  },
  iconsLayout: {
    height: 24,
    width: 24,
  },
  menuProfilePosition: {
    zIndex: 3,
    position: "absolute",
  },
  buttonFlexBox: {
    width: 349,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  lightLayout: {
    height: 41,
    width: 41,
  },
  notchIcon: {
    marginLeft: -109.5,
    top: -2,
    left: "50%",
    width: 219,
    height: 30,
    position: "absolute",
    display: "none",
  },
  batteryIcon: {
    right: 0,
    width: 24,
    top: 0,
    height: 11,
    position: "absolute",
  },
  wifiIcon: {
    right: 29,
    width: 15,
    top: 0,
  },
  mobileSignalIcon: {
    right: 50,
    width: 17,
    top: 0,
  },
  rightSide: {
    top: 17,
    right: 15,
    width: 67,
  },
  text: {
    top: 1,
    fontSize: FontSize.defaultBoldSubheadline_size,
    letterSpacing: 0,
    lineHeight: 20,
    textAlign: "center",
    height: 20,
    color: Color.labelColorDarkPrimary,
    fontFamily: FontFamily.mulishMedium,
    fontWeight: "500",
    left: 0,
    width: 54,
    position: "absolute",
  },
  time: {
    borderRadius: Border.br_5xl,
    backgroundColor: Color.colorMediumseagreen,
    left: 0,
    height: 21,
    width: 54,
    top: 0,
    position: "absolute",
  },
  leftSide: {
    top: 12,
    left: 16,
    height: 21,
    width: 54,
    position: "absolute",
  },
  statusBarIphoneXOrNewe: {
    width: 375,
    height: 44,
    zIndex: 0,
    display: "none",
    overflow: "hidden",
  },
  text1: {
    letterSpacing: -0.1,
    textAlign: "right",
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.mulishMedium,
    fontWeight: "500",
  },
  rowChild: {
    marginLeft: 4,
  },
  space: {
    width: 151,
  },
  row1: {
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  space1: {
    width: 106,
  },
  row2: {
    marginTop: 8,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  space2: {
    width: 60,
  },
  space3: {
    width: 19,
  },
  space4: {
    width: 6,
  },
  rating: {
    justifyContent: "center",
    flex: 1,
  },
  text6: {
    fontSize: 40,
    letterSpacing: -0.4,
    textAlign: "right",
    color: Color.colorDarkslategray_200,
    alignSelf: "stretch",
  },
  row6: {
    marginTop: 8,
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "flex-end",
    alignItems: "center",
  },
  avis: {
    marginTop: 8,
    textAlign: "right",
    color: Color.colorDarkslategray_200,
    letterSpacing: -0.1,
    fontSize: FontSize.subtitleBold14_size,
  },
  rating1: {
    marginLeft: 24,
    justifyContent: "center",
  },
  row: {
    backgroundColor: "#f8f8f8",
    paddingHorizontal: Padding.p_5xs,
    paddingVertical: Padding.p_xs,
    flexDirection: "row",
    borderRadius: Border.br_5xs,
    alignSelf: "stretch",
  },
  logoIcon: {
    width: 38,
    height: 38,
    display: "none",
  },
  doudou: {
    textAlign: "left",
    fontFamily: FontFamily.mulishSemiBold,
    fontWeight: "600",
    alignSelf: "stretch",
  },
  ilYA: {
    marginLeft: 4,
    letterSpacing: -0.1,
    textAlign: "right",
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.mulishMedium,
    fontWeight: "500",
  },
  row8: {
    marginTop: 4,
    flexDirection: "row",
    alignSelf: "stretch",
    alignItems: "center",
  },
  text7: {
    marginLeft: 8,
    flex: 1,
  },
  div: {
    flexDirection: "row",
    flex: 1,
  },
  icons: {
    marginLeft: 16,
    overflow: "hidden",
  },
  divblock1: {
    alignSelf: "stretch",
  },
  lePersonnelDe: {
    fontSize: FontSize.size_smi,
    lineHeight: 19,
    fontFamily: FontFamily.mulishRegular,
    width: 309,
    marginTop: 12,
    textAlign: "left",
    color: Color.colorDarkslategray_200,
    letterSpacing: -0.1,
  },
  row7: {
    alignSelf: "stretch",
    justifyContent: "flex-end",
  },
  space5: {
    borderStyle: "solid",
    borderColor: Color.grey,
    borderWidth: 1,
    width: 335,
    height: 1,
  },
  divblock: {
    height: 496,
    zIndex: 1,
    justifyContent: "space-between",
    marginTop: 18,
    alignSelf: "stretch",
    overflow: "hidden",
  },
  icons2: {
    display: "none",
    overflow: "hidden",
  },
  donnerUnAvis: {
    textAlign: "left",
    marginLeft: 8,
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.subtitleBold14,
    fontWeight: "700",
    color: Color.labelColorDarkPrimary,
  },
  icons3: {
    marginLeft: 8,
    display: "none",
    overflow: "hidden",
  },
  primaryButtondefault: {
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: Padding.p_base,
    backgroundColor: Color.color,
    justifyContent: "center",
    flexDirection: "row",
    borderRadius: Border.br_5xs,
    alignSelf: "stretch",
    alignItems: "center",
    overflow: "hidden",
  },
  homeIndicator: {
    borderRadius: Border.br_81xl,
    backgroundColor: Color.colorDarkslategray_200,
    width: 134,
    height: 5,
    marginTop: 16,
    display: "none",
  },
  bottomNavigation: {
    width: 343,
    paddingBottom: 138,
    zIndex: 2,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  hotelRadisson: {
    textAlign: "left",
    fontFamily: FontFamily.subtitleBold14,
    fontWeight: "700",
    flex: 1,
  },
  hotelRadissonWrapper: {
    marginLeft: 12,
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  menuProfile: {
    left: -1,
    width: 377,
    height: 85,
    paddingHorizontal: Padding.p_sm,
    paddingVertical: 0,
    alignItems: "flex-end",
    flexDirection: "row",
    top: 0,
    backgroundColor: Color.labelColorDarkPrimary,
  },
  review: {
    height: 812,
    paddingHorizontal: Padding.p_base,
    paddingVertical: 7,
    justifyContent: "flex-end",
    alignItems: "center",
    overflow: "hidden",
    width: "100%",
    flex: 1,
    backgroundColor: Color.labelColorDarkPrimary,
  },
});

export default Review;
