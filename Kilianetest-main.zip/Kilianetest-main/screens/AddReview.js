import * as React from "react";
import { StyleSheet, View, ScrollView, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, Padding, Border, FontSize } from "../GlobalStyles";

const AddReview = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.addReview, styles.addReviewLayout]}>
      <View style={styles.addReviewChild} />
      <ScrollView
        style={styles.frameParent}
        showsVerticalScrollIndicator={true}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollViewContent}
      >
        <View style={styles.frameGroup}>
          <View style={styles.backButtonWrapper}>
            <Pressable
              style={styles.backButton}
              onPress={() => navigation.navigate("Review")}
            >
              <Image
                style={styles.iconLayout}
                contentFit="cover"
                source={require("../assets/back-button.png")}
              />
            </Pressable>
          </View>
          <View style={styles.ajoutezUnAvisWrapper}>
            <Text style={[styles.ajoutezUnAvis, styles.ajouterTypo]}>
              Ajoutez un avis
            </Text>
          </View>
        </View>
        <View style={styles.maskGroupParent}>
          <View style={styles.maskGroup}>
            <Image
              style={[styles.maskGroupChild, styles.addReviewLayout]}
              contentFit="cover"
              source={require("../assets/rectangle-35.png")}
            />
          </View>
          <View style={styles.yearExperienceParent}>
            <Text style={[styles.yearExperience, styles.fatouTypo]}>
              12 year experience
            </Text>
            <View style={[styles.frameContainer, styles.containerPosition]}>
              <View style={styles.hotelRadissonWrapper}>
                <Text style={[styles.hotelRadisson, styles.fatouTypo]}>
                  Hotel Radisson
                </Text>
              </View>
              <View style={styles.hotelRadissonWrapper}>
                <Text style={[styles.rteDeLa, styles.fatouTypo]}>
                  Rte de la Corniche O, Dakar
                </Text>
              </View>
              <View style={styles.hotelRadissonWrapper}>
                <Text style={[styles.rteDeLa, styles.fatouTypo]}>
                  33 869 33 77
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.frameView, styles.frameViewSpaceBlock]}>
          <View style={styles.frameWrapper}>
            <View style={styles.frameWrapper1}>
              <View style={styles.frameParent1}>
                <View style={styles.hotelRadissonWrapper}>
                  <Text style={[styles.total6Avis, styles.textTypo]}>
                    total 6 Avis
                  </Text>
                </View>
                <View style={[styles.container, styles.containerSpaceBlock]}>
                  <Text style={[styles.text1, styles.textTypo]}>4.0</Text>
                </View>
                <View style={styles.containerSpaceBlock}>
                  <Image
                    style={styles.starIconLayout2}
                    contentFit="cover"
                    source={require("../assets/star3.png")}
                  />
                  <Image
                    style={[styles.starIcon1, styles.starIconLayout2]}
                    contentFit="cover"
                    source={require("../assets/star3.png")}
                  />
                  <Image
                    style={[styles.starIcon1, styles.starIconLayout2]}
                    contentFit="cover"
                    source={require("../assets/star3.png")}
                  />
                  <Image
                    style={[styles.starIcon1, styles.starIconLayout2]}
                    contentFit="cover"
                    source={require("../assets/star3.png")}
                  />
                  <Image
                    style={[styles.starIcon1, styles.starIconLayout2]}
                    contentFit="cover"
                    source={require("../assets/star4.png")}
                  />
                </View>
              </View>
            </View>
          </View>
          <View style={styles.frameParent2}>
            <View style={styles.frameParentFlexBox}>
              <View style={styles.frameParent4}>
                <View style={styles.frame}>
                  <Text style={[styles.text2, styles.textTypo]}>5</Text>
                </View>
                <View>
                  <View style={styles.rectangleWrapper}>
                    <View
                      style={[styles.frameChild, styles.frameChildLayout]}
                    />
                  </View>
                  <View
                    style={[
                      styles.rectangleContainer,
                      styles.containerPosition,
                    ]}
                  >
                    <View style={[styles.frameItem, styles.frameChildLayout]} />
                  </View>
                </View>
              </View>
              <View style={[styles.votesWrapper, styles.frameViewSpaceBlock]}>
                <Text style={[styles.votes, styles.textTypo]}>4 votes</Text>
              </View>
            </View>
            <View style={styles.frameParentFlexBox}>
              <View style={styles.frameParent4}>
                <View style={styles.frame}>
                  <Text style={[styles.text2, styles.textTypo]}>4</Text>
                </View>
                <View>
                  <View style={styles.rectangleWrapper}>
                    <View
                      style={[styles.frameChild, styles.frameChildLayout]}
                    />
                  </View>
                  <View
                    style={[
                      styles.rectangleContainer,
                      styles.containerPosition,
                    ]}
                  >
                    <View
                      style={[styles.rectangleView, styles.frameChildLayout]}
                    />
                  </View>
                </View>
              </View>
              <View style={[styles.votesWrapper, styles.frameViewSpaceBlock]}>
                <Text style={[styles.votes, styles.textTypo]}>1 votes</Text>
              </View>
            </View>
            <View style={styles.frameParentFlexBox}>
              <View style={styles.frameParent4}>
                <View style={styles.frame}>
                  <Text style={[styles.text2, styles.textTypo]}>3</Text>
                </View>
                <View>
                  <View style={styles.rectangleWrapper}>
                    <View
                      style={[styles.frameChild, styles.frameChildLayout]}
                    />
                  </View>
                  <View
                    style={[
                      styles.rectangleContainer,
                      styles.containerPosition,
                    ]}
                  >
                    <View
                      style={[styles.rectangleView, styles.frameChildLayout]}
                    />
                  </View>
                </View>
              </View>
              <View style={[styles.votesWrapper, styles.frameViewSpaceBlock]}>
                <Text style={[styles.votes, styles.textTypo]}>1 votes</Text>
              </View>
            </View>
            <View style={[styles.frameParent12, styles.frameParentFlexBox]}>
              <View style={styles.frameParent4}>
                <View style={styles.frame}>
                  <Text style={[styles.text2, styles.textTypo]}>2</Text>
                </View>
                <View>
                  <View style={styles.rectangleWrapper}>
                    <View
                      style={[styles.frameChild, styles.frameChildLayout]}
                    />
                  </View>
                  <View
                    style={[styles.rectangleWrapper5, styles.containerPosition]}
                  >
                    <View
                      style={[styles.frameChild4, styles.frameChildLayout]}
                    />
                  </View>
                </View>
              </View>
              <View style={[styles.votesWrapper, styles.frameViewSpaceBlock]}>
                <Text style={[styles.votes, styles.textTypo]}>0 votes</Text>
              </View>
            </View>
            <View style={styles.frameParentFlexBox}>
              <View style={styles.frameParent4}>
                <View style={styles.frame}>
                  <Text style={[styles.text2, styles.textTypo]}>1</Text>
                </View>
                <View>
                  <View style={styles.rectangleWrapper}>
                    <View
                      style={[styles.frameChild, styles.frameChildLayout]}
                    />
                  </View>
                  <View
                    style={[styles.rectangleWrapper5, styles.containerPosition]}
                  >
                    <View
                      style={[styles.frameChild4, styles.frameChildLayout]}
                    />
                  </View>
                </View>
              </View>
              <View style={[styles.votesWrapper, styles.frameViewSpaceBlock]}>
                <Text style={[styles.votes, styles.textTypo]}>0 votes</Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.frameWrapperFlexBox}>
          <View style={styles.component44Wrapper}>
            <View style={styles.component44}>
              <Image
                style={[styles.starIcon5, styles.starIconLayout1]}
                contentFit="cover"
                source={require("../assets/star5.png")}
              />
              <Image
                style={[styles.starIcon6, styles.starIconLayout1]}
                contentFit="cover"
                source={require("../assets/star5.png")}
              />
              <Image
                style={[styles.starIcon7, styles.starIconLayout1]}
                contentFit="cover"
                source={require("../assets/star5.png")}
              />
              <Image
                style={[styles.starIcon8, styles.starIcon8Position]}
                contentFit="cover"
                source={require("../assets/star5.png")}
              />
              <Image
                style={[styles.starIcon9, styles.starIconLayout1]}
                contentFit="cover"
                source={require("../assets/star5.png")}
              />
            </View>
          </View>
        </View>
        <View style={styles.frameWrapper3}>
          <View style={styles.component44Wrapper}>
            <View style={styles.component45}>
              <View style={[styles.component45Child, styles.iconLayout]} />
              <Text
                style={[
                  styles.shareHereSomething,
                  styles.shareHereSomethingTypo,
                ]}
              >
                partagez ici vos impressions
              </Text>
            </View>
          </View>
        </View>
        <View style={[styles.frameWrapper4, styles.frameWrapperFlexBox]}>
          <Pressable
            style={styles.ajouterWrapper}
            onPress={() =>
              navigation.navigate("BottomTabsRoot", { screen: "AllReviews" })
            }
          >
            <Text style={[styles.ajouter, styles.ajouterTypo]}>Ajouter</Text>
          </Pressable>
        </View>
        <View style={styles.frameParent18}>
          <View style={styles.frameParent19}>
            <View style={styles.frameParent4}>
              <View style={styles.ellipseWrapper}>
                <Image
                  style={styles.ellipseIcon}
                  contentFit="cover"
                  source={require("../assets/ellipse-12.png")}
                />
              </View>
              <View>
                <View style={styles.hotelRadissonWrapper}>
                  <Text style={[styles.fatou, styles.fatouTypo]}>fatou</Text>
                </View>
                <View style={styles.hotelRadissonWrapper}>
                  <Text style={[styles.text7, styles.textTypo]}>
                    12/12/2023
                  </Text>
                </View>
                <View style={styles.frameParent4}>
                  <Image
                    style={styles.starIconLayout}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                  <Image
                    style={[styles.starIcon11, styles.starIconLayout]}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                  <Image
                    style={[styles.starIcon11, styles.starIconLayout]}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                  <Image
                    style={[styles.starIcon11, styles.starIconLayout]}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                  <Image
                    style={[styles.starIcon11, styles.starIconLayout]}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                </View>
              </View>
            </View>
            <Image
              style={styles.frameIcon}
              contentFit="cover"
              source={require("../assets/frame-227.png")}
            />
          </View>
          <View style={styles.responsibleForDiagnosingExWrapper}>
            <Text
              style={[
                styles.responsibleForDiagnosing,
                styles.shareHereSomethingTypo,
              ]}
            >{`responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.
responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.`}</Text>
          </View>
        </View>
        <View style={styles.frameParent18}>
          <View style={styles.frameParent19}>
            <View style={styles.frameParent4}>
              <View style={styles.ellipseWrapper}>
                <Image
                  style={styles.ellipseIcon}
                  contentFit="cover"
                  source={require("../assets/ellipse-12.png")}
                />
              </View>
              <View>
                <View style={styles.hotelRadissonWrapper}>
                  <Text style={[styles.fatou, styles.fatouTypo]}>fatou</Text>
                </View>
                <View style={styles.hotelRadissonWrapper}>
                  <Text style={[styles.text7, styles.textTypo]}>
                    12/12/2023
                  </Text>
                </View>
                <View style={styles.frameParent4}>
                  <Image
                    style={styles.starIconLayout}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                  <Image
                    style={[styles.starIcon11, styles.starIconLayout]}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                  <Image
                    style={[styles.starIcon11, styles.starIconLayout]}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                  <Image
                    style={[styles.starIcon11, styles.starIconLayout]}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                  <Image
                    style={[styles.starIcon11, styles.starIconLayout]}
                    contentFit="cover"
                    source={require("../assets/star6.png")}
                  />
                </View>
              </View>
            </View>
            <Image
              style={styles.frameIcon}
              contentFit="cover"
              source={require("../assets/frame-227.png")}
            />
          </View>
          <View style={styles.responsibleForDiagnosingExWrapper}>
            <Text
              style={[
                styles.responsibleForDiagnosing,
                styles.shareHereSomethingTypo,
              ]}
            >{`responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.
responsible for diagnosing, examining, diseases, disorders, and illnesses of patients.`}</Text>
          </View>
        </View>
        <View style={styles.voirPlusWrapper}>
          <Pressable
            onPress={() =>
              navigation.navigate("BottomTabsRoot", { screen: "AllReviews" })
            }
          >
            <Text style={[styles.voirPlus1, styles.ajouterTypo]}>
              Voir plus
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  frameScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  addReviewLayout: {
    width: "100%",
    overflow: "hidden",
    flex: 1,
  },
  ajouterTypo: {
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textTransform: "capitalize",
  },
  fatouTypo: {
    color: Color.colorDarkslategray_200,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textTransform: "capitalize",
  },
  containerPosition: {
    left: 0,
    position: "absolute",
  },
  frameViewSpaceBlock: {
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: 0,
    flexDirection: "row",
    alignItems: "center",
  },
  textTypo: {
    color: Color.labelsPrimary,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textTransform: "capitalize",
  },
  containerSpaceBlock: {
    marginTop: 5,
    flexDirection: "row",
  },
  starIconLayout2: {
    height: 12,
    width: 12,
  },
  frameChildLayout: {
    height: 10,
    borderRadius: Border.br_8xs,
  },
  frameParentFlexBox: {
    alignItems: "flex-end",
    alignSelf: "stretch",
  },
  starIconLayout1: {
    height: 33,
    width: 33,
    top: 0,
  },
  starIcon8Position: {
    left: 159,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  shareHereSomethingTypo: {
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
    color: Color.labelsPrimary,
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  frameWrapperFlexBox: {
    height: 67,
    marginTop: 8,
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  starIconLayout: {
    height: 13,
    width: 13,
  },
  buttonFlexBox: {
    width: 349,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  lightLayout: {
    height: 41,
    width: 41,
  },
  addReviewChild: {
    width: 375,
    height: 65,
    justifyContent: "space-between",
    alignItems: "center",
    overflow: "hidden",
  },
  backButton: {
    width: 25,
    height: 25,
  },
  backButtonWrapper: {
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: 0,
    height: 42,
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  ajoutezUnAvis: {
    fontSize: FontSize.size_base,
    width: 171,
    color: Color.color,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  ajoutezUnAvisWrapper: {
    height: 42,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
  frameGroup: {
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
  },
  maskGroupChild: {
    maxWidth: "100%",
    maxHeight: "100%",
    alignSelf: "stretch",
    overflow: "hidden",
  },
  maskGroup: {
    borderRadius: 14,
    backgroundColor: Color.labelsPrimary,
    height: 85,
    flex: 1,
  },
  yearExperience: {
    top: 65,
    left: 14,
    width: 139,
    height: 7,
    display: "none",
    fontSize: FontSize.size_3xs,
    position: "absolute",
  },
  hotelRadisson: {
    fontSize: FontSize.subtitleBold14_size,
  },
  hotelRadissonWrapper: {
    padding: Padding.p_3xs,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  rteDeLa: {
    fontSize: FontSize.size_3xs,
  },
  frameContainer: {
    width: 188,
    top: 0,
    left: 0,
    height: 85,
  },
  yearExperienceParent: {
    height: 85,
    flex: 1,
  },
  maskGroupParent: {
    marginTop: 8,
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
  },
  total6Avis: {
    fontSize: FontSize.size_xs,
  },
  text1: {
    fontSize: 56,
    letterSpacing: 1.4,
    lineHeight: 76,
  },
  container: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    alignItems: "center",
  },
  starIcon1: {
    marginLeft: 5,
  },
  frameParent1: {
    width: 127,
  },
  frameWrapper1: {
    height: 109,
    justifyContent: "space-between",
    flex: 1,
  },
  frameWrapper: {
    paddingHorizontal: Padding.p_xs,
    paddingVertical: Padding.p_3xs,
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
  text2: {
    fontSize: FontSize.subtitleBold14_size,
  },
  frame: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    alignItems: "center",
  },
  frameChild: {
    backgroundColor: Color.grey,
    width: 180,
  },
  rectangleWrapper: {
    zIndex: 0,
    padding: Padding.p_3xs,
  },
  frameItem: {
    width: 144,
    backgroundColor: Color.color,
  },
  rectangleContainer: {
    zIndex: 1,
    padding: Padding.p_3xs,
    top: 0,
    left: 0,
  },
  frameParent4: {
    flexDirection: "row",
  },
  votes: {
    opacity: 0.5,
    fontSize: FontSize.size_3xs,
  },
  votesWrapper: {
    justifyContent: "center",
  },
  rectangleView: {
    width: 48,
    backgroundColor: Color.color,
  },
  frameChild4: {
    width: 5,
    backgroundColor: Color.color,
  },
  rectangleWrapper5: {
    zIndex: 1,
    padding: Padding.p_3xs,
    top: 0,
    left: 0,
    flexDirection: "row",
  },
  frameParent12: {
    height: 38,
    justifyContent: "space-between",
  },
  frameParent2: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_xs,
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
  frameView: {
    height: 194,
    flexWrap: "wrap",
    marginTop: 8,
    alignSelf: "stretch",
    justifyContent: "space-between",
  },
  starIcon5: {
    left: 0,
    position: "absolute",
  },
  starIcon6: {
    left: 53,
    position: "absolute",
  },
  starIcon7: {
    left: 106,
    position: "absolute",
  },
  starIcon8: {
    height: 33,
    width: 33,
    top: 0,
  },
  starIcon9: {
    left: 212,
    position: "absolute",
  },
  component44: {
    width: 255,
    height: 54,
  },
  component44Wrapper: {
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
    flex: 1,
  },
  component45Child: {
    top: "0%",
    right: "0%",
    bottom: "0%",
    left: "0%",
    borderStyle: "solid",
    borderColor: Color.colorRoyalblue,
    borderWidth: 0.5,
    borderRadius: Border.br_3xs,
    position: "absolute",
    backgroundColor: Color.labelColorDarkPrimary,
  },
  shareHereSomething: {
    top: "15%",
    left: "4.55%",
    opacity: 0.4,
    position: "absolute",
  },
  component45: {
    width: 330,
    height: 100,
  },
  frameWrapper3: {
    padding: Padding.p_3xs,
    marginTop: 8,
    flexDirection: "row",
    alignSelf: "stretch",
    justifyContent: "space-between",
    alignItems: "center",
  },
  ajouter: {
    color: Color.labelColorDarkPrimary,
    fontSize: FontSize.subtitleBold14_size,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  ajouterWrapper: {
    width: 135,
    paddingHorizontal: 41,
    paddingVertical: 15,
    borderRadius: Border.br_3xs,
    backgroundColor: Color.color,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  frameWrapper4: {
    flexDirection: "row",
    alignItems: "center",
  },
  ellipseIcon: {
    width: 40,
    height: 40,
  },
  ellipseWrapper: {
    padding: Padding.p_3xs,
    flexDirection: "row",
  },
  fatou: {
    fontSize: FontSize.size_xs,
  },
  text7: {
    fontSize: FontSize.size_5xs,
    opacity: 0.6,
  },
  starIcon11: {
    marginLeft: 5,
  },
  frameIcon: {
    width: 4,
    height: 19,
    marginLeft: 191,
  },
  frameParent19: {
    flexDirection: "row",
    alignItems: "center",
  },
  responsibleForDiagnosing: {
    letterSpacing: 0.2,
    width: 283,
    opacity: 0.8,
    textTransform: "capitalize",
    fontFamily: FontFamily.poppinsLight,
    fontWeight: "300",
  },
  responsibleForDiagnosingExWrapper: {
    marginTop: 3,
    padding: Padding.p_3xs,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  frameParent18: {
    marginTop: 8,
    alignSelf: "stretch",
    justifyContent: "center",
    alignItems: "center",
  },
  voirPlus1: {
    fontSize: FontSize.subtitleBold14_size,
    color: Color.color,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
  },
  voirPlusWrapper: {
    padding: Padding.p_3xs,
    marginTop: 8,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  frameParent: {
    alignSelf: "stretch",
    flex: 1,
  },
  addReview: {
    height: 1181,
    paddingTop: 52,
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
    backgroundColor: Color.labelColorDarkPrimary,
  },
});

export default AddReview;
