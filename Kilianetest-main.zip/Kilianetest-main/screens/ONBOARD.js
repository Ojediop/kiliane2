import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Padding, FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const ONBOARD = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.onboard1, styles.onboard1FlexBox]}>
      <View style={styles.stattusBar}>
        <View style={[styles.timeWrapper, styles.wrapperFlexBox1]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
        </View>
        <View style={styles.cellularConnectionParent}>
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <View style={styles.battery}>
            <View style={[styles.border, styles.borderPosition]} />
            <Image
              style={[styles.capIcon, styles.borderPosition]}
              contentFit="cover"
              source={require("../assets/cap.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={[styles.frameParent, styles.onboard1FlexBox]}>
        <View
          style={[styles.welcomeMessageContainerWrapper, styles.wrapperFlexBox]}
        >
          <View>
            <View style={[styles.titleWrapper, styles.wrapperFlexBox1]}>
              <Text style={styles.title}>Kiliane</Text>
            </View>
            <View
              style={[
                styles.loremIpsumDolorSitAmetCoWrapper,
                styles.onboardFlexBox,
              ]}
            >
              <Text
                style={[styles.loremIpsumDolor, styles.button1Typo]}
              >{`Avec kiliane, nous offrons une opportunité sans précédent aux utilisateurs de
partager leurs expériences en temps réel`}</Text>
            </View>
          </View>
        </View>
        <View style={[styles.onboardWrapper, styles.wrapperFlexBox]}>
          <Pressable
            style={[styles.onboard, styles.onboardFlexBox]}
            onPress={() => navigation.navigate("ONBOARD1")}
          >
            <View style={styles.carouselIndicator}>
              <View style={styles.carouselIndicatorChild} />
              <Image
                style={styles.carouselIndicatorItem}
                contentFit="cover"
                source={require("../assets/ellipse-1.png")}
              />
              <Image
                style={styles.carouselIndicatorItem}
                contentFit="cover"
                source={require("../assets/ellipse-1.png")}
              />
            </View>
            <Pressable
              style={styles.button}
              onPress={() => navigation.navigate("ONBOARD1")}
            >
              <View style={styles.buttonWrapper}>
                <Text style={[styles.button1, styles.button1Typo]}>
                  Suivant
                </Text>
              </View>
            </Pressable>
          </Pressable>
        </View>
      </View>
      <View style={styles.homeIndicator}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  onboard1FlexBox: {
    overflow: "hidden",
    alignItems: "center",
  },
  wrapperFlexBox1: {
    paddingVertical: Padding.p_3xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  timeTypo: {
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  borderPosition: {
    left: "50%",
    position: "absolute",
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  wrapperFlexBox: {
    padding: Padding.p_3xs,
    justifyContent: "space-between",
    alignItems: "center",
  },
  onboardFlexBox: {
    width: 327,
    alignItems: "center",
    flexDirection: "row",
  },
  button1Typo: {
    fontSize: FontSize.size_xl,
    textAlign: "left",
  },
  time: {
    fontSize: FontSize.size_mid,
    lineHeight: 22,
    color: Color.labelsPrimary,
    textAlign: "center",
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    height: 44,
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderStyle: "solid",
    borderColor: Color.labelsPrimary,
    borderWidth: 1,
    width: 25,
    opacity: 0.35,
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    height: 13,
    width: 27,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  stattusBar: {
    justifyContent: "space-between",
    width: 375,
    alignItems: "center",
    flexDirection: "row",
  },
  title: {
    fontSize: FontSize.size_5xl,
    lineHeight: 36,
    color: Color.color,
    textAlign: "left",
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  titleWrapper: {
    backgroundColor: Color.labelColorDarkPrimary,
    paddingHorizontal: 0,
  },
  loremIpsumDolor: {
    lineHeight: 30,
    fontWeight: "500",
    fontFamily: FontFamily.montserratMedium,
    color: Color.textDark,
    flex: 1,
  },
  loremIpsumDolorSitAmetCoWrapper: {
    paddingVertical: Padding.p_xs,
    paddingHorizontal: 0,
    justifyContent: "center",
  },
  welcomeMessageContainerWrapper: {
    height: 250,
  },
  carouselIndicatorChild: {
    borderRadius: Border.br_31xl,
    height: 8,
    backgroundColor: Color.color,
    width: 27,
  },
  carouselIndicatorItem: {
    width: 8,
    marginLeft: 4,
    height: 8,
  },
  carouselIndicator: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  button1: {
    color: Color.color1,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  buttonWrapper: {
    borderRadius: Border.br_9xs,
    width: 120,
    height: 48,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_7xs,
    backgroundColor: Color.color,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  button: {
    flexDirection: "row",
  },
  onboard: {
    justifyContent: "space-between",
  },
  onboardWrapper: {
    height: 68,
    marginTop: 27,
  },
  frameParent: {
    alignSelf: "stretch",
    justifyContent: "flex-end",
    marginLeft: 191,
    alignItems: "center",
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
    marginLeft: 191,
    width: 375,
  },
  onboard1: {
    backgroundColor: Color.color1,
    width: "100%",
    height: 812,
    paddingVertical: Padding.p_49xl,
    paddingHorizontal: 0,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    flex: 1,
  },
});

export default ONBOARD;
