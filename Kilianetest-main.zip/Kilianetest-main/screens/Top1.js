import * as React from "react";
import { StyleSheet, View } from "react-native";
import { Color } from "../GlobalStyles";

const Top1 = () => {
  return <View style={styles.top10} />;
};

const styles = StyleSheet.create({
  top10: {
    backgroundColor: Color.labelColorDarkPrimary,
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
  },
});

export default Top1;
