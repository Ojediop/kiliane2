import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Padding, FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const ONBOARD2 = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.onboard3, styles.onboardFlexBox1]}>
      <View style={[styles.stattusBar, styles.stattusBarLayout]}>
        <View style={[styles.timeWrapper, styles.wrapperFlexBox]}>
          <Text style={[styles.time, styles.timeTypo]}>9:41</Text>
        </View>
        <View
          style={[styles.cellularConnectionParent, styles.timeWrapperLayout]}
        >
          <Image
            style={styles.cellularConnectionIcon}
            contentFit="cover"
            source={require("../assets/cellular-connection.png")}
          />
          <Image
            style={styles.wifiIcon}
            contentFit="cover"
            source={require("../assets/wifi.png")}
          />
          <View style={styles.battery}>
            <View style={[styles.border, styles.borderPosition]} />
            <Image
              style={[styles.capIcon, styles.borderPosition]}
              contentFit="cover"
              source={require("../assets/cap.png")}
            />
            <View style={[styles.capacity, styles.capacityPosition]} />
          </View>
        </View>
      </View>
      <View style={styles.welcomeMessageContainerWrapper}>
        <View>
          <View style={[styles.titleWrapper, styles.wrapperSpaceBlock]}>
            <Text style={styles.title}>Kiliane</Text>
          </View>
          <View
            style={[
              styles.loremIpsumDolorSitAmetCoWrapper,
              styles.onboardFlexBox,
            ]}
          >
            <Text style={[styles.loremIpsumDolor, styles.button1Typo]}>
              Avec kiliane, la voix des clients est au coeur de l'amélioration
              continue.
            </Text>
          </View>
        </View>
      </View>
      <View style={[styles.onboardWrapper, styles.onboardFlexBox1]}>
        <Pressable
          style={[styles.onboard, styles.onboardFlexBox]}
          onPress={() => navigation.navigate("WELCOME")}
        >
          <View style={styles.carouselIndicator}>
            <Image
              style={styles.carouselIndicatorChild}
              contentFit="cover"
              source={require("../assets/ellipse-1.png")}
            />
            <Image
              style={[styles.carouselIndicatorItem, styles.carouselSpaceBlock]}
              contentFit="cover"
              source={require("../assets/ellipse-1.png")}
            />
            <View
              style={[styles.carouselIndicatorInner, styles.carouselSpaceBlock]}
            />
          </View>
          <Pressable
            style={styles.button}
            onPress={() => navigation.navigate("WELCOME")}
          >
            <View style={styles.buttonWrapper}>
              <Text style={[styles.button1, styles.button1Typo]}>Suivant</Text>
            </View>
          </Pressable>
        </Pressable>
      </View>
      <View style={[styles.homeIndicator, styles.stattusBarLayout]}>
        <View style={[styles.homeIndicator1, styles.capacityPosition]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  onboardFlexBox1: {
    justifyContent: "flex-end",
    alignItems: "center",
  },
  stattusBarLayout: {
    display: "none",
    width: 375,
  },
  wrapperFlexBox: {
    paddingVertical: Padding.p_3xs,
    flexDirection: "row",
    alignItems: "center",
  },
  timeTypo: {
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  timeWrapperLayout: {
    height: 44,
    justifyContent: "center",
  },
  borderPosition: {
    left: "50%",
    position: "absolute",
  },
  capacityPosition: {
    backgroundColor: Color.labelsPrimary,
    left: "50%",
    position: "absolute",
  },
  wrapperSpaceBlock: {
    paddingHorizontal: 0,
    justifyContent: "center",
  },
  onboardFlexBox: {
    width: 327,
    flexDirection: "row",
    alignItems: "center",
  },
  button1Typo: {
    fontSize: FontSize.size_xl,
    textAlign: "left",
  },
  carouselSpaceBlock: {
    marginLeft: 4,
    height: 8,
  },
  time: {
    fontSize: FontSize.size_mid,
    lineHeight: 22,
    color: Color.labelsPrimary,
    textAlign: "center",
  },
  timeWrapper: {
    paddingHorizontal: Padding.p_14xl,
    justifyContent: "center",
    height: 44,
  },
  cellularConnectionIcon: {
    width: 19,
    height: 12,
  },
  wifiIcon: {
    width: 17,
    marginLeft: 7,
    height: 12,
  },
  border: {
    height: "100%",
    marginLeft: -13.65,
    top: "0%",
    bottom: "0%",
    borderRadius: Border.br_8xs_3,
    borderStyle: "solid",
    borderColor: Color.labelsPrimary,
    borderWidth: 1,
    width: 25,
    opacity: 0.35,
  },
  capIcon: {
    height: "31.54%",
    marginLeft: 12.35,
    top: "36.92%",
    bottom: "31.54%",
    maxHeight: "100%",
    width: 1,
    opacity: 0.4,
  },
  capacity: {
    height: "69.23%",
    marginLeft: -11.65,
    top: "15.38%",
    bottom: "15.38%",
    borderRadius: Border.br_10xs_5,
    width: 21,
  },
  battery: {
    height: 13,
    width: 27,
    marginLeft: 7,
  },
  cellularConnectionParent: {
    paddingRight: Padding.p_mid,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  stattusBar: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  title: {
    fontSize: FontSize.size_5xl,
    lineHeight: 36,
    color: Color.color,
    textAlign: "left",
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  titleWrapper: {
    paddingVertical: Padding.p_3xs,
    flexDirection: "row",
    alignItems: "center",
  },
  loremIpsumDolor: {
    lineHeight: 30,
    fontWeight: "500",
    fontFamily: FontFamily.montserratMedium,
    color: Color.textDark,
    flex: 1,
  },
  loremIpsumDolorSitAmetCoWrapper: {
    paddingVertical: Padding.p_xs,
    paddingHorizontal: 0,
    justifyContent: "center",
  },
  welcomeMessageContainerWrapper: {
    alignSelf: "stretch",
    marginTop: 32,
    justifyContent: "center",
    alignItems: "center",
  },
  carouselIndicatorChild: {
    height: 8,
    width: 8,
  },
  carouselIndicatorItem: {
    width: 8,
    marginLeft: 4,
  },
  carouselIndicatorInner: {
    borderRadius: Border.br_31xl,
    backgroundColor: Color.color,
    width: 27,
  },
  carouselIndicator: {
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  button1: {
    color: Color.color1,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  buttonWrapper: {
    borderRadius: Border.br_9xs,
    width: 120,
    height: 48,
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_7xs,
    backgroundColor: Color.color,
    justifyContent: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  button: {
    flexDirection: "row",
  },
  onboard: {
    justifyContent: "space-between",
  },
  onboardWrapper: {
    marginTop: 32,
  },
  homeIndicator1: {
    marginLeft: 69.5,
    bottom: 8,
    borderRadius: Border.br_81xl,
    width: 139,
    height: 5,
    transform: [
      {
        rotate: "180deg",
      },
    ],
  },
  homeIndicator: {
    height: 21,
    marginTop: 32,
  },
  onboard3: {
    backgroundColor: Color.color1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    paddingHorizontal: Padding.p_5xl,
    paddingVertical: 80,
    flex: 1,
  },
});

export default ONBOARD2;
