import * as React from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
} from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Padding, Border } from "../GlobalStyles";

const HomePageInvite1 = () => {
  const navigation = useNavigation();

  return (
    <ScrollView
      style={styles.homePageInvite}
      showsVerticalScrollIndicator={true}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.homePageInviteContent}
    >
      <ScrollView
        style={styles.frameParent}
        showsVerticalScrollIndicator={true}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.frameScrollViewContent}
      >
        <View style={[styles.vectorParent, styles.frameParentSpaceBlock]}>
          <Image
            style={styles.frameChild}
            contentFit="cover"
            source={require("../assets/ellipse-101.png")}
          />
          <Text style={[styles.bonjourMoussa, styles.servicesText]}>
            Bonjour moussa
          </Text>
          <Image
            style={[styles.notificationIcon, styles.westHamParentLayout]}
            contentFit="cover"
            source={require("../assets/notification1.png")}
          />
          <View style={[styles.westHamParent, styles.westHamParentLayout]}>
            <Text style={[styles.westHam, styles.westHamPosition]}>
              west ham
            </Text>
            <Text style={[styles.yourLocation, styles.westHamTypo]}>
              your location
            </Text>
            <Image
              style={styles.locationIcon}
              contentFit="cover"
              source={require("../assets/location1.png")}
            />
            <Image
              style={[
                styles.downFilledTriangularArrow,
                styles.maskGroupParentPosition,
              ]}
              contentFit="cover"
              source={require("../assets/down-filled-triangular-arrow1.png")}
            />
          </View>
          <Image
            style={styles.frameItem}
            contentFit="cover"
            source={require("../assets/group-341.png")}
          />
          <View style={styles.component8}>
            <Text style={[styles.goodMorning, styles.goodMorningTypo]}>
              good morning
            </Text>
            <Text style={[styles.stayHealthy, styles.goodMorningTypo]}>
              stay healthy
            </Text>
          </View>
          <View style={[styles.homePageWrapper, styles.frameParentSpaceBlock]}>
            <TextInput
              style={styles.homePage}
              placeholder="”MIMS”"
              placeholderTextColor="#000"
            />
          </View>
          <Image
            style={[styles.frameInner, styles.groupIconLayout]}
            contentFit="cover"
            source={require("../assets/ellipse-91.png")}
          />
        </View>
        <View style={[styles.instanceWrapper, styles.homeWrapperFlexBox]}>
          <View style={[styles.frameWrapper, styles.maskGroupLayout]}>
            <View
              style={[styles.maskGroupParent, styles.maskGroupParentPosition]}
            >
              <Image
                style={styles.maskGroupLayout}
                contentFit="cover"
                source={require("../assets/mask-group22.png")}
              />
              <Image
                style={[styles.maskGroupIcon1, styles.maskGroupLayout]}
                contentFit="cover"
                source={require("../assets/mask-group23.png")}
              />
              <Image
                style={[styles.maskGroupIcon1, styles.maskGroupLayout]}
                contentFit="cover"
                source={require("../assets/mask-group24.png")}
              />
              <Image
                style={[styles.maskGroupIcon1, styles.maskGroupLayout]}
                contentFit="cover"
                source={require("../assets/mask-group25.png")}
              />
              <Image
                style={[styles.maskGroupIcon1, styles.maskGroupLayout]}
                contentFit="cover"
                source={require("../assets/mask-group26.png")}
              />
            </View>
          </View>
        </View>
        <View style={[styles.frameGroup, styles.frameParentSpaceBlock]}>
          <View style={styles.servicesWrapper}>
            <Text style={[styles.services, styles.servicesClr]}>Services</Text>
          </View>
          <Pressable
            style={styles.voirToutWrapper}
            onPress={() => navigation.navigate("AllServices")}
          >
            <Text style={[styles.voirTout, styles.voirTypo]}>Voir tout</Text>
          </Pressable>
        </View>
        <View style={styles.frameContainer}>
          <View style={[styles.frameView, styles.frameFlexBox1]}>
            <Pressable
              style={styles.maskGroupGroup}
              onPress={() => navigation.navigate("Service")}
            >
              <Image
                style={styles.maskGroupIcon5}
                contentFit="cover"
                source={require("../assets/mask-group27.png")}
              />
              <Text style={styles.hotel}>Hotel</Text>
            </Pressable>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon5}
                contentFit="cover"
                source={require("../assets/mask-group28.png")}
              />
              <Text style={styles.hotel}>Banque</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon5}
                contentFit="cover"
                source={require("../assets/mask-group29.png")}
              />
              <Text style={styles.hotel}>Restaurant</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon5}
                contentFit="cover"
                source={require("../assets/mask-group30.png")}
              />
              <Text style={styles.hotel}>Clinique</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon5}
                contentFit="cover"
                source={require("../assets/mask-group31.png")}
              />
              <Text style={styles.hotel}>dentiste</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon5}
                contentFit="cover"
                source={require("../assets/mask-group32.png")}
              />
              <Text style={styles.hotel}>gynecologe</Text>
            </View>
            <View style={styles.maskGroupGroup}>
              <Image
                style={styles.maskGroupIcon5}
                contentFit="cover"
                source={require("../assets/mask-group33.png")}
              />
              <Text style={styles.hotel}>Fast Food</Text>
            </View>
            <View>
              <Image
                style={styles.maskGroupIcon5}
                contentFit="cover"
                source={require("../assets/mask-group34.png")}
              />
              <Text style={styles.hotel}>Pret à porter</Text>
            </View>
          </View>
        </View>
        <View style={[styles.frameParent1, styles.hospitalsFlexBox]}>
          <View style={styles.lesMieuxNotsWrapper}>
            <Text style={[styles.services, styles.servicesClr]}>
              les mieux notés
            </Text>
          </View>
          <Pressable
            style={styles.voirToutWrapper}
            onPress={() => navigation.navigate("Top1")}
          >
            <Text style={[styles.voirTout, styles.voirTypo]}>Voir tout</Text>
          </Pressable>
        </View>
        <Pressable
          style={[styles.framePressable, styles.frameParentSpaceBlock]}
          onPress={() => navigation.navigate("AddReview")}
        >
          <View style={styles.maskGroup}>
            <Image
              style={styles.maskGroupChild}
              contentFit="cover"
              source={require("../assets/rectangle-351.png")}
            />
          </View>
          <View style={[styles.frameWrapper1, styles.frameFlexBox2]}>
            <View style={styles.frameParent2}>
              <View style={styles.frameParent3}>
                <View style={styles.frameParent3}>
                  <View style={styles.frameContainer}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star7.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool1.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.servicesText]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </Pressable>
        <View style={[styles.framePressable, styles.frameParentSpaceBlock]}>
          <View style={styles.maskGroup}>
            <Image
              style={styles.maskGroupChild}
              contentFit="cover"
              source={require("../assets/rectangle-352.png")}
            />
          </View>
          <View style={[styles.frameWrapper1, styles.frameFlexBox2]}>
            <View style={styles.frameParent2}>
              <View style={styles.frameParent3}>
                <View style={styles.frameParent3}>
                  <View style={styles.frameContainer}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star8.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool2.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.servicesText]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.framePressable, styles.frameParentSpaceBlock]}>
          <View style={styles.maskGroup}>
            <Image
              style={styles.maskGroupChild}
              contentFit="cover"
              source={require("../assets/rectangle-353.png")}
            />
          </View>
          <View style={[styles.frameWrapper1, styles.frameFlexBox2]}>
            <View style={styles.frameParent2}>
              <View style={styles.frameParent3}>
                <View style={styles.frameParent3}>
                  <View style={styles.frameContainer}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star9.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool3.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.servicesText]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.framePressable, styles.frameParentSpaceBlock]}>
          <View style={styles.maskGroup}>
            <Image
              style={styles.maskGroupChild}
              contentFit="cover"
              source={require("../assets/rectangle-354.png")}
            />
          </View>
          <View style={[styles.frameWrapper1, styles.frameFlexBox2]}>
            <View style={styles.frameParent2}>
              <View style={styles.frameParent3}>
                <View style={styles.frameParent3}>
                  <View style={styles.frameContainer}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star10.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool4.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.servicesText]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.framePressable, styles.frameParentSpaceBlock]}>
          <View style={styles.maskGroup}>
            <Image
              style={styles.maskGroupChild}
              contentFit="cover"
              source={require("../assets/rectangle-355.png")}
            />
          </View>
          <View style={[styles.frameWrapper1, styles.frameFlexBox2]}>
            <View style={styles.frameParent2}>
              <View style={styles.frameParent3}>
                <View style={styles.frameParent3}>
                  <View style={styles.frameContainer}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star11.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool5.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.servicesText]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <View style={[styles.framePressable, styles.frameParentSpaceBlock]}>
          <View style={styles.maskGroup}>
            <Image
              style={styles.maskGroupChild}
              contentFit="cover"
              source={require("../assets/rectangle-356.png")}
            />
          </View>
          <View style={[styles.frameWrapper1, styles.frameFlexBox2]}>
            <View style={styles.frameParent2}>
              <View style={styles.frameParent3}>
                <View style={styles.frameParent3}>
                  <View style={styles.frameContainer}>
                    <View
                      style={[
                        styles.seaPlazaWrapper,
                        styles.homeWrapperFlexBox,
                      ]}
                    >
                      <Text style={[styles.seaPlaza, styles.text1Typo]}>
                        Sea plaza
                      </Text>
                    </View>
                    <View style={styles.starParent}>
                      <Image
                        style={styles.starIcon}
                        contentFit="cover"
                        source={require("../assets/star12.png")}
                      />
                      <Text style={[styles.text, styles.textTypo]}>4.5</Text>
                      <Text style={[styles.rating, styles.textTypo]}>
                        rating
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                    <Text style={[styles.text1, styles.text1Typo]}>
                      (+221) 33 859 89 62
                    </Text>
                  </View>
                </View>
                <View style={[styles.wrapper, styles.wrapperFlexBox]}>
                  <Text
                    style={[styles.accueilseaplazateyliomcom, styles.text1Typo]}
                  >
                    accueil.seaplaza@teyliom.com
                  </Text>
                </View>
              </View>
              <View style={[styles.toolParent, styles.wrapperFlexBox]}>
                <Image
                  style={styles.toolIconLayout}
                  contentFit="cover"
                  source={require("../assets/tool6.png")}
                />
                <Text style={[styles.routeCornicheOuest, styles.servicesText]}>
                  Route Corniche Ouest, Dakar
                </Text>
              </View>
            </View>
          </View>
        </View>
        <ScrollView
          style={styles.frameScrollview}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={true}
          contentContainerStyle={styles.frameScrollView1Content}
        >
          <View style={[styles.frameParent26, styles.frameFlexBox1]}>
            <View style={styles.quelquesAvisWrapper}>
              <Text style={[styles.quelquesAvis, styles.voirTout2Typo]}>
                Quelques Avis
              </Text>
            </View>
            <Pressable
              style={[styles.frameWrapper7, styles.frameFlexBox]}
              onPress={() =>
                navigation.navigate("BottomTabsRoot", { screen: "AllReviews" })
              }
            >
              <View style={[styles.voirToutFrame, styles.frameFlexBox]}>
                <Text style={[styles.voirTout2, styles.voirTout2Typo]}>
                  Voir tout
                </Text>
              </View>
            </Pressable>
          </View>
          <View style={[styles.hospitals, styles.hospitalsFlexBox]}>
            <Pressable
              style={styles.maskGroupBg}
              onPress={() => navigation.navigate("Review")}
            >
              <Image
                style={styles.maskGroupIcon13}
                contentFit="cover"
                source={require("../assets/mask-group35.png")}
              />
              <Text style={[styles.laGondole, styles.servicesClr]}>
                la gondole
              </Text>
              <Text style={[styles.westHamNorth, styles.servicesText]}>
                west ham, north England
              </Text>
              <Image
                style={[styles.toolIcon6, styles.toolIconLayout]}
                contentFit="cover"
                source={require("../assets/tool7.png")}
              />
              <Text style={[styles.westHamNorth, styles.servicesText]}>
                5km away from your location
              </Text>
              <Image
                style={[styles.groupIcon, styles.groupIconLayout]}
                contentFit="cover"
                source={require("../assets/group-571.png")}
              />
            </Pressable>
            <View style={[styles.maskGroupParent13, styles.maskGroupBg]}>
              <Image
                style={styles.maskGroupIcon13}
                contentFit="cover"
                source={require("../assets/mask-group35.png")}
              />
              <Text style={[styles.laGondole, styles.servicesClr]}>
                la gondole
              </Text>
              <Text style={[styles.westHamNorth, styles.servicesText]}>
                west ham, north England
              </Text>
              <Image
                style={[styles.toolIcon6, styles.toolIconLayout]}
                contentFit="cover"
                source={require("../assets/tool7.png")}
              />
              <Text style={[styles.westHamNorth, styles.servicesText]}>
                5km away from your location
              </Text>
              <Image
                style={[styles.groupIcon, styles.groupIconLayout]}
                contentFit="cover"
                source={require("../assets/group-571.png")}
              />
            </View>
            <View style={[styles.maskGroupParent13, styles.maskGroupBg]}>
              <Image
                style={styles.maskGroupIcon13}
                contentFit="cover"
                source={require("../assets/mask-group35.png")}
              />
              <Text style={[styles.laGondole, styles.servicesClr]}>
                la gondole
              </Text>
              <Text style={[styles.westHamNorth, styles.servicesText]}>
                west ham, north England
              </Text>
              <Image
                style={[styles.toolIcon6, styles.toolIconLayout]}
                contentFit="cover"
                source={require("../assets/tool7.png")}
              />
              <Text style={[styles.westHamNorth, styles.servicesText]}>
                5km away from your location
              </Text>
              <Image
                style={[styles.groupIcon, styles.groupIconLayout]}
                contentFit="cover"
                source={require("../assets/group-571.png")}
              />
            </View>
          </View>
        </ScrollView>
      </ScrollView>
      <View style={[styles.homePageInviteInner, styles.homeWrapperFlexBox]}>
        <View style={styles.rectangleView} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  frameScrollView1Content: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  frameScrollViewContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-between",
  },
  homePageInviteContent: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  frameParentSpaceBlock: {
    paddingVertical: 0,
    alignSelf: "stretch",
  },
  servicesText: {
    textAlign: "left",
    textTransform: "capitalize",
  },
  westHamParentLayout: {
    height: 20,
    marginTop: 1,
    display: "none",
  },
  westHamPosition: {
    opacity: 0.8,
    top: 13,
  },
  westHamTypo: {
    fontFamily: FontFamily.poppinsRegular,
    left: 11,
    position: "absolute",
    textAlign: "left",
    color: Color.colorDarkslategray_100,
    textTransform: "capitalize",
  },
  maskGroupParentPosition: {
    left: 0,
    position: "absolute",
  },
  goodMorningTypo: {
    fontSize: FontSize.size_smi_7,
    opacity: 0.7,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    color: Color.colorDarkslategray_100,
    textTransform: "capitalize",
  },
  groupIconLayout: {
    width: 9,
    display: "none",
  },
  homeWrapperFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  maskGroupLayout: {
    height: 151,
    width: 330,
  },
  servicesClr: {
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratMedium,
  },
  voirTypo: {
    color: Color.color,
    fontFamily: FontFamily.poppinsMedium,
    fontSize: FontSize.size_xs,
  },
  frameFlexBox1: {
    paddingHorizontal: Padding.p_xl,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  hospitalsFlexBox: {
    width: 375,
    flexDirection: "row",
    paddingVertical: 0,
    alignItems: "center",
  },
  frameFlexBox2: {
    flexWrap: "wrap",
    flex: 1,
  },
  text1Typo: {
    color: Color.colorTeal,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
    textAlign: "left",
    textTransform: "capitalize",
  },
  textTypo: {
    marginTop: 4,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textTransform: "capitalize",
  },
  wrapperFlexBox: {
    marginTop: 6,
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "stretch",
  },
  voirTout2Typo: {
    textAlign: "center",
    fontWeight: "500",
    textTransform: "capitalize",
  },
  frameFlexBox: {
    width: 71,
    flexDirection: "row",
    alignItems: "center",
  },
  toolIconLayout: {
    width: 10,
    opacity: 0.7,
    height: 10,
  },
  maskGroupBg: {
    backgroundColor: Color.colorWhitesmoke_100,
    borderRadius: Border.br_3xs,
    padding: Padding.p_3xs,
  },
  buttonFlexBox: {
    width: 349,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  lightLayout: {
    width: 41,
    height: 41,
  },
  frameChild: {
    width: 11,
    height: 10,
    zIndex: 0,
  },
  bonjourMoussa: {
    marginTop: 1,
    zIndex: 1,
    display: "none",
    color: Color.colorDarkslategray_100,
    textAlign: "left",
    fontFamily: FontFamily.montserratMedium,
    fontWeight: "500",
    textTransform: "capitalize",
    fontSize: FontSize.subtitleBold14_size,
  },
  notificationIcon: {
    width: 20,
    zIndex: 2,
  },
  westHam: {
    fontFamily: FontFamily.poppinsRegular,
    left: 11,
    position: "absolute",
    textAlign: "left",
    color: Color.colorDarkslategray_100,
    textTransform: "capitalize",
    fontSize: FontSize.size_3xs,
  },
  yourLocation: {
    top: 1,
    fontSize: FontSize.size_5xs,
    opacity: 0.5,
  },
  locationIcon: {
    left: 70,
    width: 19,
    height: 19,
    top: 0,
    position: "absolute",
  },
  downFilledTriangularArrow: {
    borderRadius: Border.br_115xl,
    width: 7,
    height: 7,
    opacity: 0.8,
    top: 13,
  },
  westHamParent: {
    width: 89,
    zIndex: 3,
  },
  frameItem: {
    width: 45,
    height: 45,
    zIndex: 4,
    marginTop: 1,
    display: "none",
  },
  goodMorning: {
    opacity: 0.7,
  },
  stayHealthy: {
    marginTop: 6.3,
    opacity: 0.7,
  },
  component8: {
    height: 13,
    zIndex: 5,
    marginTop: 1,
    display: "none",
    overflow: "hidden",
  },
  homePage: {
    height: 41,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.subtitleBold14_size,
    alignSelf: "stretch",
  },
  homePageWrapper: {
    zIndex: 6,
    paddingHorizontal: Padding.p_3xs,
    marginTop: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  frameInner: {
    left: 321,
    height: 9,
    zIndex: 7,
    top: 0,
    position: "absolute",
  },
  vectorParent: {
    height: 88,
    paddingHorizontal: Padding.p_lgi,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Color.labelColorDarkPrimary,
  },
  maskGroupIcon1: {
    marginLeft: 20,
  },
  maskGroupParent: {
    flexDirection: "row",
    top: 0,
  },
  frameWrapper: {
    shadowColor: "rgba(0, 0, 0, 0.15)",
    shadowRadius: 10,
    elevation: 10,
    borderRadius: Border.br_3xs,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    overflow: "hidden",
    backgroundColor: Color.labelColorDarkPrimary,
  },
  instanceWrapper: {
    padding: Padding.p_3xs,
    alignSelf: "stretch",
  },
  services: {
    fontSize: FontSize.defaultBoldSubheadline_size,
    color: Color.labelsPrimary,
    textAlign: "left",
    textTransform: "capitalize",
    fontWeight: "500",
  },
  servicesWrapper: {
    width: 83,
    justifyContent: "space-between",
    flexDirection: "row",
    padding: Padding.p_3xs,
    alignItems: "center",
  },
  voirTout: {
    textAlign: "left",
    textTransform: "capitalize",
    fontWeight: "500",
  },
  voirToutWrapper: {
    width: 74,
    justifyContent: "space-between",
    flexDirection: "row",
    padding: Padding.p_3xs,
    alignItems: "center",
  },
  frameGroup: {
    paddingHorizontal: Padding.p_11xl,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  maskGroupIcon5: {
    width: 70,
    height: 70,
  },
  hotel: {
    marginTop: 12,
    color: Color.colorDarkslategray_200,
    fontFamily: FontFamily.poppinsMedium,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    fontWeight: "500",
    textTransform: "capitalize",
  },
  maskGroupGroup: {
    alignItems: "center",
  },
  frameView: {
    paddingVertical: Padding.p_5xs,
    flexWrap: "wrap",
    flex: 1,
  },
  frameContainer: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "stretch",
  },
  lesMieuxNotsWrapper: {
    width: 145,
    justifyContent: "space-between",
    flexDirection: "row",
    padding: Padding.p_3xs,
    alignItems: "center",
  },
  frameParent1: {
    paddingHorizontal: Padding.p_base,
    justifyContent: "space-between",
  },
  maskGroupChild: {
    height: 99,
    width: 93,
  },
  maskGroup: {
    backgroundColor: Color.labelsPrimary,
    width: 93,
    borderRadius: Border.br_3xs,
  },
  seaPlaza: {
    fontSize: FontSize.subtitleBold14_size,
    fontFamily: FontFamily.montserratSemiBold,
    fontWeight: "600",
  },
  seaPlazaWrapper: {
    flexDirection: "row",
    padding: Padding.p_3xs,
  },
  starIcon: {
    width: 15,
    height: 15,
  },
  text: {
    fontSize: FontSize.size_2xs_3,
    color: Color.colorDarkslategray_200,
  },
  rating: {
    fontSize: FontSize.size_6xs_9,
    color: Color.colorSteelblue,
    opacity: 0.7,
  },
  starParent: {
    width: 24,
    alignItems: "flex-end",
  },
  text1: {
    fontSize: FontSize.size_xs,
  },
  wrapper: {
    padding: Padding.p_3xs,
  },
  frameParent3: {
    alignSelf: "stretch",
  },
  accueilseaplazateyliomcom: {
    fontSize: FontSize.size_2xs,
  },
  routeCornicheOuest: {
    lineHeight: 13,
    width: 181,
    marginLeft: 10,
    color: Color.colorDarkslategray_200,
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.montserratMedium,
    textAlign: "left",
    fontWeight: "500",
    textTransform: "capitalize",
  },
  toolParent: {
    opacity: 0.7,
  },
  frameParent2: {
    flex: 1,
  },
  frameWrapper1: {
    height: 132,
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  framePressable: {
    justifyContent: "space-between",
    flexDirection: "row",
    paddingHorizontal: Padding.p_3xs,
    alignItems: "center",
  },
  quelquesAvis: {
    width: 125,
    color: Color.labelsPrimary,
    fontFamily: FontFamily.montserratMedium,
    fontSize: FontSize.defaultBoldSubheadline_size,
  },
  quelquesAvisWrapper: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  voirTout2: {
    width: 68,
    color: Color.color,
    fontFamily: FontFamily.poppinsMedium,
    fontSize: FontSize.size_xs,
  },
  voirToutFrame: {
    justifyContent: "flex-end",
  },
  frameWrapper7: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
    justifyContent: "space-between",
  },
  frameParent26: {
    paddingVertical: 0,
    alignSelf: "stretch",
  },
  maskGroupIcon13: {
    width: 200,
    height: 110,
  },
  laGondole: {
    marginTop: 10,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    textTransform: "capitalize",
    fontWeight: "500",
  },
  westHamNorth: {
    fontFamily: FontFamily.montserratRegular,
    marginTop: 10,
    color: Color.colorDarkslategray_200,
    fontSize: FontSize.size_3xs,
    display: "none",
    textAlign: "left",
    textTransform: "capitalize",
  },
  toolIcon6: {
    marginTop: 10,
    display: "none",
  },
  groupIcon: {
    height: 8,
    marginTop: 10,
    opacity: 0.7,
  },
  maskGroupParent13: {
    marginLeft: 10,
  },
  hospitals: {
    paddingHorizontal: Padding.p_3xs,
  },
  frameScrollview: {
    alignSelf: "stretch",
    flex: 1,
  },
  frameParent: {
    zIndex: 0,
    alignSelf: "stretch",
    flex: 1,
  },
  rectangleView: {
    width: 373,
    height: 57,
    backgroundColor: Color.labelColorDarkPrimary,
  },
  homePageInviteInner: {
    left: 1,
    height: 55,
    top: 0,
    position: "absolute",
    zIndex: 1,
  },
  homePageInvite: {
    maxWidth: "100%",
    overflow: "hidden",
    width: "100%",
    flex: 1,
    backgroundColor: Color.labelColorDarkPrimary,
  },
});

export default HomePageInvite1;
